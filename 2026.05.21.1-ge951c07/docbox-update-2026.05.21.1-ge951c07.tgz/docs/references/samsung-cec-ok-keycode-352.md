# Samsung HDMI-CEC OK button key code 352

Use this when the Docbox/TVmed physical TV remote mostly works but OK/Enter does not select kiosk buttons.

## Symptom

The CEC input bridge log shows directional and back buttons being consumed, but OK appears as an unmapped Linux input key:

```text
Unmapped CEC input key code=352 value=1
```

## Fix

Map Linux key code `352` to the kiosk `SELECT` action in `tvmed_cec_input_bridge.py`:

```python
ACTION_BY_KEY_CODE = {
    # ...
    352: "SELECT",  # KEY_OK on Samsung/CEC input remotes
    353: "SELECT",  # KEY_SELECT / KEY_OK on many remotes
}
```

Keep a regression test asserting:

```python
self.assertEqual(tvmed_cec_input_bridge.ACTION_BY_KEY_CODE[352], "SELECT")
```

## Verification

1. Restart the bridge or kiosk service.
2. Press OK/Enter on the TV remote.
3. Confirm the log shows:

```text
CEC input 352 -> SELECT consumed=True
```

## Notes

- This is separate from HDMI wake/reclaim. Wake/reclaim uses `/dev/cec*`; button capture uses `/dev/input/event*`.
- On Pi 5, the input bridge should monitor both `vc4-hdmi-0` and `vc4-hdmi-1` event devices when present.
