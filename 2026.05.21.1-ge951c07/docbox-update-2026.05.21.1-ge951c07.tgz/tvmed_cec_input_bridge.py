#!/usr/bin/env python3
"""Bridge Raspberry Pi HDMI-CEC kernel input events into the TVmed kiosk.

`cec-ctl --monitor` often requires root.  Raspberry Pi's vc4 HDMI driver also
exposes CEC remote presses as `/dev/input/event*` keyboard devices
(`vc4-hdmi-0`, `vc4-hdmi-1`).  This helper reads those event devices as the
`input` group user and forwards known remote keys directly to the kiosk through
Chrome DevTools.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import select
import struct
import sys
from pathlib import Path

INPUT_EVENT = struct.Struct("llHHI")
EV_KEY = 0x01

ACTION_BY_KEY_CODE = {
    1: "BACK",      # KEY_ESC
    28: "SELECT",   # KEY_ENTER
    96: "SELECT",   # KEY_KPENTER
    103: "UP",      # KEY_UP
    105: "LEFT",    # KEY_LEFT
    106: "RIGHT",   # KEY_RIGHT
    108: "DOWN",    # KEY_DOWN
    158: "BACK",    # KEY_BACK
    174: "BACK",    # KEY_EXIT
    352: "SELECT",  # KEY_OK on Samsung/CEC input remotes
    353: "SELECT",  # KEY_SELECT / KEY_OK on many remotes
}


def discover_vc4_hdmi_event_devices() -> list[Path]:
    devices = Path("/proc/bus/input/devices").read_text(errors="replace").split("\n\n")
    paths: list[Path] = []
    for block in devices:
        if 'Name="vc4-hdmi-' not in block:
            continue
        if "Handlers=" not in block or "kbd" not in block:
            continue
        match = re.search(r"Handlers=.*?\b(event\d+)\b", block)
        if match:
            path = Path("/dev/input") / match.group(1)
            if path.exists() and path not in paths:
                paths.append(path)
    return paths


def emit_remote_action(action: str, code: int, dry_run: bool = False) -> bool:
    detail = {"action": action, "source": "cec-input", "keyCode": code}
    if dry_run:
        print(f"CEC input {code} -> {action}: {json.dumps(detail, sort_keys=True)}", flush=True)
        return True
    try:
        from tvmed_device_api import find_kiosk_ws_url, websocket_eval

        payload = json.dumps(detail)
        expr = f"window.tvmedKiosk && window.tvmedKiosk.remoteAction && window.tvmedKiosk.remoteAction({payload})"
        response = websocket_eval(find_kiosk_ws_url(), expr, timeout=1.0)
        value = response.get("result", {}).get("result", {}).get("value")
        print(f"CEC input {code} -> {action} consumed={bool(value)}", flush=True)
        return bool(value)
    except Exception as exc:
        print(f"CEC input {code} -> {action} failed: {exc}", file=sys.stderr, flush=True)
        return False


def run(devices: list[Path], dry_run: bool = False) -> int:
    if not devices:
        print("No vc4 HDMI CEC input event devices found", file=sys.stderr, flush=True)
        return 2
    files = []
    for path in devices:
        try:
            fh = path.open("rb", buffering=0)
        except PermissionError as exc:
            print(f"Cannot read {path}: {exc}; ensure user is in input group", file=sys.stderr, flush=True)
            continue
        files.append(fh)
        print(f"Monitoring CEC input events from {path}", flush=True)
    if not files:
        return 13

    while True:
        readable, _, _ = select.select(files, [], [])
        for fh in readable:
            data = fh.read(INPUT_EVENT.size)
            if len(data) != INPUT_EVENT.size:
                continue
            _sec, _usec, event_type, code, value = INPUT_EVENT.unpack(data)
            if event_type != EV_KEY or value not in (1, 2):
                continue
            action = ACTION_BY_KEY_CODE.get(code)
            if action:
                emit_remote_action(action, code, dry_run=dry_run)
            else:
                print(f"Unmapped CEC input key code={code} value={value}", flush=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Bridge vc4 HDMI CEC input events to TVmed kiosk actions")
    parser.add_argument("--device", action="append", help="Explicit /dev/input/eventX device; repeatable")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    devices = [Path(item) for item in args.device] if args.device else discover_vc4_hdmi_event_devices()
    return run(devices, dry_run=args.dry_run)


if __name__ == "__main__":
    raise SystemExit(main())
