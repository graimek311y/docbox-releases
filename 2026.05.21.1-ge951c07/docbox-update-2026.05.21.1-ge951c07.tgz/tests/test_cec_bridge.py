#!/usr/bin/env python3
"""Regression tests for HDMI-CEC remote bridge behavior."""

from __future__ import annotations

import unittest
from unittest import mock

import tvmed_cec_bridge
import tvmed_cec_input_bridge


class CecBridgeTest(unittest.TestCase):
    def test_reclaim_interval_defaults_to_disabled(self) -> None:
        self.assertEqual(tvmed_cec_bridge.DEFAULT_RECLAIM_INTERVAL_SECONDS, 0)

    def test_configure_cec_source_is_playback_only_by_default(self) -> None:
        with mock.patch("tvmed_cec_bridge.os.geteuid", return_value=0), \
             mock.patch("tvmed_cec_bridge.subprocess.run") as run:
            run.side_effect = [
                mock.Mock(stdout="Physical Address: 1.0.0.0\n", returncode=0),
                mock.Mock(stdout="", returncode=0),
            ]

            result = tvmed_cec_bridge.configure_cec_source("/dev/cec0", use_sudo=True)

        self.assertTrue(result["ok"])
        self.assertFalse(result["activeSource"])
        command = run.call_args_list[1].args[0]
        self.assertIn("--playback", command)
        self.assertNotIn("--active-source", command)

    def test_configure_cec_source_active_source_is_explicit(self) -> None:
        with mock.patch("tvmed_cec_bridge.os.geteuid", return_value=0), \
             mock.patch("tvmed_cec_bridge.subprocess.run") as run:
            run.side_effect = [
                mock.Mock(stdout="Physical Address: 1.0.0.0\n", returncode=0),
                mock.Mock(stdout="", returncode=0),
            ]

            result = tvmed_cec_bridge.configure_cec_source("/dev/cec0", use_sudo=True, active_source=True)

        self.assertTrue(result["activeSource"])
        command = run.call_args_list[1].args[0]
        self.assertIn("--active-source", command)

    def test_cec_event_prefers_browser_remote_action_and_consumes(self) -> None:
        event = tvmed_cec_bridge.BridgeEvent(
            cec_key="select",
            cec_code="0x00",
            action="SELECT",
            x_key="Return",
        )

        with mock.patch("tvmed_device_api.find_kiosk_ws_url", return_value="ws://127.0.0.1/devtools/page/1"), \
             mock.patch("tvmed_device_api.websocket_eval", return_value={"result": {"result": {"value": True}}}) as websocket_eval:
            consumed = tvmed_cec_bridge.emit_browser_remote_event(event, dry_run=False)

        self.assertTrue(consumed)
        expression = websocket_eval.call_args.args[1]
        self.assertIn("window.tvmedKiosk.remoteAction", expression)
        self.assertIn('"action": "SELECT"', expression)

    def test_input_bridge_maps_samsung_ok_to_select(self) -> None:
        self.assertEqual(tvmed_cec_input_bridge.ACTION_BY_KEY_CODE[352], "SELECT")


if __name__ == "__main__":
    unittest.main()
