#!/usr/bin/env bash
set -euo pipefail

# Launch the next-stage TVmed device browser UI. Unlike the raw smoke page,
# this UI keeps camera/mic off until the visible consent state is confirmed.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${TVMED_KVS_PORT:-8088}"
URL="http://127.0.0.1:${PORT}/web/device-kiosk.html?v=$(date +%s)"
LOG_DIR="${XDG_RUNTIME_DIR:-/tmp}/tvmed-device-kiosk"
mkdir -p "$LOG_DIR/chromium-profile"

if ! command -v chromium >/dev/null 2>&1; then
  echo "chromium is not installed. Install chromium xserver-xorg xinit first." >&2
  exit 1
fi
if ! command -v startx >/dev/null 2>&1; then
  echo "startx is not installed. Install xinit/xserver-xorg first." >&2
  exit 1
fi

cleanup() {
  [[ -n "${DEVICE_API_PID:-}" ]] && kill "$DEVICE_API_PID" >/dev/null 2>&1 || true
  [[ -n "${CEC_BRIDGE_PID:-}" ]] && kill "$CEC_BRIDGE_PID" >/dev/null 2>&1 || true
  [[ -n "${CEC_INPUT_BRIDGE_PID:-}" ]] && kill "$CEC_INPUT_BRIDGE_PID" >/dev/null 2>&1 || true
  [[ -n "${SERVER_PID:-}" ]] && kill "$SERVER_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT

cd "$ROOT"
./tvmed_kvs_browser_smoke.sh --role MASTER --port "$PORT" >"$LOG_DIR/server.log" 2>&1 &
SERVER_PID=$!

python3 - <<PY
import time, urllib.request, sys
url = "$URL"
for _ in range(50):
    try:
        urllib.request.urlopen(url, timeout=1).read(16)
        sys.exit(0)
    except Exception:
        time.sleep(0.2)
print("device kiosk web server did not become ready", file=sys.stderr)
sys.exit(1)
PY

CEC_ADAPTER="${TVMED_CEC_ADAPTER:-/dev/cec0}"
if [[ "${TVMED_ENABLE_CEC_BRIDGE:-1}" == "1" ]] && [[ -e "$CEC_ADAPTER" ]] && command -v cec-ctl >/dev/null 2>&1 && command -v xdotool >/dev/null 2>&1; then
  CEC_RECLAIM_INTERVAL="${TVMED_CEC_RECLAIM_INTERVAL:-0}"
  python3 "$ROOT/tvmed_cec_bridge.py" --no-sudo --adapter "$CEC_ADAPTER" --display :0 --reclaim-interval "$CEC_RECLAIM_INTERVAL" >"$LOG_DIR/cec-bridge.log" 2>&1 &
  CEC_BRIDGE_PID=$!
  python3 "$ROOT/tvmed_cec_input_bridge.py" >"$LOG_DIR/cec-input-bridge.log" 2>&1 &
  CEC_INPUT_BRIDGE_PID=$!
  echo "CEC remote bridge enabled: adapter=$CEC_ADAPTER pid=$CEC_BRIDGE_PID input_pid=$CEC_INPUT_BRIDGE_PID reclaim_interval=${CEC_RECLAIM_INTERVAL}s log=$LOG_DIR/cec-bridge.log input_log=$LOG_DIR/cec-input-bridge.log"
else
  echo "CEC remote bridge disabled or unavailable: adapter=$CEC_ADAPTER"
fi

if [[ "${TVMED_ENABLE_DEVICE_API:-1}" == "1" ]]; then
  python3 "$ROOT/tvmed_device_api.py" --bind "${TVMED_DEVICE_API_BIND:-0.0.0.0}" --port "${TVMED_DEVICE_API_PORT:-8091}" >"$LOG_DIR/device-api.log" 2>&1 &
  DEVICE_API_PID=$!
  echo "Device call trigger API enabled: pid=$DEVICE_API_PID url=http://${TVMED_DEVICE_API_HOST:-$(hostname -I | awk '{print $1}')}:${TVMED_DEVICE_API_PORT:-8091}/incoming log=$LOG_DIR/device-api.log"
else
  echo "Device call trigger API disabled."
fi

cat >"$LOG_DIR/xinitrc" <<EOF
#!/usr/bin/env bash
set -euo pipefail
xset -dpms
xset s off
xset s noblank
KIOSK_WIDTH="\${TVMED_KIOSK_WIDTH:-1920}"
KIOSK_HEIGHT="\${TVMED_KIOSK_HEIGHT:-1080}"
xrandr --output HDMI-2 --mode "\${KIOSK_WIDTH}x\${KIOSK_HEIGHT}" --rate 60 >/dev/null 2>&1 \
  || xrandr --output HDMI-1 --mode "\${KIOSK_WIDTH}x\${KIOSK_HEIGHT}" --rate 60 >/dev/null 2>&1 \
  || true
chromium \
  --remote-debugging-address=127.0.0.1 \
  --remote-debugging-port=9222 \
  --user-data-dir="$LOG_DIR/chromium-profile" \
  --kiosk \
  --start-fullscreen \
  --window-position=0,0 \
  --window-size="\${KIOSK_WIDTH},\${KIOSK_HEIGHT}" \
  --no-first-run \
  --disable-infobars \
  --autoplay-policy=no-user-gesture-required \
  --disable-features=WebRtcPipeWireCamera \
  --use-fake-ui-for-media-stream \
  --unsafely-treat-insecure-origin-as-secure=$URL \
  "$URL" >"$LOG_DIR/chromium.log" 2>&1 &
CHROMIUM_PID=\$!
for _ in {1..40}; do
  if command -v xdotool >/dev/null 2>&1; then
    WINDOW_ID="\$(xdotool search --onlyvisible --class chromium 2>/dev/null | head -1 || true)"
    if [[ -n "\$WINDOW_ID" ]]; then
      xdotool windowmove "\$WINDOW_ID" 0 0 windowsize "\$WINDOW_ID" "\$KIOSK_WIDTH" "\$KIOSK_HEIGHT" >/dev/null 2>&1 || true
    fi
  fi
  sleep 0.25
done
wait "\$CHROMIUM_PID"
EOF
chmod +x "$LOG_DIR/xinitrc"

echo "Launching TVmed device kiosk: $URL"
echo "Camera/mic stay off until the on-screen consent state is confirmed."
if DISPLAY=:0 xset q >/dev/null 2>&1; then
  echo "Using existing X display :0."
  export DISPLAY=:0
  exec "$LOG_DIR/xinitrc"
fi
exec startx "$LOG_DIR/xinitrc" -- :0
