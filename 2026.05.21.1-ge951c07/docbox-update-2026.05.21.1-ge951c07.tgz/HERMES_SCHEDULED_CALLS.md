# TVmed Scheduled Calls via Hermes Telegram

Goal: from Telegram, Graeme can ask Hermes something like:

```text
Setup Call to John Doe for 2.30pm
```

Hermes should create a one-shot scheduled job for **10 minutes before call time**. That job calls `scripts/tvmed_prepare_call.py`, which enqueues a cloud `prepare` command for the selected TVmed device.

## What happens at T-10 minutes

1. Hermes cron runs the prepare script.
2. doogle.bot stores a `prepare` command for the target device.
3. The Pi cloud poller receives it.
4. The Pi local device API sends HDMI-CEC:
   - TV on
   - active source / TVmed HDMI input
   - on Pi 5, both HDMI CEC adapters (`/dev/cec0`, `/dev/cec1`) are candidates; disconnected adapters report `f.f.f.f` and must not count as success
5. The browser kiosk shows a full-screen countdown clock.
6. Camera/mic remain OFF.
7. At call time, the kiosk enters the normal **Incoming call** flow.
8. Patient still must choose **Accept Call** then **Start call / Turn On Camera**.

## Device map

- `John Doe` → `gateway-host`
- `Dylan patient` → `dylan-pi5`

## Hermes cron pattern

For a call at `2026-05-14T14:30:00+01:00`, schedule the job for `2026-05-14T14:20:00+01:00`.

The cron job should run from the TVmed repo:

```bash
/Users/dv4studio/.openclaw/workspace/TVmed/scripts/tvmed_prepare_call.py \
  --device gateway-host \
  --patient-label "John Doe" \
  --caller-name "Graeme" \
  --call-time "2026-05-14T14:30:00+01:00"
```

For Dylan:

```bash
/Users/dv4studio/.openclaw/workspace/TVmed/scripts/tvmed_prepare_call.py \
  --device dylan-pi5 \
  --patient-label "Dylan patient" \
  --caller-name "Graeme" \
  --call-time "2026-05-14T14:30:00+01:00"
```

## Required prompt for autonomous Hermes cron creation

When Graeme asks from Telegram to schedule a TVmed call:

1. Parse patient label and call time.
2. Use current local timezone unless Graeme specifies another timezone.
3. Create a one-shot cron job for call time minus 10 minutes.
4. Use `no_agent=true` and `script` if possible, or a self-contained prompt that runs the exact command above.
5. Confirm back to Telegram with:
   - patient
   - call time
   - prepare/wake time

## Safety

- `prepare` never starts media.
- Camera/mic stay off until the patient consents on the TV.
- If the patient is already in a call, the kiosk ignores the countdown state and does not interrupt the call.
- The background CEC remote bridge must not periodically send `active-source` while idle; leave `TVMED_CEC_RECLAIM_INTERVAL=0` unless deliberately testing an operator-controlled reclaim flow.
- Do not put gate keys, AWS keys, or runtime tokens in this file or chat.
