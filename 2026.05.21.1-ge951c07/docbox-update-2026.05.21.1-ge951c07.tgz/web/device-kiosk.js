/* global AWS, KVSWebRTC, TVMED_KVS_CONFIG, TVMED_DEVICE_STATE */
'use strict';

const { DeviceKioskStateMachine } = TVMED_DEVICE_STATE;
const sm = new DeviceKioskStateMachine();

const el = (id) => document.getElementById(id);
const localView = el('localView');
const remoteClinicianView = el('remoteClinicianView');
const logEl = el('log');
const mediaStatus = el('mediaStatus');
const screenTitle = el('screenTitle');
const screenCopy = el('screenCopy');
const card = el('card');
const overlay = el('overlay');
const activeText = el('activeText');
const countdownEl = el('countdown');
const countdownLabelEl = el('countdownLabel');
const remoteConfigPanel = el('remoteConfigPanel');
const remoteConfigGrid = el('remoteConfigGrid');
const remoteLast = el('remoteLast');
const requestCallButton = el('requestCall');
const triageButton = el('triage');
const triagePanel = el('triagePanel');
const handPanel = el('handPanel');
const maintenanceMenu = el('maintenanceMenu');
const maintenanceStatus = el('maintenanceStatus');
const deviceInfo = el('deviceInfo');
const versionBadge = el('versionBadge');
const headerPrompt = el('headerPrompt');
const headerConfirmEnd = el('headerConfirmEnd');
const headerCancelEnd = el('headerCancelEnd');

const REMOTE_REQUIRED = [
  ['SELECT', 'OK / select'],
  ['UP', 'Up'],
  ['DOWN', 'Down'],
  ['LEFT', 'Left'],
  ['RIGHT', 'Right'],
  ['BACK', 'Back / return'],
];
const KEY_ACTION = {
  Enter: 'SELECT',
  ArrowUp: 'UP',
  ArrowDown: 'DOWN',
  ArrowLeft: 'LEFT',
  ArrowRight: 'RIGHT',
  Escape: 'BACK',
  Backspace: 'BACK',
};

let remoteConfigActive = false;
let remoteConfig = loadRemoteConfig();
let remoteConfigAutoFinishTimer = null;

let signalingClient = null;
let peerConnection = null;
let localStream = null;
let remoteClinicianStream = null;
let masterRemoteClientId = null;
let previousMediaAllowed = false;
let countdownTimer = null;
let countdownIncomingPending = false;
let assistanceAckTimer = null;
let requestCallSending = false;
let requestCallResetTimer = null;
let triageSending = false;
let triageResetTimer = null;
let triageActive = false;
let triageScreen = 'complaint';
let triageSession = null;
let triageStatusText = '';
let handTestMode = 'off';
let handTestStream = null;
let handTestHands = null;
let handTestRaf = null;
let handTestTimer = null;
let handTestStatusText = '';
let handTestReady = false;
let handFrameBusy = false;
let handLastFrameAt = 0;
let handLastActionAt = 0;
let appVersionLabel = 'dev';

function setVersionBadge(version = 'dev', name = 'dbox01') {
  appVersionLabel = String(version || 'dev').slice(0, 80);
  const deviceName = String(name || 'dbox01').slice(0, 80);
  if (versionBadge) versionBadge.textContent = `${deviceName} : ${appVersionLabel}`;
}

async function loadAppVersion() {
  try {
    const resp = await fetch(`./docbox-version.json?cb=${Date.now()}`, { cache: 'no-store' });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const body = await resp.json();
    const cfg = config();
    const deviceName = cfg.deviceDisplayName || cfg.deviceName || cfg.deviceAlias || body.deviceName || body.name || 'dbox01';
    setVersionBadge(body.version || 'dev', deviceName);
    log('Loaded Docbox version', { name: deviceName, version: appVersionLabel, gitSha: body.gitSha, channel: body.channel });
  } catch (err) {
    setVersionBadge('dev', 'dbox01');
    log('Docbox version file unavailable', { error: err.message });
  }
}
let handPinchDown = false;
let handOpenSince = 0;
let handReference = null;
let lastDirectionalFocusMove = { direction: null, targetId: null, at: 0 };
let lastDirectionalInput = { action: null, at: 0 };
let debugControlVisible = false;
const DIRECTION_REPEAT_GUARD_MS = 550;
const DIRECTION_INPUT_DEBOUNCE_MS = 500;
const HAND_TEST_TIMEOUT_MS = 120000;
const TRIAGE_API_ENDPOINT = 'https://doogle.bot/api/triage';
const TRIAGE_PATIENT_AGE = 75;
const TRIAGE_COMPLAINTS = [
  { id: 'chest', label: 'Chest pain or tightness' },
  { id: 'breathing', label: 'Breathing difficulty' },
  { id: 'fall', label: 'Fall or injury' },
  { id: 'confusion', label: 'Confusion or memory' },
  { id: 'pain', label: 'Pain somewhere' },
  { id: 'wound', label: 'Wound or skin' },
  { id: 'stomach', label: 'Stomach or digestive' },
  { id: 'urine', label: 'Urinary problem' },
  { id: 'mental', label: 'Feeling low or anxious' },
  { id: 'medication', label: 'Medication question' },
  { id: 'general', label: 'Generally unwell' },
  { id: 'other', label: 'Something else' },
];

function loadRemoteConfig() {
  try {
    return JSON.parse(localStorage.getItem('tvmedRemoteConfig') || '{}') || {};
  } catch (_) {
    return {};
  }
}

function saveRemoteConfig() {
  try {
    localStorage.setItem('tvmedRemoteConfig', JSON.stringify(remoteConfig));
  } catch (_) {}
}

function normalizeRemoteAction(input) {
  const value = String(input || '').trim().toUpperCase();
  if (['OK', 'ENTER', 'RETURN', 'SELECT'].includes(value)) return 'SELECT';
  if (['UP', 'ARROWUP'].includes(value)) return 'UP';
  if (['DOWN', 'ARROWDOWN'].includes(value)) return 'DOWN';
  if (['LEFT', 'ARROWLEFT'].includes(value)) return 'LEFT';
  if (['RIGHT', 'ARROWRIGHT'].includes(value)) return 'RIGHT';
  if (['BACK', 'EXIT', 'ESCAPE', 'BACKSPACE', 'RETURN_BACK'].includes(value)) return 'BACK';
  return value || 'UNKNOWN';
}

function describeRemoteEvent(detail) {
  const parts = [];
  if (detail.action) parts.push(normalizeRemoteAction(detail.action));
  if (detail.cecKey) parts.push(String(detail.cecKey));
  if (detail.cecCode) parts.push(String(detail.cecCode));
  if (detail.key) parts.push(String(detail.key));
  return parts.join(' · ') || 'unknown button';
}

function renderRemoteConfig() {
  remoteConfigPanel.classList.toggle('hidden', !remoteConfigActive);
  remoteConfigGrid.innerHTML = '';
  for (const [action, label] of REMOTE_REQUIRED) {
    const seen = remoteConfig[action];
    const item = document.createElement('div');
    item.className = `remote-key${seen ? ' seen' : ''}`;
    item.innerHTML = `${seen ? '✓' : '○'} ${label}<small>${seen ? describeRemoteEvent(seen) : 'not captured yet'}</small>`;
    remoteConfigGrid.appendChild(item);
  }
}

function startRemoteConfig() {
  remoteConfigActive = true;
  if (remoteConfigAutoFinishTimer) clearTimeout(remoteConfigAutoFinishTimer);
  remoteConfigAutoFinishTimer = null;
  remoteConfig = {};
  saveRemoteConfig();
  remoteLast.textContent = 'Waiting for first remote button…';
  screenTitle.textContent = 'Configure remote';
  screenCopy.textContent = 'Now press OK, arrows, and Back on the TV remote. Captured buttons turn green.';
  log('Remote config started');
  renderRemoteConfig();
}

function finishRemoteConfig() {
  if (remoteConfigAutoFinishTimer) clearTimeout(remoteConfigAutoFinishTimer);
  remoteConfigAutoFinishTimer = null;
  remoteConfigActive = false;
  saveRemoteConfig();
  log('Remote config finished', remoteConfig);
  render();
}

function captureRemoteButton(detail = {}) {
  if (!remoteConfigActive) return false;
  const action = normalizeRemoteAction(detail.action || detail.key || detail.cecKey);
  const eventDetail = { ...detail, action, at: new Date().toISOString() };
  if (REMOTE_REQUIRED.some(([required]) => required === action)) {
    remoteConfig[action] = eventDetail;
    saveRemoteConfig();
  }
  remoteLast.textContent = `Captured: ${describeRemoteEvent(eventDetail)}`;
  log('Remote button captured', eventDetail);
  renderRemoteConfig();
  const missing = REMOTE_REQUIRED.filter(([required]) => !remoteConfig[required]).map(([, label]) => label);
  if (missing.length) {
    screenTitle.textContent = 'Configure remote';
    screenCopy.textContent = `Still need: ${missing.join(', ')}`;
  } else {
    screenTitle.textContent = 'Remote configured';
    screenCopy.textContent = 'All core buttons captured. Returning to Ready…';
    remoteLast.textContent = 'All buttons captured ✓';
    if (!remoteConfigAutoFinishTimer) {
      remoteConfigAutoFinishTimer = setTimeout(() => finishRemoteConfig(), 900);
    }
  }
  return true;
}

function log(message, data) {
  const stamp = new Date().toISOString();
  const suffix = data === undefined ? '' : ` ${JSON.stringify(data)}`;
  logEl.textContent += `[${stamp}] ${message}${suffix}\n`;
  logEl.scrollTop = logEl.scrollHeight;
  console.log(`[TVmed] ${message}`, data || '');
}

function setMaintenanceStatus(text) {
  maintenanceStatus.textContent = text || '';
  if (text) setTimeout(() => {
    if (maintenanceStatus.textContent === text) maintenanceStatus.textContent = '';
  }, 4000);
}

function setDebugControlVisible(visible = !debugControlVisible) {
  debugControlVisible = Boolean(visible);
  logEl.classList.toggle('hidden', !debugControlVisible);
  deviceInfo.classList.toggle('hidden', !debugControlVisible);
  setMaintenanceStatus(debugControlVisible ? 'Debug Control shown' : 'Debug Control hidden');
  log('Debug Control toggled', {
    visible: debugControlVisible,
    state: sm.snapshot().state,
    activeElement: document.activeElement && document.activeElement.id,
  });
}

async function postLocalAction(path, payload, statusBusy, statusDone, logLabel) {
  const cfg = config();
  const url = `${String(cfg.localApiBase || 'http://127.0.0.1:8091').replace(/\/$/, '')}${path}`;
  setMaintenanceStatus(statusBusy);
  log(`${logLabel} requested`, { url });
  try {
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, source: 'kiosk-menu', at: new Date().toISOString() }),
    });
    const body = await resp.json().catch(() => ({}));
    if (!resp.ok || body.ok === false) throw new Error(body.error || `HTTP ${resp.status}`);
    setMaintenanceStatus(statusDone);
    log(`${logLabel} accepted`, body);
    return body;
  } catch (err) {
    setMaintenanceStatus(`${logLabel} failed`);
    log(`${logLabel} failed`, { error: err.message });
    return null;
  }
}

async function reclaimRemote() {
  return postLocalAction('/reclaim-remote', {}, 'Reclaiming TV remote…', 'TV remote re-claimed', 'Reclaim TV remote');
}

async function restartPi() {
  return postLocalAction('/reboot', {}, 'Restarting Pi…', 'Pi reboot queued…', 'Restart Pi');
}

async function wifiConfig() {
  return postLocalAction('/wifi-config', {}, 'Opening WiFi Config…', 'WiFi Config opened', 'WiFi Config');
}

async function wifiLogin() {
  return postLocalAction('/wifi-login', {}, 'Opening Browser WiFi Login…', 'Browser WiFi Login opened', 'Browser WiFi Login');
}

async function updateDocbox() {
  const result = await postLocalAction('/update', {}, 'Updating Docbox…', 'Docbox updated', 'Update Docbox');
  if (result && result.output) {
    log('Update Docbox output', { output: result.output });
  }
  return result;
}

function loadScriptOnce(src) {
  if ([...document.scripts].some((script) => script.src === src)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`Could not load ${src}`));
    document.head.appendChild(script);
  });
}

async function loadMediaPipeHands() {
  if (window.Hands) return;
  await loadScriptOnce('https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js');
  if (!window.Hands) throw new Error('MediaPipe Hands did not load.');
}

function setHandStatus(text) {
  handTestStatusText = text || '';
  const status = handPanel && handPanel.querySelector('.hand-status');
  if (handTestMode === 'active' && status) {
    status.textContent = handTestStatusText;
  } else {
    renderHandPanel();
  }
}

function startHandTestConfirm() {
  if (sm.snapshot().state !== 'idle' || triageActive || remoteConfigActive) {
    setMaintenanceStatus('Hand Test only works from Ready');
    return;
  }
  handTestMode = 'confirm';
  handTestStatusText = '';
  render();
}

function stopHandTest(reason = 'Hand Test stopped') {
  if (handTestRaf) cancelAnimationFrame(handTestRaf);
  handTestRaf = null;
  if (handTestTimer) clearTimeout(handTestTimer);
  handTestTimer = null;
  if (handTestStream) { for (const track of handTestStream.getTracks()) track.stop(); }
  handTestStream = null;
  if (handTestHands) { try { handTestHands.close(); } catch (_) {} }
  handTestHands = null;
  handTestReady = false;
  handFrameBusy = false;
  handLastFrameAt = 0;
  handPinchDown = false;
  handOpenSince = 0;
  handReference = null;
  if (handTestMode !== 'off') log(reason);
  handTestMode = 'off';
  handTestStatusText = '';
  if (!sm.snapshot().mediaAllowed) {
    localView.srcObject = null;
    localView.classList.add('hidden');
  }
  render();
}

async function startHandTest() {
  if (sm.snapshot().state !== 'idle' || triageActive || remoteConfigActive) {
    setHandStatus('Hand Test only works from Ready.');
    return;
  }
  handTestMode = 'active';
  handTestReady = false;
  handReference = null;
  setHandStatus('Starting camera and loading hand tracking…');
  render();
  try {
    await loadMediaPipeHands();
    handTestStream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 15 } },
      audio: false,
    });
    localView.srcObject = handTestStream;
    localView.classList.remove('hidden');
    await localView.play().catch((err) => log('Hand Test preview play warning', { message: err.message }));
    handTestHands = new window.Hands({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
    });
    handTestHands.setOptions({ maxNumHands: 1, modelComplexity: 0, minDetectionConfidence: 0.65, minTrackingConfidence: 0.55 });
    handTestHands.onResults(onHandResults);
    handTestTimer = setTimeout(() => stopHandTest('Hand Test timed out'), HAND_TEST_TIMEOUT_MS);
    setHandStatus('Camera ON — show one hand to test gestures.');
    handLoop();
  } catch (err) {
    setHandStatus(`Hand Test failed: ${err.message}`);
    log('Hand Test failed', { error: err.message });
    stopHandTest('Hand Test failed');
  }
}

function handLoop() {
  if (handTestMode !== 'active' || !handTestHands || !localView.srcObject) return;
  const now = performance.now();
  if (!handFrameBusy && localView.readyState >= 2 && now - handLastFrameAt > 180) {
    handFrameBusy = true;
    handLastFrameAt = now;
    handTestHands.send({ image: localView }).catch((err) => {
      log('MediaPipe hand frame failed', { error: err.message });
    }).finally(() => { handFrameBusy = false; });
  }
  handTestRaf = requestAnimationFrame(handLoop);
}

function dist(a, b) {
  return Math.hypot((a.x || 0) - (b.x || 0), (a.y || 0) - (b.y || 0));
}

function fingerExtended(landmarks, tip, pip) {
  return landmarks[tip].y < landmarks[pip].y - 0.025;
}

function handCenter(landmarks) {
  const palm = [0, 5, 9, 13, 17].map((i) => landmarks[i]);
  return {
    x: palm.reduce((sum, p) => sum + p.x, 0) / palm.length,
    y: palm.reduce((sum, p) => sum + p.y, 0) / palm.length,
  };
}

function handAction(action, label) {
  const now = Date.now();
  if (now - handLastActionAt < 650) return;
  handLastActionAt = now;
  setHandStatus(`Gesture: ${label}`);
  handleRemoteAction(action);
}

function onHandResults(results) {
  if (handTestMode !== 'active') return;
  const landmarks = results.multiHandLandmarks && results.multiHandLandmarks[0];
  if (!landmarks) {
    handTestReady = false;
    handReference = null;
    handOpenSince = 0;
    setHandStatus('No hand detected. Camera may be turned away.');
    return;
  }
  const center = handCenter(landmarks);
  const pinch = dist(landmarks[4], landmarks[8]) < 0.055;

  if (!handTestReady || !handReference) {
    handTestReady = true;
    handReference = center;
    setHandStatus('Hand detected. Move hand for arrows, pinch thumb/index to click.');
    return;
  }

  if (pinch && !handPinchDown) {
    handPinchDown = true;
    handAction('SELECT', 'Click');
    handReference = center;
    return;
  }
  if (!pinch) handPinchDown = false;

  const dx = center.x - handReference.x;
  const dy = center.y - handReference.y;
  if (Math.abs(dx) > 0.13 || Math.abs(dy) > 0.13) {
    if (Math.abs(dx) > Math.abs(dy)) handAction(dx > 0 ? 'RIGHT' : 'LEFT', dx > 0 ? 'Right' : 'Left');
    else handAction(dy > 0 ? 'DOWN' : 'UP', dy > 0 ? 'Down' : 'Up');
    handReference = center;
  } else if (Date.now() - handLastActionAt > 1000) {
    setHandStatus('Hand detected. Move hand for arrows, pinch thumb/index for OK. Use Stop Test button to exit.');
  }
}

function renderHandPanel() {
  if (handTestMode === 'off') {
    handPanel.classList.add('hidden');
    handPanel.innerHTML = '';
    return;
  }
  handPanel.classList.remove('hidden');
  if (handTestMode === 'confirm') {
    handPanel.innerHTML = `<div class="hand-instructions"><strong>Hand Test turns on the camera.</strong><br>Use this only while testing gesture navigation. Camera/mic are not connected to a call.</div><div class="hand-gestures"><div class="hand-gesture">Move hand left/right/up/down = arrows</div><div class="hand-gesture">Tap thumb + forefinger = OK</div><div class="hand-gesture">Use Stop Test to exit</div></div><div class="hand-controls"><button id="handStart" class="primary">Start Hand Test</button><button id="handCancel" class="secondary">Cancel</button></div><div class="hand-status">${escapeHtml(handTestStatusText)}</div>`;
    el('handStart').addEventListener('click', startHandTest);
    el('handCancel').addEventListener('click', () => stopHandTest('Hand Test cancelled'));
  } else {
    handPanel.innerHTML = `<div class="hand-instructions"><strong>Camera ON — Hand Test</strong><br>Move hand for arrows. Tap thumb/forefinger for OK. Use Stop Test to exit. Auto-stops after 2 minutes.</div><div class="hand-dpad" aria-label="Hand gesture direction test"><button id="handUp" class="secondary" type="button">↑</button><button id="handLeft" class="secondary" type="button">←</button><button id="handOk" class="primary" type="button">OK</button><button id="handRight" class="secondary" type="button">→</button><button id="handDown" class="secondary" type="button">↓</button></div><div class="hand-status">${escapeHtml(handTestStatusText || 'Waiting for hand…')}</div><div class="hand-controls"><button id="handStop" class="danger">Stop Test</button></div>`;
    [['handUp', 'UP', 'Up'], ['handLeft', 'LEFT', 'Left'], ['handOk', 'SELECT', 'OK'], ['handRight', 'RIGHT', 'Right'], ['handDown', 'DOWN', 'Down']].forEach(([id, action, label]) => {
      el(id).addEventListener('click', () => {
        if (id === 'handOk') setHandStatus('OK clicked');
        else handAction(action, label);
      });
    });
    el('handStop').addEventListener('click', () => stopHandTest('Hand Test stopped'));
    if (!handPanel.contains(document.activeElement)) setTimeout(() => el('handOk') && el('handOk').focus(), 0);
  }
}

function handleMaintenanceMenuSelection(action) {
  if (!action) return;
  const labels = { configRemote: 'Config remote', wifiConfig: 'WiFi Config', wifiLogin: 'Browser WiFi Login', handTest: 'Hand Test', debugControl: 'Debug Control', reclaimRemote: 'Reclaim TV remote', update: 'Update', restart: 'Restart', restartPi: 'Restart Pi', exit: 'Exit' };
  log('Mouse maintenance menu selected', { action });
  if (action === 'configRemote') {
    maintenanceMenu.value = '';
    startRemoteConfig();
    return;
  }
  if (action === 'debugControl') {
    setDebugControlVisible();
  } else if (action === 'wifiConfig') {
    wifiConfig();
  } else if (action === 'wifiLogin') {
    wifiLogin();
  } else if (action === 'handTest') {
    startHandTestConfirm();
  } else if (action === 'reclaimRemote') {
    reclaimRemote();
  } else if (action === 'restartPi') {
    restartPi();
  } else if (action === 'restart') {
    setMaintenanceStatus('Restarting page…');
    setTimeout(() => window.location.reload(), 450);
  } else if (action === 'update') {
    updateDocbox();
  } else if (action === 'exit') {
    setMaintenanceStatus('Exit selected');
  } else {
    setMaintenanceStatus(`${labels[action] || 'Menu'} selected`);
  }
  maintenanceMenu.value = '';
}

function config() {
  const cfg = window.TVMED_KVS_CONFIG || {};
  return {
    role: 'MASTER',
    region: cfg.region || 'eu-west-1',
    channelName: cfg.channelName || 'tvmed-gateway-host',
    clientId: cfg.clientId || 'gateway-host',
    patientLabel: cfg.patientLabel || 'John Doe',
    localApiBase: cfg.localApiBase || 'http://127.0.0.1:8091',
    accessKeyId: cfg.accessKeyId,
    secretAccessKey: cfg.secretAccessKey,
    sessionToken: cfg.sessionToken || '',
  };
}

function endpointByProtocol(endpoints, protocol) {
  const item = endpoints.find((e) => e.Protocol === protocol);
  if (!item) throw new Error(`KVS endpoint missing protocol ${protocol}`);
  return item.ResourceEndpoint;
}

async function getChannelArn(kinesisVideo, channelName) {
  const desc = await kinesisVideo.describeSignalingChannel({ ChannelName: channelName }).promise();
  const info = desc.ChannelInfo || {};
  if (info.ChannelStatus !== 'ACTIVE') throw new Error(`Channel is ${info.ChannelStatus || 'unknown'}, not ACTIVE`);
  return info.ChannelARN;
}

async function startMasterMedia() {
  stopMasterMedia();
  const cfg = config();
  if (!cfg.accessKeyId || !cfg.secretAccessKey) throw new Error('Device AWS credentials missing.');

  AWS.config.update({
    region: cfg.region,
    credentials: new AWS.Credentials({
      accessKeyId: cfg.accessKeyId,
      secretAccessKey: cfg.secretAccessKey,
      sessionToken: cfg.sessionToken || undefined,
    }),
  });

  log(`Starting consented MASTER on ${cfg.channelName}/${cfg.region}`);
  const kinesisVideo = new AWS.KinesisVideo({ region: cfg.region });
  const channelARN = await getChannelArn(kinesisVideo, cfg.channelName);

  const endpointResp = await kinesisVideo.getSignalingChannelEndpoint({
    ChannelARN: channelARN,
    SingleMasterChannelEndpointConfiguration: { Protocols: ['WSS', 'HTTPS'], Role: 'MASTER' },
  }).promise();
  const endpoints = endpointResp.ResourceEndpointList || [];
  const wssEndpoint = endpointByProtocol(endpoints, 'WSS');
  const httpsEndpoint = endpointByProtocol(endpoints, 'HTTPS');

  const signaling = new AWS.KinesisVideoSignalingChannels({ region: cfg.region, endpoint: httpsEndpoint });
  const iceResp = await signaling.getIceServerConfig({ ChannelARN: channelARN }).promise();
  const iceServers = [
    { urls: `stun:stun.kinesisvideo.${cfg.region}.amazonaws.com:443` },
    ...(iceResp.IceServerList || []).map((server) => ({
      urls: server.Uris,
      username: server.Username,
      credential: server.Password,
    })),
  ];

  peerConnection = new RTCPeerConnection({ iceServers, iceTransportPolicy: 'all' });
  peerConnection.addEventListener('icecandidate', ({ candidate }) => {
    if (!candidate || !signalingClient || !masterRemoteClientId) return;
    signalingClient.sendIceCandidate(candidate, masterRemoteClientId);
    log('Sent ICE candidate');
  });
  peerConnection.addEventListener('track', async (event) => {
    if (!remoteClinicianStream) {
      remoteClinicianStream = new MediaStream();
      remoteClinicianView.srcObject = remoteClinicianStream;
    }
    remoteClinicianStream.addTrack(event.track);
    log('Received clinician track', { kind: event.track.kind });
    render();
    await remoteClinicianView.play().catch((err) => log('Remote clinician play warning', { message: err.message }));
  });
  peerConnection.addEventListener('connectionstatechange', () => {
    const state = peerConnection.connectionState;
    log(`Peer state: ${state}`);
    if (state === 'connected') dispatch('mediaConnected');
    if (state === 'failed') dispatch('fault', { message: 'Video connection failed' });
  });
  peerConnection.addEventListener('iceconnectionstatechange', () => log(`ICE state: ${peerConnection.iceConnectionState}`));

  localStream = await navigator.mediaDevices.getUserMedia({
    video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    },
  });
  log('Local media acquired', {
    videoTracks: localStream.getVideoTracks().map((track) => track.label),
    audioTracks: localStream.getAudioTracks().map((track) => track.label),
  });
  localView.srcObject = localStream;
  await localView.play().catch((err) => log('Local preview play warning', { message: err.message }));
  for (const track of localStream.getTracks()) peerConnection.addTrack(track, localStream);
  log('Local media started after consent', localStream.getTracks().map((t) => `${t.kind}:${t.label || '(no label)'}`));

  signalingClient = new KVSWebRTC.SignalingClient({
    channelARN,
    channelEndpoint: wssEndpoint,
    role: KVSWebRTC.Role.MASTER,
    region: cfg.region,
    credentials: AWS.config.credentials,
    systemClockOffset: kinesisVideo.config.systemClockOffset,
  });

  signalingClient.on('open', () => log('Signaling open'));
  signalingClient.on('sdpOffer', async (offer, remoteClientId) => {
    masterRemoteClientId = remoteClientId;
    log('Received viewer SDP offer', { remoteClientId });
    await peerConnection.setRemoteDescription(offer);
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    signalingClient.sendSdpAnswer(peerConnection.localDescription, remoteClientId);
    log('Sent SDP answer');
  });
  signalingClient.on('iceCandidate', async (candidate) => {
    await peerConnection.addIceCandidate(candidate);
    log('Received ICE candidate');
  });
  signalingClient.on('close', () => log('Signaling closed'));
  signalingClient.on('error', (err) => dispatch('fault', { message: `Signaling error: ${err && err.message ? err.message : err}` }));
  signalingClient.open();
}

function stopMasterMedia() {
  masterRemoteClientId = null;
  if (signalingClient) { try { signalingClient.close(); } catch (_) {} signalingClient = null; }
  if (peerConnection) { try { peerConnection.close(); } catch (_) {} peerConnection = null; }
  if (localStream) { for (const track of localStream.getTracks()) track.stop(); localStream = null; }
  if (remoteClinicianStream) { for (const track of remoteClinicianStream.getTracks()) track.stop(); remoteClinicianStream = null; }
  localView.srcObject = null;
  remoteClinicianView.srcObject = null;
  remoteClinicianView.classList.add('hidden');
}

async function sendAssistanceAlert() {
  const cfg = config();
  const snap = sm.snapshot();
  const payload = {
    patientLabel: cfg.patientLabel || 'Patient',
    deviceId: cfg.clientId || 'device',
    callerName: snap.callerName || 'Clinician',
    reason: 'Patient declined a TVmed call, answered not OK, and requested assistance.',
    at: new Date().toISOString(),
  };
  const url = `${String(cfg.localApiBase || 'http://127.0.0.1:8091').replace(/\/$/, '')}/assistance`;
  log('Sending assistance alert', { url, patientLabel: payload.patientLabel });
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const body = await resp.json().catch(() => ({}));
  if (!resp.ok || body.ok === false) throw new Error(body.error || `Assistance alert failed: HTTP ${resp.status}`);
  log('Assistance alert sent', body);
  return body;
}

function doctorNameForRequest(snap) {
  return snap.callerName || (snap.scheduledCall && snap.scheduledCall.callerName) || 'Dr Murphy';
}

async function sendPatientRequest({
  button,
  busyFlag,
  setBusyFlag,
  resetTimer,
  setResetTimer,
  requestingText,
  sentText,
  failedText,
  resetText,
  reason,
  logLabel,
}) {
  if (busyFlag()) return;
  setBusyFlag(true);
  button.disabled = true;
  button.textContent = requestingText;
  const cfg = config();
  const snap = sm.snapshot();
  const payload = {
    patientLabel: cfg.patientLabel || 'Patient',
    deviceId: cfg.clientId || 'device',
    callerName: doctorNameForRequest(snap),
    reason,
    at: new Date().toISOString(),
  };
  const url = `${String(cfg.localApiBase || 'http://127.0.0.1:8091').replace(/\/$/, '')}/request-call`;
  try {
    log(`Sending ${logLabel}`, { url, patientLabel: payload.patientLabel });
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const body = await resp.json().catch(() => ({}));
    if (!resp.ok || body.ok === false) throw new Error(body.error || `${logLabel} failed: HTTP ${resp.status}`);
    log(`${logLabel} sent`, body);
    button.textContent = sentText;
  } catch (err) {
    log(`${logLabel} failed`, { message: err.message });
    button.textContent = failedText;
  } finally {
    if (resetTimer()) clearTimeout(resetTimer());
    setResetTimer(setTimeout(() => {
      setBusyFlag(false);
      button.disabled = false;
      button.textContent = resetText;
    }, 3000));
  }
}

async function requestCall() {
  return sendPatientRequest({
    button: requestCallButton,
    busyFlag: () => requestCallSending,
    setBusyFlag: (value) => { requestCallSending = value; },
    resetTimer: () => requestCallResetTimer,
    setResetTimer: (value) => { requestCallResetTimer = value; },
    requestingText: 'Requesting…',
    sentText: 'Request sent',
    failedText: 'Request failed',
    resetText: 'Request call',
    reason: 'Patient requested a Doctor from the docbox.tv kiosk.',
    logLabel: 'call request',
  });
}

function triageApiPayload(action, extra = {}) {
  return {
    action,
    age: TRIAGE_PATIENT_AGE,
    patientLabel: config().patientLabel || 'Patient',
    deviceId: config().clientId || 'device',
    ...extra,
  };
}

function renderTriagePanel() {
  if (!triageActive) {
    triagePanel.classList.add('hidden');
    triagePanel.innerHTML = '';
    return;
  }
  triagePanel.classList.remove('hidden');
  if (triageScreen === 'complaint') {
    triagePanel.innerHTML = `<div class="triage-grid">${TRIAGE_COMPLAINTS.map((item) => `<button class="triage-choice secondary" data-complaint="${item.id}">${item.label}</button>`).join('')}</div><div class="triage-status">Press Back to return to Ready.</div>`;
    triagePanel.querySelectorAll('[data-complaint]').forEach((button) => {
      button.addEventListener('click', () => startQuickCheckComplaint(button.dataset.complaint));
    });
  } else if (triageScreen === 'thinking') {
    triagePanel.innerHTML = `<div class="triage-message">Reviewing your answers…</div><div class="triage-status">${triageStatusText || 'Please wait.'}</div>`;
  } else if (triageScreen === 'question') {
    const questionNum = Math.max(1, Number(triageSession && triageSession.question_num) || 1);
    const pct = Math.min((questionNum / 8) * 100, 87);
    const question = (triageSession && triageSession.question) || 'Are you feeling unwell?';
    triagePanel.innerHTML = `<div class="triage-progress"><div class="triage-progress-fill" style="width:${pct}%"></div></div><div class="triage-message">${escapeHtml(question)}</div><div class="triage-answers"><button id="triageYes" class="primary">Yes</button><button id="triageNo" class="secondary">No</button></div><div class="triage-status">Question ${questionNum} of 8 · Press Back to stop.</div>`;
    el('triageYes').addEventListener('click', () => submitQuickCheckAnswer('Yes'));
    el('triageNo').addEventListener('click', () => submitQuickCheckAnswer('No'));
  } else if (triageScreen === 'result') {
    const result = triageSession || {};
    const isEmergency = result.urgency === 'emergency';
    const copy = isEmergency
      ? 'Standby and we’ll get a doctor to call you'
      : 'We have notified a Doctor about your symptoms.';
    triagePanel.innerHTML = `<div class="triage-message"><strong>${escapeHtml(copy)}</strong></div><div class="triage-answers"><button id="triageDone" class="primary">Done</button><button id="triageAgain" class="secondary">Start Again</button></div>`;
    el('triageDone').addEventListener('click', stopQuickCheck);
    el('triageAgain').addEventListener('click', startQuickCheck);
  } else if (triageScreen === 'error') {
    triagePanel.innerHTML = `<div class="triage-message">Quick Check could not connect. Please use Request call.</div><div class="triage-status">${escapeHtml(triageStatusText || '')}</div><div class="triage-answers"><button id="triageClose" class="primary">Back to Ready</button></div>`;
    el('triageClose').addEventListener('click', stopQuickCheck);
  }
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

function setQuickCheckScreen(screen, status = '') {
  triageScreen = screen;
  triageStatusText = status;
  render();
}

function startQuickCheck() {
  triageActive = true;
  triageSession = null;
  triageButton.textContent = 'Quick Check';
  setQuickCheckScreen('complaint');
  log('Quick Check started');
}

function stopQuickCheck() {
  triageActive = false;
  triageSession = null;
  triageStatusText = '';
  render();
  log('Quick Check closed');
}

async function startQuickCheckComplaint(complaint) {
  setQuickCheckScreen('thinking', 'Starting Quick Check…');
  try {
    const resp = await fetch(TRIAGE_API_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(triageApiPayload('start', { complaint })),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || data.error) throw new Error(data.error || `HTTP ${resp.status}`);
    triageSession = data;
    setQuickCheckScreen(data.should_stop ? 'result' : 'question');
  } catch (err) {
    log('Quick Check start failed', { error: err.message });
    setQuickCheckScreen('error', err.message);
  }
}

async function submitQuickCheckAnswer(answer) {
  if (!triageSession) return;
  setQuickCheckScreen('thinking', 'Checking your answer…');
  try {
    const resp = await fetch(TRIAGE_API_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(triageApiPayload('answer', {
        answer,
        sessionId: triageSession.sessionId,
        history: triageSession.history || [],
      })),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || data.error) throw new Error(data.error || `HTTP ${resp.status}`);
    triageSession = { ...triageSession, ...data };
    if (data.should_stop) {
      await sendQuickCheckResult(triageSession);
      setQuickCheckScreen('result', 'Doctor alert sent.');
    } else {
      setQuickCheckScreen('question');
    }
  } catch (err) {
    log('Quick Check answer failed', { error: err.message });
    setQuickCheckScreen('error', err.message);
  }
}

async function sendQuickCheckResult(result) {
  const cfg = config();
  const reasonParts = [
    result.urgency === 'emergency' ? 'URGENT Quick Check completed on docbox.tv kiosk.' : 'Quick Check completed on docbox.tv kiosk.',
    result.presenting_complaint ? `Concern: ${result.presenting_complaint}.` : '',
    result.urgency ? `Urgency: ${result.urgency}.` : '',
    result.specialty ? `Suggested area: ${result.specialty}.` : '',
    result.clinician_summary ? `Summary: ${result.clinician_summary}` : '',
    Array.isArray(result.red_flags) && result.red_flags.length ? `Red flags: ${result.red_flags.join(', ')}.` : '',
  ].filter(Boolean);
  const payload = {
    patientLabel: cfg.patientLabel || 'Patient',
    deviceId: cfg.clientId || 'device',
    callerName: doctorNameForRequest(sm.snapshot()),
    reason: reasonParts.join(' '),
    at: new Date().toISOString(),
    triage: {
      urgency: result.urgency,
      specialty: result.specialty,
      presenting_complaint: result.presenting_complaint,
      key_symptoms: result.key_symptoms,
      red_flags: result.red_flags,
    },
  };
  const url = `${String(cfg.localApiBase || 'http://127.0.0.1:8091').replace(/\/$/, '')}/request-call`;
  log('Sending Quick Check result', { url, urgency: result.urgency });
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const body = await resp.json().catch(() => ({}));
  if (!resp.ok || body.ok === false) throw new Error(body.error || `Quick Check alert failed: HTTP ${resp.status}`);
  log('Quick Check result sent', body);
}

function requestTriage() {
  startQuickCheck();
}

function visibleActionButtons() {
  return Array.from(document.querySelectorAll('button')).filter((button) => {
    if (button.disabled || button.classList.contains('hidden')) return false;
    return getComputedStyle(button).display !== 'none' && getComputedStyle(button).visibility !== 'hidden';
  });
}

function focusFirstVisibleButton() {
  const buttons = visibleActionButtons();
  if (!buttons.length) return;
  const state = sm.snapshot().state;
  // Welfare prompts are safety-critical: each new question should default to Yes.
  // Otherwise choosing "No" on the first question leaves focus on the reused No
  // button, so a repeated/next OK press can immediately answer No again and return
  // to Ready before the patient has a chance to request assistance.
  if (['declined_ok_check', 'declined_assistance_check'].includes(state)) {
    el('accept').focus();
    return;
  }
  if (triageActive) {
    if (buttons.includes(document.activeElement)) return;
    buttons[0].focus();
    return;
  }
  if (handTestMode !== 'off') {
    if (buttons.includes(document.activeElement)) return;
    buttons[0].focus();
    return;
  }
  if (buttons.includes(document.activeElement)) return;
  if (state === 'idle' && !remoteConfigActive) {
    const preferred = el('simulateIncoming');
    if (buttons.includes(preferred)) {
      preferred.focus();
      return;
    }
  }
  buttons[0].focus();
}

function buttonCenter(button) {
  const rect = button.getBoundingClientRect();
  return {
    x: rect.left + rect.width / 2,
    y: rect.top + rect.height / 2,
  };
}

function focusIdleButtonInDirection(direction, buttons) {
  if (sm.snapshot().state !== 'idle' || remoteConfigActive || triageActive || handTestMode !== 'off') return false;
  const currentId = document.activeElement && document.activeElement.id;
  const nav = {
    simulateIncoming: { UP: 'requestCall' },
    requestCall: { UP: 'triage', DOWN: 'simulateIncoming' },
    triage: { DOWN: 'requestCall' },
  };
  const targetId = nav[currentId] && nav[currentId][direction];
  if (!targetId) return true;
  const target = el(targetId);
  if (!buttons.includes(target)) return true;
  target.focus();
  lastDirectionalFocusMove = { direction, targetId, at: Date.now() };
  return true;
}

function focusButtonInDirection(direction) {
  const now = Date.now();
  if (
    lastDirectionalInput.action === direction
    && now - lastDirectionalInput.at < DIRECTION_INPUT_DEBOUNCE_MS
  ) {
    log('Remote direction ignored as duplicate', { direction, msSinceLast: now - lastDirectionalInput.at });
    return;
  }
  lastDirectionalInput = { action: direction, at: now };

  const buttons = visibleActionButtons();
  if (!buttons.length) return;
  if (!buttons.includes(document.activeElement)) {
    focusFirstVisibleButton();
    return;
  }

  const beforeId = document.activeElement && document.activeElement.id;
  if (
    lastDirectionalFocusMove.direction === direction
    && lastDirectionalFocusMove.targetId === beforeId
    && now - lastDirectionalFocusMove.at < DIRECTION_REPEAT_GUARD_MS
  ) {
    return;
  }

  if (focusIdleButtonInDirection(direction, buttons)) return;

  const currentButton = document.activeElement;
  const current = buttonCenter(currentButton);
  const candidates = buttons
    .filter((button) => button !== currentButton)
    .map((button) => {
      const center = buttonCenter(button);
      const dx = center.x - current.x;
      const dy = center.y - current.y;
      let major;
      let cross;
      if (direction === 'LEFT') { major = -dx; cross = Math.abs(dy); }
      else if (direction === 'RIGHT') { major = dx; cross = Math.abs(dy); }
      else if (direction === 'UP') { major = -dy; cross = Math.abs(dx); }
      else { major = dy; cross = Math.abs(dx); }
      if (major <= 8) return null;
      return { button, major, cross, distance: Math.hypot(dx, dy) };
    })
    .filter(Boolean)
    .sort((a, b) => {
      const aOnAxis = a.cross <= Math.max(80, a.major * 0.75);
      const bOnAxis = b.cross <= Math.max(80, b.major * 0.75);
      if (aOnAxis !== bOnAxis) return aOnAxis ? -1 : 1;
      return (a.cross * 3 + a.major + a.distance * 0.15) - (b.cross * 3 + b.major + b.distance * 0.15);
    });

  if (candidates.length) candidates[0].button.focus();

  const afterId = document.activeElement && document.activeElement.id;
  if (afterId && afterId !== beforeId) {
    lastDirectionalFocusMove = { direction, targetId: afterId, at: Date.now() };
  }
}

function activateFocusedOrDefault() {
  if (document.activeElement && document.activeElement.tagName === 'BUTTON' && !document.activeElement.classList.contains('hidden')) {
    document.activeElement.click();
    return;
  }
  const state = sm.snapshot().state;
  if (triageActive) {
    focusFirstVisibleButton();
    return;
  }
  if (handTestMode !== 'off') {
    focusFirstVisibleButton();
    return;
  }
  if (['incoming', 'consent', 'declined_ok_check', 'declined_assistance_check'].includes(state)) el('accept').click();
  else if (state === 'end_confirm') headerConfirmEnd.click();
  else focusFirstVisibleButton();
}

function backOrDeclineDefault() {
  const state = sm.snapshot().state;
  if (triageActive) {
    stopQuickCheck();
    return;
  }
  if (handTestMode !== 'off') {
    stopHandTest('Hand Test stopped by Back');
    return;
  }
  if (['incoming', 'consent', 'declined_ok_check', 'declined_assistance_check'].includes(state)) el('decline').click();
  else if (['connecting', 'active'].includes(state)) headerConfirmEnd.click();
  else if (state === 'end_confirm') headerCancelEnd.click();
}

function handleRemoteAction(detail) {
  const action = typeof detail === 'string' ? detail : (detail && detail.action);
  log('Remote action received', {
    action,
    detail,
    state: sm.snapshot().state,
    activeElement: document.activeElement && document.activeElement.id,
  });
  let consumed = true;
  if (remoteConfigActive) {
    return captureRemoteButton(typeof detail === 'object' ? detail : { action, source: 'browser' });
  }
  if (['UP', 'LEFT'].includes(action)) focusButtonInDirection(action);
  else if (['DOWN', 'RIGHT'].includes(action)) focusButtonInDirection(action);
  else if (action === 'SELECT') activateFocusedOrDefault();
  else if (action === 'BACK') backOrDeclineDefault();
  else consumed = false;
  log('Remote action handled', {
    action,
    consumed,
    activeElement: document.activeElement && document.activeElement.id,
  });
  return consumed;
}

function setButton(id, visible, text) {
  const button = el(id);
  button.classList.toggle('hidden', !visible);
  if (text) button.textContent = text;
}

function formatCountdown(ms) {
  const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function formatCallTime(timestamp) {
  return new Date(timestamp).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function renderCountdown(snap) {
  const scheduled = snap.state === 'idle' ? snap.scheduledCall : null;
  if (!scheduled) {
    countdownEl.classList.add('hidden');
    countdownLabelEl.classList.add('hidden');
    if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
    countdownIncomingPending = false;
    return false;
  }
  const remaining = scheduled.callTime - Date.now();
  countdownEl.textContent = formatCountdown(remaining);
  countdownLabelEl.textContent = `Call time ${formatCallTime(scheduled.callTime)} · camera/mic still off`;
  countdownEl.classList.remove('hidden');
  countdownLabelEl.classList.remove('hidden');
  if (remaining <= 0) {
    if (!countdownIncomingPending) {
      countdownIncomingPending = true;
      if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
      log('Scheduled call due; switching to Incoming Call screen');
      dispatch('incoming', { callerName: scheduled.callerName || 'Clinician' });
      countdownIncomingPending = false;
    }
    return false;
  }
  if (!countdownTimer) countdownTimer = setInterval(render, 1000);
  return true;
}

function render() {
  const snap = sm.snapshot();
  const handTestActive = handTestMode === 'active';
  mediaStatus.textContent = snap.mediaAllowed ? 'CAMERA LIVE' : (handTestActive ? 'CAMERA ON — TEST' : 'Camera/mic OFF');
  mediaStatus.classList.toggle('live', snap.mediaAllowed || handTestActive);
  mediaStatus.classList.toggle('safe', !snap.mediaAllowed && !handTestActive);
  localView.classList.toggle('hidden', !snap.mediaAllowed && !handTestActive);
  const callScreenActive = ['connecting', 'active', 'end_confirm'].includes(snap.state);
  const endControlActive = ['connecting', 'active', 'end_confirm'].includes(snap.state) && !remoteConfigActive;
  const endConfirmActive = snap.state === 'end_confirm' && !remoteConfigActive;
  document.body.classList.toggle('call-screen', callScreenActive);
  document.body.classList.toggle('end-confirm', endConfirmActive);
  document.body.classList.toggle('quick-check', triageActive);
  document.body.classList.toggle('hand-test', handTestMode !== 'off');
  remoteClinicianView.classList.toggle('hidden', !callScreenActive || !remoteClinicianStream);
  headerPrompt.classList.toggle('hidden', !endControlActive);
  card.classList.toggle('hidden', (snap.state === 'active' && !!remoteClinicianStream) || endConfirmActive);
  overlay.classList.toggle('hidden', !(snap.state === 'active' && !!remoteClinicianStream));
  if (versionBadge) {
    versionBadge.classList.toggle('hidden', !(snap.state === 'idle' && !remoteConfigActive && !triageActive && handTestMode === 'off'));
  }

  setButton('simulateIncoming', snap.state === 'idle' && !remoteConfigActive && !triageActive && handTestMode === 'off');
  setButton('triage', snap.state === 'idle' && !remoteConfigActive && !triageActive && handTestMode === 'off', 'Quick Check');
  setButton('requestCall', snap.state === 'idle' && !remoteConfigActive && !triageActive && handTestMode === 'off');
  setButton('accept', ['incoming', 'consent', 'declined_ok_check', 'declined_assistance_check'].includes(snap.state) && !remoteConfigActive && !triageActive && handTestMode === 'off', snap.state === 'incoming' ? 'OK / continue' : (snap.state === 'consent' ? 'Start call' : 'Yes'));
  setButton('decline', ['incoming', 'consent', 'declined_ok_check', 'declined_assistance_check'].includes(snap.state) && !remoteConfigActive && !triageActive && handTestMode === 'off', ['declined_ok_check', 'declined_assistance_check'].includes(snap.state) ? 'No' : 'Decline');
  setButton('cancelEnd', false);
  headerConfirmEnd.classList.toggle('hidden', !endControlActive);
  headerCancelEnd.classList.add('hidden');
  setButton('clearFault', snap.state === 'fault' && !remoteConfigActive && !triageActive && handTestMode === 'off');
  renderRemoteConfig();

  if (handTestMode !== 'off' && (snap.state !== 'idle' || triageActive || remoteConfigActive)) {
    stopHandTest('Hand Test stopped because kiosk left Ready');
    return;
  }

  if (triageActive) {
    screenTitle.textContent = triageScreen === 'complaint' ? 'Quick Check' : (triageScreen === 'question' ? 'Quick Check' : 'Quick Check');
    screenCopy.textContent = triageScreen === 'complaint'
      ? 'What are you worried about today? Use the remote and press OK.'
      : (triageScreen === 'question'
        ? 'Answer Yes or No using the remote.'
        : 'Camera and mic are still off.');
    countdownEl.classList.add('hidden');
    countdownLabelEl.classList.add('hidden');
    renderTriagePanel();
    focusFirstVisibleButton();
    return;
  }
  renderTriagePanel();

  if (handTestMode !== 'off') {
    screenTitle.textContent = handTestMode === 'confirm' ? 'Start Hand Test?' : 'Hand Test';
    screenCopy.textContent = handTestMode === 'confirm'
      ? 'This turns on the camera for local gesture testing only.'
      : 'Try navigating without the remote.';
    countdownEl.classList.add('hidden');
    countdownLabelEl.classList.add('hidden');
    renderHandPanel();
    focusFirstVisibleButton();
    return;
  }
  renderHandPanel();

  if (remoteConfigActive) {
    screenTitle.textContent = 'Configure remote';
    if (!remoteLast.textContent || remoteLast.textContent === 'Waiting for first remote button…') {
      screenCopy.textContent = 'Now press OK, arrows, and Back on the TV remote. Captured buttons turn green.';
    }
    return;
  }

  if (snap.state === 'idle') {
    screenTitle.textContent = 'Ready?';
    screenCopy.innerHTML = 'Waiting for Doctor.<br>Camera and mic are off.';
  } else if (snap.state === 'incoming') {
    screenTitle.textContent = 'Incoming call';
    screenCopy.textContent = `${snap.callerName || 'Clinician'} is calling. Press OK to continue to consent, or Decline.`;
  } else if (snap.state === 'consent') {
    screenTitle.textContent = 'Consent required';
    screenCopy.textContent = 'Press Start call to turn the camera on and connect video. Press Decline to keep camera off.';
  } else if (snap.state === 'connecting') {
    screenTitle.textContent = 'Connecting';
    screenCopy.textContent = 'Camera is now on after consent. Connecting secure video…';
  } else if (snap.state === 'active') {
    screenTitle.textContent = 'Call active';
    screenCopy.textContent = `Camera is live with ${snap.callerName || 'clinician'}. Press End call to finish.`;
  } else if (snap.state === 'end_confirm') {
    screenTitle.textContent = 'End call?';
    screenCopy.textContent = 'Press Confirm end to stop camera and return to idle, or Stay in call.';
  } else if (snap.state === 'declined_ok_check') {
    screenTitle.textContent = 'Are you OK?';
    screenCopy.textContent = 'Please answer Yes or No using the remote.';
  } else if (snap.state === 'declined_assistance_check') {
    screenTitle.textContent = 'Do you need assistance?';
    screenCopy.textContent = 'Press Yes and I will send a message to Graeme. Press No to return to Ready.';
  } else if (snap.state === 'declined_assistance_sent') {
    screenTitle.textContent = 'Message sent';
    screenCopy.textContent = 'Assistance has been requested. Please stay near the TV.';
  } else if (snap.state === 'fault') {
    screenTitle.textContent = 'Needs attention';
    screenCopy.textContent = snap.message || 'Device fault. Camera/mic stopped.';
  }
  activeText.textContent = `Call active with ${snap.callerName || 'clinician'} · Back/End to finish`;

  const countdownActive = renderCountdown(snap);
  if (snap.state === 'idle' && countdownActive) {
    const scheduled = snap.scheduledCall || {};
    screenTitle.textContent = 'Scheduled call';
    screenCopy.textContent = `${scheduled.callerName || 'Clinician'} will call ${scheduled.patientLabel || 'patient'} soon. Please stay near the TV.`;
    setButton('simulateIncoming', false);
  }
  focusFirstVisibleButton();
}

function dispatch(event, detail) {
  const before = sm.snapshot();
  sm.dispatch(event, detail);
  const after = sm.snapshot();
  log(`state ${before.state} -> ${after.state}`, { event, mediaAllowed: after.mediaAllowed });
  if (!before.mediaAllowed && after.mediaAllowed) {
    startMasterMedia().catch((err) => dispatch('fault', { message: err.message }));
  }
  if (before.mediaAllowed && !after.mediaAllowed) stopMasterMedia();
  if (after.state === 'declined_assistance_sent' && before.state !== 'declined_assistance_sent') {
    sendAssistanceAlert()
      .then(() => {
        if (assistanceAckTimer) clearTimeout(assistanceAckTimer);
        assistanceAckTimer = setTimeout(() => dispatch('assistanceSentAck'), 2500);
      })
      .catch((err) => dispatch('fault', { message: `Assistance alert failed: ${err.message}` }));
  }
  previousMediaAllowed = after.mediaAllowed;
  render();
}

el('simulateIncoming').addEventListener('click', () => dispatch('incoming', { callerName: 'Dr Murphy' }));
maintenanceMenu.addEventListener('change', () => handleMaintenanceMenuSelection(maintenanceMenu.value));
triageButton.addEventListener('click', () => requestTriage());
requestCallButton.addEventListener('click', () => requestCall());
el('accept').addEventListener('click', () => {
  const state = sm.snapshot().state;
  if (state === 'incoming') dispatch('acceptIncoming');
  else if (state === 'consent') dispatch('confirmConsent');
  else if (state === 'declined_ok_check') dispatch('patientOkYes');
  else if (state === 'declined_assistance_check') dispatch('assistanceYes');
});
el('decline').addEventListener('click', () => {
  const state = sm.snapshot().state;
  if (['incoming', 'consent'].includes(state)) dispatch('decline');
  else if (state === 'declined_ok_check') dispatch('patientOkNo');
  else if (state === 'declined_assistance_check') dispatch('assistanceNo');
});
el('cancelEnd').addEventListener('click', () => dispatch('cancelEnd'));
headerConfirmEnd.addEventListener('click', () => {
  dispatch(sm.snapshot().state === 'end_confirm' ? 'confirmEnd' : 'requestEnd');
});
headerCancelEnd.addEventListener('click', () => dispatch('cancelEnd'));
el('clearFault').addEventListener('click', () => dispatch('clearFault'));

document.addEventListener('keydown', (event) => {
  const targetTag = event.target && event.target.tagName;
  if (targetTag === 'TEXTAREA' || targetTag === 'INPUT') return;
  if (remoteConfigActive) {
    const action = KEY_ACTION[event.key];
    event.preventDefault();
    if (action) captureRemoteButton({ action, key: event.key, source: 'keyboard' });
    return;
  }
  const action = KEY_ACTION[event.key];
  if (action) {
    event.preventDefault();
    handleRemoteAction(action);
  }
});

window.tvmedKiosk = {
  dispatch,
  incoming: (callerName = 'Dr Murphy') => dispatch('incoming', { callerName }),
  scheduleCall: ({ callTime, callerName = 'Dr Murphy', patientLabel = 'Patient' } = {}) => dispatch('scheduleCall', { callTime, callerName, patientLabel }),
  clearSchedule: () => dispatch('clearSchedule'),
  startRemoteConfig,
  finishRemoteConfig,
  setDebugControlVisible,
  captureRemoteButton,
  remoteAction: handleRemoteAction,
  remoteConfigStatus: () => ({ active: remoteConfigActive, config: remoteConfig }),
  requestCall,
  requestTriage,
  wifiConfig,
  wifiLogin,
  updateDocbox,
  startHandTestConfirm,
  startHandTest,
  stopHandTest,
  reclaimRemote,
  restartPi,
  snapshot: () => sm.snapshot(),
};

const cfg = config();
el('deviceInfo').textContent = `${cfg.clientId} · ${cfg.region} · ${cfg.channelName}`;
setVersionBadge('dev');
render();
loadAppVersion().then(render);
log('Loaded device kiosk. Camera/mic remain off until explicit consent.');
