/* global AWS, KVSWebRTC, TVMED_KVS_CONFIG */
'use strict';

const remoteView = document.getElementById('remoteView');
const logEl = document.getElementById('log');
const statusEl = document.getElementById('status');
const statusText = document.getElementById('statusText');
const connectButton = document.getElementById('connect');
const disconnectButton = document.getElementById('disconnect');
const callDeviceButton = document.getElementById('callDevice');
const copyButton = document.getElementById('copy');
const localPreview = document.getElementById('localPreview');
const toggleMicButton = document.getElementById('toggleMic');
const toggleCameraButton = document.getElementById('toggleCamera');
const patientSelect = document.getElementById('patientSelect');

const FALLBACK_PATIENTS = [
  { id: 'gateway-host', label: 'John Doe', channelName: 'tvmed-gateway-host' },
  { id: 'dylan-pi5', label: 'Dylan patient', channelName: 'tvmed-dylan-pi5' },
  { id: 'colette-patient', label: 'Colette Patient', channelName: 'tvmed-colette-patient' },
];

let localStream = null;
let signalingClient = null;
let peerConnection = null;

function updateLocalMediaButtons() {
  const audioTrack = localStream && localStream.getAudioTracks()[0];
  const videoTrack = localStream && localStream.getVideoTracks()[0];
  toggleMicButton.disabled = !audioTrack;
  toggleCameraButton.disabled = !videoTrack;
  toggleMicButton.textContent = audioTrack && audioTrack.enabled ? 'Mute mic' : 'Unmute mic';
  toggleCameraButton.textContent = videoTrack && videoTrack.enabled ? 'Camera off' : 'Camera on';
}

async function startClinicianMedia() {
  stopClinicianMedia();
  setStatus('Requesting clinician camera/mic…');
  try {
    localStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
    });
  } catch (err) {
    log('Camera+mic request failed; retrying microphone only', { message: err.message });
    localStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false,
    });
  }
  localPreview.srcObject = localStream;
  localPreview.classList.remove('hidden');
  await localPreview.play().catch((err) => log('Local preview play warning', { message: err.message }));
  log('Clinician media acquired', {
    videoTracks: localStream.getVideoTracks().map((track) => track.label),
    audioTracks: localStream.getAudioTracks().map((track) => track.label),
  });
  updateLocalMediaButtons();
  return localStream;
}

function stopClinicianMedia() {
  if (localStream) {
    for (const track of localStream.getTracks()) track.stop();
  }
  localStream = null;
  localPreview.srcObject = null;
  localPreview.classList.add('hidden');
  updateLocalMediaButtons();
}

function setStatus(text, kind = '') {
  statusText.textContent = text;
  statusEl.classList.toggle('connected', kind === 'connected');
  statusEl.classList.toggle('error', kind === 'error');
}

function log(message, data) {
  const stamp = new Date().toISOString();
  const suffix = data === undefined ? '' : ` ${JSON.stringify(data, null, 2)}`;
  logEl.textContent += `[${stamp}] ${message}${suffix}\n`;
  logEl.scrollTop = logEl.scrollHeight;
}

function randomClientId() {
  return `clinician-${Math.random().toString(36).slice(2, 10)}`;
}

function allPatients() {
  const cfg = window.TVMED_KVS_CONFIG || {};
  const configured = Array.isArray(cfg.patients) ? cfg.patients : [];
  const byId = new Map();
  for (const patient of [...FALLBACK_PATIENTS, ...configured]) {
    const normalized = {
      id: patient.id || patient.deviceId,
      label: patient.label || patient.name || patient.id || patient.deviceId,
      channelName: patient.channelName,
    };
    if (normalized.id && normalized.channelName) byId.set(normalized.id, normalized);
  }
  return Array.from(byId.values());
}

function selectedPatient() {
  const patients = allPatients();
  return patients.find((patient) => patient.id === patientSelect.value) || patients[0] || FALLBACK_PATIENTS[0];
}

function config() {
  const cfg = window.TVMED_KVS_CONFIG || {};
  const patient = selectedPatient();
  return {
    region: cfg.region || 'eu-west-1',
    channelName: patient.channelName || cfg.channelName || 'tvmed-gateway-host',
    deviceId: patient.id || cfg.deviceId || 'gateway-host',
    patientLabel: patient.label || patient.id || 'Patient',
    clientId: cfg.clientId || randomClientId(),
    accessKeyId: cfg.accessKeyId,
    secretAccessKey: cfg.secretAccessKey,
    sessionToken: cfg.sessionToken || '',
    callTriggerUrl: cfg.callTriggerUrl || '',
    callTriggerToken: cfg.callTriggerToken || '',
  };
}

function renderPatientSelect() {
  const patients = allPatients();
  const params = new URLSearchParams(window.location.search);
  const requested = params.get('device') || params.get('patient') || '';
  // URL/device parameter must override any browser-restored dropdown value.
  const current = requested || patientSelect.value || patients[0]?.id || '';
  patientSelect.innerHTML = '';
  for (const patient of patients) {
    const option = document.createElement('option');
    option.value = patient.id;
    option.textContent = patient.label;
    patientSelect.appendChild(option);
  }
  patientSelect.value = patients.some((patient) => patient.id === current) ? current : (patients[0]?.id || '');
  updateSelectedPatientInfo();
}

function updateSelectedPatientInfo() {
  const cfg = config();
  document.getElementById('deviceName').textContent = `${cfg.patientLabel} (${cfg.deviceId})`;
  document.getElementById('channelName').textContent = cfg.channelName;
  document.getElementById('region').textContent = cfg.region;
  document.getElementById('callTrigger').textContent = cfg.callTriggerUrl || 'not configured';
}

function endpointByProtocol(endpoints, protocol) {
  const item = endpoints.find((e) => e.Protocol === protocol);
  if (!item) throw new Error(`KVS endpoint missing protocol ${protocol}`);
  return item.ResourceEndpoint;
}

async function getChannelArn(kinesisVideo, channelName) {
  const desc = await kinesisVideo.describeSignalingChannel({ ChannelName: channelName }).promise();
  const info = desc.ChannelInfo || {};
  if (info.ChannelStatus !== 'ACTIVE') throw new Error(`Channel is ${info.ChannelStatus || 'unknown'}, not ACTIVE`);
  return info.ChannelARN;
}

async function inviteDevice() {
  const cfg = config();
  if (!cfg.callTriggerUrl) throw new Error('Call trigger URL is not configured.');
  callDeviceButton.disabled = true;
  setStatus('Calling device…');
  log('Sending incoming-call trigger', { url: cfg.callTriggerUrl, deviceId: cfg.deviceId });
  const headers = { 'content-type': 'application/json' };
  if (cfg.callTriggerToken) headers['x-tvmed-token'] = cfg.callTriggerToken;
  const resp = await fetch(cfg.callTriggerUrl, {
    method: 'POST',
    mode: 'cors',
    headers,
    body: JSON.stringify({ deviceId: cfg.deviceId, callerName: 'Dr Murphy' }),
  });
  const body = await resp.json().catch(() => ({}));
  if (!resp.ok || body.ok === false) throw new Error(body.error || `Call trigger failed: HTTP ${resp.status}`);
  log('Device is ringing', body);
  setStatus('Device ringing');
}

async function connectViewer() {
  disconnectViewer();
  const cfg = config();
  if (!cfg.accessKeyId || !cfg.secretAccessKey) throw new Error('Viewer AWS credentials are missing.');

  document.getElementById('deviceName').textContent = cfg.clientId || 'viewer';
  document.getElementById('channelName').textContent = cfg.channelName;
  document.getElementById('region').textContent = cfg.region;

  setStatus('Resolving KVS…');
  connectButton.disabled = true;
  disconnectButton.disabled = false;

  AWS.config.update({
    region: cfg.region,
    credentials: new AWS.Credentials({
      accessKeyId: cfg.accessKeyId,
      secretAccessKey: cfg.secretAccessKey,
      sessionToken: cfg.sessionToken || undefined,
    }),
  });

  log(`Connecting VIEWER to ${cfg.patientLabel} on ${cfg.channelName}/${cfg.region} as ${cfg.clientId}`);
  const kinesisVideo = new AWS.KinesisVideo({ region: cfg.region });
  const channelARN = await getChannelArn(kinesisVideo, cfg.channelName);
  log('Resolved channel ARN suffix', channelARN.split('/').slice(-2).join('/'));

  const endpointResp = await kinesisVideo.getSignalingChannelEndpoint({
    ChannelARN: channelARN,
    SingleMasterChannelEndpointConfiguration: {
      Protocols: ['WSS', 'HTTPS'],
      Role: 'VIEWER',
    },
  }).promise();
  const endpoints = endpointResp.ResourceEndpointList || [];
  const wssEndpoint = endpointByProtocol(endpoints, 'WSS');
  const httpsEndpoint = endpointByProtocol(endpoints, 'HTTPS');
  log('Resolved endpoints', endpoints.map((e) => e.Protocol));

  const signaling = new AWS.KinesisVideoSignalingChannels({ region: cfg.region, endpoint: httpsEndpoint });
  const iceResp = await signaling.getIceServerConfig({ ChannelARN: channelARN }).promise();
  const iceServers = [
    { urls: `stun:stun.kinesisvideo.${cfg.region}.amazonaws.com:443` },
    ...(iceResp.IceServerList || []).map((server) => ({
      urls: server.Uris,
      username: server.Username,
      credential: server.Password,
    })),
  ];
  log('ICE servers ready', { count: iceServers.length });

  const clinicianStream = await startClinicianMedia();

  peerConnection = new RTCPeerConnection({ iceServers, iceTransportPolicy: 'all' });
  for (const track of clinicianStream.getTracks()) {
    peerConnection.addTrack(track, clinicianStream);
    log('Added clinician track to call', { kind: track.kind, label: track.label });
  }
  if (!clinicianStream.getVideoTracks().length) peerConnection.addTransceiver('video', { direction: 'recvonly' });
  if (!clinicianStream.getAudioTracks().length) peerConnection.addTransceiver('audio', { direction: 'recvonly' });

  peerConnection.addEventListener('icecandidate', ({ candidate }) => {
    if (!candidate || !signalingClient) return;
    signalingClient.sendIceCandidate(candidate);
    log('Sent ICE candidate');
  });
  peerConnection.addEventListener('track', async (event) => {
    remoteView.srcObject = event.streams[0];
    log('Remote track received', { kind: event.track.kind });
    await remoteView.play().catch((err) => log('Remote video play warning', { message: err.message }));
  });
  peerConnection.addEventListener('connectionstatechange', () => {
    const state = peerConnection.connectionState;
    log(`Peer state: ${state}`);
    if (state === 'connected') setStatus('Connected', 'connected');
    if (state === 'failed' || state === 'disconnected') setStatus(state, 'error');
  });
  peerConnection.addEventListener('iceconnectionstatechange', () => log(`ICE state: ${peerConnection.iceConnectionState}`));

  signalingClient = new KVSWebRTC.SignalingClient({
    channelARN,
    channelEndpoint: wssEndpoint,
    role: KVSWebRTC.Role.VIEWER,
    region: cfg.region,
    credentials: AWS.config.credentials,
    clientId: cfg.clientId,
    systemClockOffset: kinesisVideo.config.systemClockOffset,
  });

  signalingClient.on('open', async () => {
    setStatus('Negotiating…');
    log('Signaling open');
    const offer = await peerConnection.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
    await peerConnection.setLocalDescription(offer);
    signalingClient.sendSdpOffer(peerConnection.localDescription);
    log('VIEWER sent SDP offer');
  });
  signalingClient.on('sdpAnswer', async (answer) => {
    log('VIEWER received SDP answer');
    await peerConnection.setRemoteDescription(answer);
  });
  signalingClient.on('iceCandidate', async (candidate) => {
    await peerConnection.addIceCandidate(candidate);
    log('Received ICE candidate');
  });
  signalingClient.on('close', () => log('Signaling closed'));
  signalingClient.on('error', (err) => {
    setStatus('Signaling error', 'error');
    log('Signaling error', { message: String(err && err.message ? err.message : err) });
  });

  signalingClient.open();
}

function disconnectViewer() {
  if (signalingClient) { try { signalingClient.close(); } catch (_) {} signalingClient = null; }
  if (peerConnection) { try { peerConnection.close(); } catch (_) {} peerConnection = null; }
  remoteView.srcObject = null;
  stopClinicianMedia();
  connectButton.disabled = false;
  disconnectButton.disabled = true;
  setStatus('Idle');
}

connectButton.addEventListener('click', () => connectViewer().catch((err) => {
  disconnectViewer();
  setStatus('Error', 'error');
  log('CONNECT FAILED', { message: err.message, stack: err.stack });
}));
disconnectButton.addEventListener('click', () => { disconnectViewer(); log('Disconnected'); });
callDeviceButton.addEventListener('click', () => inviteDevice().catch((err) => {
  setStatus('Call trigger error', 'error');
  callDeviceButton.disabled = false;
  log('CALL DEVICE FAILED', { message: err.message, stack: err.stack });
}));
toggleMicButton.addEventListener('click', () => {
  const track = localStream && localStream.getAudioTracks()[0];
  if (!track) return;
  track.enabled = !track.enabled;
  log(track.enabled ? 'Clinician mic unmuted' : 'Clinician mic muted');
  updateLocalMediaButtons();
});
toggleCameraButton.addEventListener('click', () => {
  const track = localStream && localStream.getVideoTracks()[0];
  if (!track) return;
  track.enabled = !track.enabled;
  log(track.enabled ? 'Clinician camera enabled' : 'Clinician camera disabled');
  updateLocalMediaButtons();
});
copyButton.addEventListener('click', async () => { await navigator.clipboard.writeText(logEl.textContent); log('Copied log'); });

renderPatientSelect();
patientSelect.addEventListener('change', () => {
  if (peerConnection || signalingClient) disconnectViewer();
  callDeviceButton.disabled = !config().callTriggerUrl;
  updateSelectedPatientInfo();
  log('Selected patient', { deviceId: config().deviceId, channelName: config().channelName });
});
const initial = config();
callDeviceButton.disabled = !initial.callTriggerUrl;
updateLocalMediaButtons();
log('Loaded clinician viewer. Select John Doe, Dylan patient, or Colette Patient, use Call selected patient, wait for patient consent, then Connect viewer. Chrome will ask for clinician camera/mic.');
