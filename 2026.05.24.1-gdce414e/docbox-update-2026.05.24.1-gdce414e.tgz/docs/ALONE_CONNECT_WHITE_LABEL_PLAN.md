# ALONE Connect White-label Update Plan

> **For Hermes:** Use software-implementation-discipline and test-driven-development if executing this plan. Do not deploy to a live Pi unless Graeme explicitly asks.

**Goal:** Finish the ALONE Connect white-label update without breaking the existing DocBox kiosk, clinician viewer, safety flows, or field update path.

**Architecture:** Keep one shared DocBox codebase. DocBox remains the reference UI/UX and safety template. ALONE Connect is a brand/config overlay for user-facing tokens only: logo, product name, role labels, button labels, copy, and optional colours. Do not fork state machines, call flow, media consent, service names, API routes, systemd units, or update scripts.

**Current base:** Clean worktree `/Users/dv4studio/.openclaw/workspace/TVmed-whitelabel-clean`, branch `feature/white-label-branding`, PR #1. Existing implementation has `BRAND_REGISTRY`, `localStorage.docboxWhiteLabelBrand`, and a mouse-only maintenance menu switch.

---

## Hard guardrails

- No live Pi deployment unless Graeme explicitly asks.
- No changes to camera/mic activation, consent gating, WebRTC media start, end-call behavior, welfare flow, CEC reclaim, or remote-control navigation as part of branding.
- Keep internal identifiers stable unless explicitly asked: `tvmed`, `docbox`, existing routes, service names, and env keys may remain internal.
- DocBox must remain the default brand if no brand is configured.
- Brand switching must be mouse-only/operator-only; do not add it to TV remote D-pad focus.
- No raw secrets, viewer gate keys, Worker secrets, AWS keys, or tokens in repo/docs.

---

## Acceptance criteria

1. DocBox kiosk still defaults to current DocBox UI/copy and passes existing tests.
2. ALONE Connect can be activated by config or local operator switch without code fork.
3. ALONE user-facing copy uses:
   - Product: `ALONE Connect`
   - Role: `ALONE Care Helper`
   - `I’m Ready` -> `I’m Here`
   - `Request Call` -> `Call for Help`
   - `Quick Check` -> `How Are You Feeling?`
   - no patient-facing `Doctor` / `Dr Murphy` fallback in ALONE mode.
4. Official ALONE logo is used when supplied; otherwise text-mark fallback remains safe.
5. Kiosk still fits 1920×1080 with no scroll in both brands.
6. Generated control docs/skill stay current after any menu/export changes.
7. Public clinician viewer and device kiosk are verified from source/tests before merge; live deployment is a separate explicit step.

---

## Task 0: Confirm clean rollback point

**Objective:** Ensure implementation starts from a known-clean branch.

**Files:** none.

**Steps:**
1. Run:
   ```bash
   cd /Users/dv4studio/.openclaw/workspace/TVmed-whitelabel-clean
   git status --short --branch
   git log --oneline -5
   ```
2. Expected: clean `feature/white-label-branding` branch with only intended commits.
3. If dirty, inspect and either commit plan/docs changes or reset only after preserving any useful work.

---

## Task 1: Add/verify official ALONE logo asset

**Objective:** Replace text fallback with official ALONE logo only when the asset is available.

**Files:**
- Add: `web/assets/alone-logo.*` or `web/assets/alone-connect-logo.*`
- Modify: `web/device-kiosk.js`
- Possibly modify: `web/device-kiosk.html` if cache-bust needed.

**Steps:**
1. Add supplied logo under `web/assets/`.
2. Ensure filename contains no spaces and is web-safe.
3. Update `BRAND_REGISTRY.aloneconnect.logoSrc` to point at the asset.
4. Keep text fallback in place if image load fails.
5. Cache-bust script reference only if JS changed and static deploy path needs it.

**Verification:**
```bash
node --check web/device-kiosk.js
```
Then use local browser/CDP check later in Task 6.

---

## Task 2: Complete ALONE brand token coverage

**Objective:** Route all visible patient-facing ALONE terminology through brand tokens, without broad internal renames.

**Files:**
- Modify: `web/device-kiosk.js`
- Possibly modify: `web/device-kiosk.html`
- Test: `tests/device-kiosk-state.test.js` or add focused brand-token test if practical.

**Checklist to inspect and patch narrowly:**
- Ready screen title/copy.
- Primary button label.
- Request-help button label and alert reason.
- Quick Check button and result copy.
- Incoming call caller role/copy.
- Scheduled call countdown copy.
- Welfare/assistance copy if it says Doctor/clinician.
- Footer/header product copy.
- Document title.

**Do not change:** state names, event names, API payload fields, service names, or media behavior.

**Verification:**
```bash
node --check web/device-kiosk.js
node --test tests/device-kiosk-state.test.js
```

---

## Task 3: Add brand activation from generated config

**Objective:** Ensure devices can boot directly into ALONE Connect via config, without relying on manual menu switching.

**Files:**
- Modify/read: config generation path for `window.TVMED_KVS_CONFIG` if needed.
- Modify: `web/device-kiosk.js` only if existing `brand`/`brandKey` handling is incomplete.

**Expected behavior:**
Priority should be clear and documented:
1. Explicit config brand/brandKey if present.
2. Operator-selected `localStorage.docboxWhiteLabelBrand` if no config brand is present.
3. DocBox default.

If current implementation uses a different priority, document it or adjust deliberately.

**Verification:**
Use browser console/CDP with synthetic configs:
```js
window.TVMED_KVS_CONFIG = { brand: 'aloneconnect' }
```
Then reload/apply and verify active brand. Also test invalid brand falls back to DocBox.

---

## Task 4: Preserve remote-control navigation and maintenance menu boundaries

**Objective:** Ensure ALONE branding does not alter D-pad focus or expose operator controls to the patient remote.

**Files:**
- Modify/read: `web/device-kiosk.js`
- Modify/read: `web/device-kiosk.html`

**Checks:**
- Brand switch remains in bottom-left mouse-only maintenance `<select>`.
- `switchToAloneConnect` / `switchToDocBox` is not part of Ready-screen D-pad map.
- Ready map remains shared:
  - `I’m Ready`/`I’m Here` ⇄ request/help ⇄ Quick Check/How Are You Feeling?
- `Camera/mic OFF` remains status-only, not focusable.

**Verification:**
Browser/CDP scripted remote actions:
```js
window.tvmedKiosk.switchBrand('aloneconnect')
window.tvmedKiosk.remoteAction('UP')
window.tvmedKiosk.remoteAction('DOWN')
window.tvmedKiosk.snapshot()
```
Assert focus moves only among patient-facing controls.

---

## Task 5: Keep generated docs/skill current

**Objective:** Regenerate source-derived docs after menu/export changes without dropping curated references.

**Files:**
- Modify/check: `docs/docbox-control-skill.md`
- Source generator: `scripts/generate_docbox_skill.py`

**Steps:**
1. Run:
   ```bash
   python3 scripts/generate_docbox_skill.py --check
   ```
2. If stale:
   ```bash
   python3 scripts/generate_docbox_skill.py
   ```
3. Inspect the diff. If curated reference links disappear, fix the generator/template, not the generated output by hand.

**Verification:**
```bash
python3 -m pytest tests/test_docbox_skill_generator.py
```

---

## Task 6: Local visual/browser verification for both brands

**Objective:** Prove the kiosk still renders and fits for DocBox and ALONE Connect.

**Files:** none unless bugs found.

**Local checks:**
1. Serve/open kiosk locally using existing project method.
2. In DocBox brand, inspect:
   - header logo/copy,
   - Ready screen labels,
   - Quick Check label,
   - Request Call label,
   - no document scroll at 1920×1080.
3. Switch to ALONE Connect and inspect:
   - ALONE logo/text mark,
   - `I’m Here`, `Call for Help`, `How Are You Feeling?`,
   - `ALONE Care Helper` copy,
   - no `Doctor` fallback in ALONE patient-facing idle/request paths,
   - no document scroll at 1920×1080.

**Useful console snippet:**
```js
({
  brand: window.tvmedKiosk.activeBrand?.(),
  title: document.querySelector('#screenTitle')?.textContent?.trim(),
  buttons: [...document.querySelectorAll('button')].map(b => b.textContent.trim()).filter(Boolean),
  scroll: { width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight, innerWidth, innerHeight }
})
```

---

## Task 7: Full test gate before merge

**Objective:** Run the existing focused safety/test gate.

**Commands:**
```bash
cd /Users/dv4studio/.openclaw/workspace/TVmed-whitelabel-clean
node --check web/device-kiosk.js
node --test tests/device-kiosk-state.test.js
python3 -m pytest tests/test_docbox_skill_generator.py
```

If Python tests need project path:
```bash
PYTHONPATH=. python3 -m pytest tests/test_docbox_skill_generator.py
```

Expected: all pass.

---

## Task 8: PR review and merge, no deployment

**Objective:** Merge only after verified source state; keep live Pi untouched.

**Steps:**
1. Review diff:
   ```bash
   git diff github/main...HEAD -- web/device-kiosk.js web/device-kiosk.html docs/WHITE_LABEL_BRANDING.md docs/docbox-control-skill.md README.md
   ```
2. Confirm no secrets:
   ```bash
   git grep -nE 'AKIA|SECRET_ACCESS_KEY|BEGIN PRIVATE KEY|x-tvmed-token|TVMED_DEVICE_API_TOKEN|TWILIO_AUTH_TOKEN|CLOUDFLARE_API_TOKEN' -- . ':!*.md'
   ```
3. Push branch and update PR if needed.
4. Merge PR only after tests/review.
5. Do not run field release builder or Pi update script unless separately requested.

---

## Deferred post-merge deployment plan

Only if Graeme explicitly asks to deploy:

1. Build no-secrets DocBox release bundle.
2. Publish release to `docbox-releases`.
3. Run `scripts/docbox_device_update.sh` on target Pi.
4. Verify service active, badge version, 1920×1080 fit, and brand selection.
5. Do not change patient Pi brand persistently unless target device is meant to become ALONE Connect.
