# White-label branding architecture

DocBox is the reference template for every white-label build.

## Product rule

- Shared codebase: all brands run the same kiosk, clinician viewer, call state machine, device API, CEC handling, safety gates, update path, and tests.
- DocBox owns the UI/UX pattern: layout, navigation, remote-control D-pad behavior, consent flow, Quick Check flow, maintenance menu shape, 1920×1080 fit, and accessibility rules.
- White-label brands only override brand tokens and copy where required: logo/text mark, public product name, primary/accent colours, domain, and optional partner-specific patient/clinician labels.
- Internal identifiers may remain `tvmed`/`docbox` while user-facing copy can change by brand. Do not fork behavior or duplicate screens for a partner brand unless a new shared feature is being added for all brands.

## Current kiosk implementation

`web/device-kiosk.js` contains a small brand registry:

- `docbox` — default/reference brand; uses `web/assets/docbox-logo-current.png`.
- `aloneconnect` — first white-label entry; uses the same DocBox UI/UX and shows `web/assets/AloneConnect_logo.jpg` with text fallback if the image fails to load.

The mouse-only maintenance menu now includes **Switch to AloneConnect**. Selecting it stores the active brand in `localStorage.docboxWhiteLabelBrand`, updates the header brand, document title, and user-facing alert reason strings, and toggles the menu label back to **Switch to DocBox**.

A deployed device can also be pre-set by config once the generated `TVMED_KVS_CONFIG` includes either:

```js
brand: 'aloneconnect'
```

or:

```js
brandKey: 'aloneconnect'
```

If no brand is configured or stored locally, the kiosk defaults to DocBox.

## Adding the next brand

1. Add a new entry to `BRAND_REGISTRY` in `web/device-kiosk.js`.
2. Add a logo under `web/assets/` if supplied; otherwise allow text fallback.
3. Keep UI/UX identical to DocBox unless the change is a shared product improvement.
4. Add a maintenance-menu switch only if field operators need manual switching on-device.
5. Cache-bust `device-kiosk.html` script query string.
6. Run syntax/tests and regenerate `docs/docbox-control-skill.md` if menu/export surfaces changed.

## Non-goals

- No per-brand code forks.
- No partner-specific consent/media safety changes.
- No hidden camera/mic behavior changes under a white-label brand.
- No broad rename of stable API/service/script names just for branding.
