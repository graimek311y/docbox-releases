# TVmed Research Brief

**Project:** TVmed — standalone TV telemedicine for older persons who cannot reliably use phones/tablets.

**Core idea:** A managed TV-connected appliance/app lets an authorised remote clinician start a consultation, wake/show the TV interface, and control the camera/PTZ after visible consent/alerting.

## Executive recommendation

Do **not** target arbitrary consumer smart TVs as the primary platform. Camera/mic access, USB camera support, remote wake/start, kiosk mode, app distribution, and device management are too fragmented.

Recommended MVP:

- **Host:** managed HDMI appliance — Linux mini PC/Raspberry Pi-class box or Android Enterprise-capable TV/set-top box.
- **Display:** existing TV over HDMI.
- **Camera/audio:** OBSBOT Tiny 2 for first MVP, using the camera's built-in microphone to minimise installation complexity; OBSBOT Tail Air if IP/VISCA/OSC control is needed.
- **Remote audio output:** use the TV speakers over HDMI for MVP, with WebRTC acoustic echo cancellation tested in a real living room.
- **Fallback audio:** external USB speakerphones are a fallback only if built-in camera mic + TV speakers fail real-room audio tests.
- **Video/audio transport:** WebRTC.
- **Audio approach:** camera built-in mic + TV speakers over HDMI, using WebRTC/browser/libwebrtc acoustic echo cancellation as the first-line “mix-minus” mechanism.
- **AWS option:** Amazon Kinesis Video Streams with WebRTC is the current managed signaling/STUN/TURN candidate for the prototype. Dev setup: AWS account `798335328077`, region `eu-west-1`, channel `tvmed-gateway-host`, device role `MASTER`, Pi runtime IAM user `tvmed-device-gateway-host` scoped to that channel. KVS is not itself an audio mixer, so echo cancellation still happens in the Pi/browser/native WebRTC stack.
- **Remote control:** clinician web console sends signed commands over WebRTC data channel or secure device-control channel.
- **TV wake/input:** HDMI-CEC first, with fallback IR blaster/smart plug/OEM TV API where necessary.
- **Hermes Agent:** use as the remote ops/support/install/note-assistant layer around TVmed, not as the safety-critical consent or call-state controller.

## Target users

OPS / older persons who:

- cannot operate phone/tablet reliably,
- may have visual, hearing, cognitive, mobility, or dexterity limitations,
- may need clinician/caregiver-initiated calls,
- already have or can use a TV as the interface.

## Camera/audio research

### Ranked shortlist

1. **OBSBOT Tiny 2** — best practical MVP USB camera
   - 4K, 2-axis gimbal PTZ, AI tracking, USB.
   - SDK supports Windows/macOS/Linux; includes gimbal control, zoom, sleep/wake, presets, tracking modes, audio settings.
   - Good enough for controlled appliance; validate Linux SDK and UVC behaviour.
   - Built-in mics + TV speakers are the desired low-complexity MVP path; validate WebRTC AEC in a real living room.
   - Sources: https://www.obsbot.com/explore/obsbot-tiny-2 , https://www.obsbot.com/sdk

2. **OBSBOT Tail Air** — best advanced/IP PTZ option
   - 4K, 2-axis gimbal, HDMI, USB/UVC, RTSP/RTMP/SRT, VISCA over IP, OSC, OBSBOT SDK.
   - More expensive/complex but better if remote camera control is central.
   - Has 3.5 mm mic/line input; still consider separate room audio.
   - Sources: https://www.obsbot.com/explore/obsbot-tail-air , https://www.obsbot.com/explore/obsbot-tail-air/visca-over-ip

3. **Logitech PTZ Pro 2** — reliable business USB PTZ
   - 1080p, optical zoom, mature enterprise camera.
   - No built-in audio; needs separate speaker/mic.
   - Public SDK/control story weaker than OBSBOT; test UVC PTZ/V4L2.
   - Source: https://www.logitech.com/en-us/products/video-conferencing/conference-cameras/ptz-pro2-conferencecam.html

4. **Logitech Rally / Rally Plus** — excellent audio/video but overkill for home
   - Strong room audio with mic pods, enterprise management.
   - Expensive and too complex for individual homes; better for care facilities/clinics.

5. **Insta360 Link 2** — visually attractive but API risk
   - 4K webcam; Link 2 has gimbal, Link 2C does not.
   - No clearly reliable public embedded PTZ API found. Main control path appears desktop app.
   - Use only after direct vendor confirmation and Linux/Android PTZ prototype.
   - Source: https://www.insta360.com/product/insta360-link2

6. **Huddly / Meeting Owl** — good meeting-room products, poor doctor-controlled PTZ fit
   - Huddly: auto-framing/digital crop, not doctor-driven mechanical PTZ.
   - Meeting Owl: strong room audio but 360-degree meeting style, not suitable for medical inspection/framing.

### Audio recommendation

- Use the OBSBOT Tiny 2 built-in microphone plus TV speakers over HDMI for the simplest MVP hardware footprint.
- Enable and test WebRTC acoustic echo cancellation (`echoCancellation`, `noiseSuppression`, `autoGainControl`, or native/libwebrtc AEC3 equivalent).
- Run real-room tests at sofa distance and realistic TV volume before relying on this for pilots.
- Keep a separate USB speakerphone/mic near the patient as the fallback if echo, pickup distance, or intelligibility fail.

## TV OS/platform research

### Best platform choices

1. **Linux mini-PC/Raspberry Pi HDMI appliance** — best technical fit
   - Full control of USB UVC cameras, USB audio, PTZ APIs, WebRTC, kiosk/autostart, OTA updates, device logs, support access.
   - Can stay always-on and wake TV via HDMI-CEC/IR.
   - Best for doctor-controlled camera and security hardening.

2. **Managed Android TV/set-top box** — best commercial appliance path
   - Use Android Enterprise/dedicated device mode where possible.
   - Native WebRTC app, foreground service, kiosk launcher, MDM, FCM commands, HDMI-CEC.
   - Must validate USB camera/mic support per exact hardware/firmware.
   - Source: https://source.android.com/docs/core/camera/external-usb-cameras

### Platforms to avoid as primary MVP

- **tvOS/Apple TV:** not standalone; camera depends on iPhone/iPad Continuity Camera. Fails no-phone/no-tablet constraint.
- **Roku:** no general camera/mic/WebRTC telemedicine platform.
- **Samsung Tizen / LG webOS consumer TVs:** fragmented WebRTC/camera support, poor remote wake/start, weak fleet management.
- **Fire TV:** possible pilot target but weaker than managed Android devices for camera and management guarantees.

## Privacy/security/regulatory issues

Remote clinician control of a home TV/camera is high-risk. Design it as **remote-start with visible consent/alerting**, not silent surveillance.

### Main risks

- Special category health data: video/audio consultations plus home context.
- Vulnerable adults: capacity, coercion, safeguarding, carer involvement.
- Remote camera/mic activation: potential covert surveillance or abuse.
- Stolen clinician credentials or insider misuse.
- Wrong patient-device pairing.
- Unpatched home appliances.
- Recording/metadata retention and data subject rights.
- NHS procurement requirements if used in UK healthcare.

### Required mitigations

- DPIA before pilot.
- Clear controller/processor roles and lawful basis; Article 9 health-data condition.
- No silent camera/mic activation.
- Full-screen prompt, audible chime/spoken announcement, countdown, persistent on-screen call banner.
- Voice approval before camera/video starts where the patient is capable: e.g. “Doctor Smith is calling. Say YES to start video, or NO to decline.” Keep voice approval as a consent/accessibility layer, not the only safeguard.
- TV remote approval before camera/video starts: support pressing **OK/Select** on the TV remote via HDMI-CEC as a first-class approval option, alongside voice. Show a high-contrast full-screen prompt: “Press OK to start video. Press Back/Exit to decline.”
- Support non-voice fallback approval for hearing/speech/cognitive impairment: large physical button, TV remote OK button, carer approval, or pre-agreed auto-answer policy for specific trusted appointments.
- Physical/privacy button or shutter where possible.
- Patient/carer can revoke remote-start permission.
- Clinician MFA, RBAC, care-team relationship checks, just-in-time appointment access.
- Signed commands, device certificates, anti-replay, TLS/WebRTC DTLS-SRTP.
- Tamper-evident audit logs: who started, when, why, patient/device, accepted/auto-accepted/break-glass, camera/mic state changes.
- Patient/carer visible access history.
- Break-glass only with reason, re-authentication, alerts, post-event review.
- Secure provisioning/deprovisioning, remote wipe, cert revocation, signed OTA updates.
- No recording by default; explicit separate consent and retention if enabled.
- NHS DSPT/DTAC/Cyber Essentials evidence pack if targeting NHS/social care.

Sources:

- ICO DPIA guidance: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/accountability-and-governance/data-protection-impact-assessments-dpias/
- GDPR Article 9: https://gdpr-info.eu/art-9-gdpr/
- GDPR Article 25: https://gdpr-info.eu/art-25-gdpr/
- GDPR Article 32: https://gdpr-info.eu/art-32-gdpr/
- NHS DSPT: https://www.dsptoolkit.nhs.uk/
- NHS DTAC: https://digital.nhs.uk/services/digital-technology-assessment-criteria-dtac
- NCSC Cyber Essentials: https://www.ncsc.gov.uk/cyberessentials/overview

## MVP architecture sketch

- Patient home:
  - Managed HDMI appliance connected to TV.
  - OBSBOT Tiny 2 / Tail Air camera above TV.
  - OBSBOT Tiny 2 built-in mic + TV speakers over HDMI for simplest MVP; external USB speakerphone near seating area only if real-room echo tests fail.
  - TVmed app in kiosk mode, auto-starts on boot.
  - Device stays connected to TVmed cloud via mutually authenticated control channel.

- Clinician side:
  - Web console with patient roster/appointments.
  - Start session button sends signed remote-start command.
  - Camera controls: pan/tilt/zoom/presets/tracking toggle.
  - WebRTC call UI.
  - Audit/history visible.

- Cloud:
  - Device registry/certificates.
  - Appointment/care-team authorisation.
  - Signalling server.
  - Audit log service.
  - OTA/config management.

## Hermes Agent integration

Hermes should be integrated as the **ops/assistant layer** around TVmed, while the TVmed device app remains deterministic and safety-critical decisions remain hard-coded/auditable.

### Role boundary

Hermes may assist with:

- remote support and diagnostics: “is OPS online?”, “is OBSBOT detected?”, “why did the call fail?”;
- health summaries: device uptime, temperature, disk, service status, WebRTC listener, USB camera/audio, HDMI/CEC state;
- allowlisted maintenance actions: restart WebRTC listener, collect logs, test camera/audio, run preflight checks;
- installer/carer guidance over Telegram or an admin console;
- scheduled watchdog alerts and daily/appointment preflight checks;
- operational call-event summaries and Obsidian/project notes.

Hermes must **not** decide:

- whether camera/mic may turn on;
- whether patient consent is valid;
- whether emergency/break-glass access is permitted;
- whether to accept or decline a clinical call.

Those decisions stay in the TVmed state machine and clinical governance policy.

### Device-side service shape

Run separate services on the appliance:

- `tvmed-device.service`
  - WebRTC listener and media pipeline.
  - OBSBOT PTZ control daemon.
  - voice/remote/button consent detection.
  - HDMI-CEC wake/input control.
  - deterministic state machine: `IDLE -> INCOMING_CALL_VISIBLE_ALERT -> WAIT_FOR_APPROVAL -> CONNECTING -> IN_CALL -> ENDED`.
- `tvmed-agent-bridge.service`
  - small local API exposing only safe, allowlisted support actions.
  - candidate endpoints:
    - `GET /health`
    - `GET /logs?since=...`
    - `POST /actions/restart-webrtc`
    - `POST /actions/test-camera`
    - `POST /actions/test-audio`
    - `GET /ptz/status`
    - `GET /call/status`
  - sends event webhooks to Hermes/cloud for support summaries and alerts.

Hermes can run either centrally on Graeme/admin infrastructure or as a constrained local profile on the Pi. For production devices, prefer central Hermes plus a tightly scoped device bridge; avoid giving the LLM broad local shell access on a patient appliance.

### Safe command pattern

All Hermes-triggered commands must be:

- allowlisted by endpoint/action name;
- authenticated with device identity and signed requests;
- logged with requester, time, before/after state, and whether camera/mic state could be affected;
- unable to bypass local visible consent flows;
- revocable per device/patient.

Example admin workflow:

1. Graeme/admin asks Hermes: “check OPS device”.
2. Hermes calls the health endpoint or backend API.
3. Hermes summarizes: online/offline, camera/audio/HDMI/WebRTC status, last call failure reason.
4. Admin may ask: “restart listener”.
5. Hermes calls only `POST /actions/restart-webrtc`, not arbitrary shell, and reports verified result.

### Scheduled Hermes checks

Recommended watchdogs:

- every 5 minutes: device heartbeat/offline alert;
- hourly: camera/audio/WebRTC/HDMI/CEC status;
- daily: disk/cache/log rotation and update status;
- after reboot: “device back online” notification;
- before scheduled call: preflight and alert if camera/audio/WebRTC is not ready.

### MVP implementation order

1. Add `GET /health` to the TVmed device service.
2. Add Hermes cron/webhook monitoring for heartbeat alerts.
3. Add the allowlisted support bridge for restart/test/log collection actions.
4. Emit structured call events: incoming call, consent requested, accepted/declined, call ended, failure reason.
5. Add installer mode/checklist driven by Hermes.
6. Later, expose Hermes behind an “Ask support agent” admin-console panel.

## AI/medical-model research

MedGemma is worth tracking as a later **clinical-note support** option, but it should not be part of the safety-critical TVmed device path.

Current finding:

- Google MedGemma models are medical-specialised Gemma variants on Hugging Face, including `google/medgemma-4b-it`, `google/medgemma-27b-it`, and `google/medgemma-4b-pt`; current HF metadata marks them public but gated/auto-access.
- Tags and intended domains include clinical reasoning, radiology/chest X-ray, dermatology, pathology, ophthalmology, and medical image/text workflows.
- The Raspberry Pi 400 / Pi-class appliance should **not** run MedGemma locally. Even 4B would be marginal beside kiosk browser/WebRTC, and 27B is out of scope.
- Do not use MedGemma to decide consent, call access, diagnosis, triage, medication advice, emergency escalation, or whether camera/mic may activate.

Potential safe uses later:

- summarise structured care history or clinician/carer notes for review;
- extract/check missing fields such as allergies, medications, emergency contacts, communication needs;
- explain medical terms to carers with clear “not medical advice” wording;
- draft questions for a scheduled GP/clinician call;
- support clinician-reviewed document summarisation, never autonomous diagnosis.

Recommended architecture:

- TVmed Pi remains deterministic: consent/call/media state machine, encrypted local operational/care store, Hermes ops sidecar.
- MedGemma, if used, runs on Mac Studio/cloud/server-side service, not on patient appliance.
- Output is labelled as draft/support material and requires clinician/carer review and audit before it affects care records.
- Medical history should live in a structured encrypted store or proper EPR/EMR integration boundary, not freeform Obsidian project notes.

Sources:

- https://huggingface.co/google/medgemma-4b-it
- https://huggingface.co/google/medgemma-27b-it
- https://huggingface.co/google/medgemma-4b-pt

## PTZ-on-Raspberry-Pi research

Current finding: **OBSBOT Tiny 2 PTZ/gimbal/zoom on Raspberry Pi 5 is plausible and worth testing first**, but it remains a hardware validation item until proven on a real Pi + camera.

Evidence:

- OBSBOT's current SDK page offers Linux support and the current SDK package includes both `linux/x86_64-release/libdev.so` and `linux/arm64-release/libdev.so`, which is the key requirement for Raspberry Pi 5 64-bit OS.
- Official SDK API names include gimbal motor angle/speed/stop/reset, presets, AI tracking modes, absolute zoom, FOV, sleep/wake/status.
- Third-party Linux projects confirm Tiny 2 control paths exist:
  - Tiny4Linux: Linux GUI/CLI for Tiny 2 sleep/wake, AI tracking, tracking speed, presets; notes general movement/zoom controls can use standard V4L2 where exposed.
  - `cgevans/tiny2`: original Rust Linux controller used by Tiny4Linux.
  - `aaronsb/obsbot-camera-control`: Qt6 Linux controller using OBSBOT SDK; claims full Tiny 2 support including PTZ, auto-framing, image settings, FOV, HDR, focus/white balance. Its bundled older SDK is x86_64, but current official SDK has ARM64.
- Standard Linux V4L2 may expose `zoom_absolute`, `pan_absolute`, `tilt_absolute`, focus/exposure/brightness controls; the richer OBSBOT-specific features need SDK/UVC extension commands.

Risks to validate:

- ARM64 SDK may be tested on generic Ubuntu ARM64 but not specifically Raspberry Pi OS.
- USB permissions/udev rules may be required.
- USB power/bandwidth must be tested with 1080p/4K video + control commands.
- Third-party tools are useful references, but production should use a minimal TVmed control daemon rather than a desktop GUI app.

Fallbacks:

- **Intel N100 mini PC** if Pi ARM64 SDK, WebRTC load, or USB stability is weak.
- **OBSBOT Tail Air / Tail 2 with VISCA over IP** if network PTZ control is more important than USB webcam simplicity.

Sources:

- https://www.obsbot.com/sdk
- https://github.com/OpenFoxes/Tiny4Linux
- https://github.com/cgevans/tiny2
- https://github.com/aaronsb/obsbot-camera-control
- https://www.kernel.org/doc/html/latest/userspace-api/media/v4l/ext-ctrls-camera.html
- https://www.obsbot.com/explore/obsbot-tail-air/visca-over-ip

## Immediate next steps

1. Buy/borrow **OBSBOT Tiny 2**.
2. Prototype on Linux mini PC/Raspberry Pi first.
   - Preferred Pi enclosure for living-room MVP: a flat-top aluminium Raspberry Pi 5 case such as Argon NEO 5 / Flirc-style case; mount the OBSBOT Tiny 2 on top with removable 3M Dual Lock/Velcro or a small 3D-printed saddle.
   - Avoid relying on the webcam base alone for appliance stability: the Tiny 2 footprint is much smaller than a Pi 5 case, so the case should act as a weighted plinth rather than trying to match the camera footprint exactly.
3. Run the PTZ-on-Pi spike:
   - Confirm Pi OS is `aarch64`; confirm OBSBOT appears in `lsusb` and `/dev/video*`.
   - Run `v4l2-ctl --list-devices`, `v4l2-ctl -d /dev/video0 --list-ctrls`, and `v4l2-ctl -d /dev/video0 --list-formats-ext`.
   - Test standard controls if exposed: `zoom_absolute`, `pan_absolute`, `tilt_absolute`.
   - Download the official OBSBOT SDK on the Pi and run `ldd linux/arm64-release/libdev.so`.
   - Build/run the official SDK sample or a tiny control program to test: enumerate, zoom, gimbal move/stop, preset, AI tracking toggle, sleep/wake.
   - Stream 1080p30 WebRTC while sending periodic PTZ commands; watch `dmesg` and `vcgencmd get_throttled` for USB resets/thermal issues.
4. Prove:
   - TV wake via HDMI-CEC.
   - app autostart/kiosk.
   - WebRTC call.
   - doctor PTZ commands via OBSBOT SDK or V4L2.
   - audio echo cancellation in a living room.
5. Then test a managed Android box if product direction prefers Android.
6. Start DPIA/security architecture before any real patient pilot.
