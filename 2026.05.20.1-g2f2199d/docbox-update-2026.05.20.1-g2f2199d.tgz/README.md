# TVmed

Standalone TV telemedicine for older persons who cannot reliably use phones/tablets.

## Goal

A managed TV-connected app/appliance lets a remote clinician start a telemedicine session, wake/show the TV UI, and control the camera/PTZ with strong privacy controls.

## Current recommendation

Use a **managed HDMI appliance**, not arbitrary consumer smart TV OS:

- Linux mini PC/Raspberry Pi-class device, or managed Android Enterprise TV box.
- Existing TV as display over HDMI.
- OBSBOT Tiny 2 for MVP camera; OBSBOT Tail Air if IP/VISCA/OSC control is needed.
- OBSBOT Tiny 2 built-in mic + TV speakers over HDMI for the simplest MVP; external USB speakerphone only if real-room echo tests fail.
- WebRTC for media.
- HDMI-CEC/IR/smart plug/OEM API for TV wake/input.
- Hermes Agent as the remote ops/support layer, not the safety-critical call controller.

See `RESEARCH.md` for the full first-pass research brief.

## Sharing / second Pi setup

- GitHub mirror for collaborators: `https://github.com/graimek311y/TVmed`
- Dylan Pi setup notes: `DYLAN_PI_SETUP.md`
- Runtime AWS/KVS/API tokens are **not** committed; share them out-of-band and keep env files `600`.
- Field update system: `DOCBOX_FIELD_UPDATES.md` plus `scripts/build_docbox_release.py` and `scripts/docbox_device_update.sh` for no-secrets public release bundles.

## Prototype scripts

- `tvmed_cec.py` — HDMI-CEC TV power/scan/remote-event helper for Samsung/Pi prototype.
- `tvmed_preflight.py` — read-only Pi health/preflight checks.
- `tvmed_shell.py` — minimal console TV shell driven by remote actions, with explicit mock consent/end-call states.
- `tvmed_morning_test.sh` — safe operator smoke test: preflight, optional TV wake, install/restart shell service, and remote-control test path.
- `tvmed_kvs_smoke.py` — non-secret AWS KVS signaling/ICE smoke test; it does not start camera/mic media.
- `tvmed_kvs_browser_smoke.sh` + `web/kvs-webrtc-smoke.html` — prototype browser MASTER/VIEWER smoke page for Brio camera/mic → AWS KVS WebRTC → browser playback.
- `tvmed_kvs_clinician_viewer.sh` + `web/clinician-viewer.html` — local-only clinician VIEWER prototype with hidden credentials and a focused remote-video UI.
- `tvmed_device_kiosk.sh` + `web/device-kiosk.html` — next-stage Pi browser device UI with deterministic idle → incoming → consent → connecting/active → end-confirm/fault states. Camera/WebRTC MASTER startup is gated behind explicit consent. Uses the TVmed logo asset from `web/assets/tvmed-logo-header.png`.
- `tests/device-kiosk-state.test.js` — Node test coverage for the browser kiosk state model and media gating.
- `systemd/tvmed-shell.service` — system service for `tvmed_cec.py listen | tvmed_shell.py --tty /dev/tty1` on the Pi. It runs as root because `/dev/tty1` writes require it on Debian.
- `systemd/tvmed-preflight.service` — oneshot read-only preflight service.
- `MVP_SPEC.md` — current Pi/Samsung/Brio/AWS prototype baseline and next implementation notes.

## Morning test on the Pi

```bash
ssh doogle@192.168.0.238
cd ~/tvmed
./tvmed_morning_test.sh --wake
```

On the Samsung TV, select the Pi HDMI input if needed. Test with the Samsung remote:

1. `Preflight` → OK; confirm checks; Back to menu.
2. `Incoming call mock` → OK; confirm the consent screen appears.
3. OK on consent; confirm `CALL ACTIVE MOCK` appears.
4. Back; confirm `END CALL?`; OK to end.
5. Turn the TV off when done:
   `python3 ./tvmed_cec.py --adapter /dev/cec0 off`

The mock shell deliberately does **not** start real camera/mic/WebRTC media.

## Brio → KVS → browser smoke test

Prototype browser smoke page:

```bash
ssh doogle@192.168.0.238
cd ~/tvmed
./tvmed_kvs_browser_smoke.sh --role MASTER --open
```

The page loads the local AWS/KVS env file, writes a gitignored `web/tvmed-kvs-config.js`, and starts a local web server. Press **Start smoke** in Chromium on the Pi; it will request Brio camera/mic access and connect as KVS `MASTER`.

For a remote viewer, open the same page with viewer-capable credentials and role `VIEWER`. Prefer localhost or an SSH tunnel; `--bind 0.0.0.0` is only for short controlled tests because the generated config file contains AWS credentials.

Focused clinician viewer prototype:

```bash
./tvmed_kvs_clinician_viewer.sh --open
```

This uses viewer-only credentials from `~/.hermes/tvmed-aws-kvs-viewer.env`, serves only on `127.0.0.1`, hides AWS credential fields from the UI, and removes the generated browser config on exit. Start the Pi MASTER kiosk first, then click **Connect viewer**.

## Device browser kiosk prototype

The next-stage Pi browser UI is separate from the raw smoke page:

```bash
ssh doogle@192.168.0.238
cd ~/tvmed
./tvmed_device_kiosk.sh
```

The device kiosk exposes the product state flow: idle → incoming call → consent required → connecting/active call → end-call confirmation/fault. The browser does not call `getUserMedia()` or start the KVS `MASTER` connection until the consent screen is explicitly confirmed. Current prototype controls include a **Test incoming call** button and keyboard Enter/Escape support; real clinician commands/CEC remote wiring come next.

Run local state tests before deployment:

```bash
node tests/device-kiosk-state.test.js
```

## Privacy stance

No silent camera/mic activation. Remote start must be visible, audible, interruptible, logged, and governed by consent/clinical policy.

## Hermes Agent integration stance

Hermes should be integrated as the **operations, support, installation, and note-assistant layer** around TVmed.

Hermes may:

- answer support questions such as “is OPS online?”;
- run device health checks and summarize camera/audio/WebRTC/HDMI status;
- restart non-safety-critical services through allowlisted commands;
- receive scheduled heartbeat/preflight alerts;
- guide installer/carer setup over Telegram or an admin console;
- summarize operational call events and write project/support notes.

Hermes must **not** decide when camera/mic turn on, whether consent is valid, or whether emergency/break-glass access is allowed. Those decisions stay in deterministic TVmed services and auditable clinical policy.
