#!/usr/bin/env python3
"""Bridge Samsung HDMI-CEC remote events into the TVmed browser kiosk.

Reads raw `cec-ctl --monitor --show-raw` output and forwards supported remote
buttons into the X11 kiosk as keyboard events. The browser UI owns the clinical
state machine; this helper only provides couch-friendly input.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import signal
import subprocess
import sys
import threading
from dataclasses import dataclass
from typing import Iterable

CEC_UI_CMD_RE = re.compile(r"ui-cmd:\s*['\"]?([a-zA-Z0-9_ -]+?)['\"]?\s*\((0x[0-9a-fA-F]+)\)")
CEC_USER_CONTROL_RE = re.compile(r"USER_CONTROL_PRESSED.*?\((0x[0-9a-fA-F]+)\)", re.IGNORECASE)
DEFAULT_RECLAIM_INTERVAL_SECONDS = 0

KEY_BY_CODE = {
    "0x00": "select",
    "0x01": "up",
    "0x02": "down",
    "0x03": "left",
    "0x04": "right",
    "0x0d": "exit",
}

KEY_BY_CEC = {
    "select": "Return",
    "up": "Up",
    "down": "Down",
    "left": "Left",
    "right": "Right",
    "back": "Escape",
    "exit": "Escape",
}

ACTION_BY_CEC = {
    "select": "SELECT",
    "up": "UP",
    "down": "DOWN",
    "left": "LEFT",
    "right": "RIGHT",
    "back": "BACK",
    "exit": "BACK",
}


@dataclass(frozen=True)
class BridgeEvent:
    cec_key: str
    cec_code: str
    action: str
    x_key: str | None


def normalize_key(value: str) -> str:
    return value.strip().lower().replace(" ", "_")


def parse_monitor_events(lines: Iterable[str]) -> Iterable[BridgeEvent]:
    for line in lines:
        match = CEC_UI_CMD_RE.search(line)
        if match:
            cec_key = normalize_key(match.group(1))
            cec_code = match.group(2).lower()
        else:
            code_match = CEC_USER_CONTROL_RE.search(line)
            if not code_match:
                continue
            cec_code = code_match.group(1).lower()
            if cec_code in {"0x44", "0x45"}:  # opcode, not the actual remote key
                continue
            cec_key = KEY_BY_CODE.get(cec_code, f"code_{cec_code}")
        if not cec_key:
            continue
        x_key = KEY_BY_CEC.get(cec_key)
        action = ACTION_BY_CEC.get(cec_key, f"UNKNOWN:{cec_key}")
        yield BridgeEvent(
            cec_key=cec_key,
            cec_code=cec_code,
            action=action,
            x_key=x_key,
        )


def emit_x_key(event: BridgeEvent, display: str, dry_run: bool) -> int:
    if not event.x_key:
        return 0
    if dry_run:
        print(f"{event.action} {event.cec_key} {event.cec_code} -> {event.x_key}", flush=True)
        return 0
    env = os.environ.copy()
    env["DISPLAY"] = display
    env.setdefault("XAUTHORITY", os.path.expanduser("~/.Xauthority"))
    proc = subprocess.run(
        ["xdotool", "key", "--clearmodifiers", event.x_key],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    if proc.stdout:
        print(proc.stdout, end="", flush=True)
    return proc.returncode


def emit_browser_remote_event(event: BridgeEvent, dry_run: bool) -> bool:
    """Notify the kiosk page of the raw CEC button.

    Newer kiosk builds consume CEC actions directly through Chrome DevTools so
    the TV remote still works if the X11/browser window focus is stale after a
    scheduled-call CEC wake. Older builds fall back to remote-config capture;
    when the page returns False, the bridge also sends an X11 keypress.
    """
    detail = {
        "action": event.action,
        "cecKey": event.cec_key,
        "cecCode": event.cec_code,
        "source": "cec",
    }
    if dry_run:
        print(f"Browser remote event: {json.dumps(detail, sort_keys=True)}", flush=True)
        return False
    try:
        from tvmed_device_api import find_kiosk_ws_url, websocket_eval

        payload = json.dumps(detail)
        expr = (
            "window.tvmedKiosk && "
            "(window.tvmedKiosk.remoteAction "
            f"? window.tvmedKiosk.remoteAction({payload}) "
            f": window.tvmedKiosk.captureRemoteButton && window.tvmedKiosk.captureRemoteButton({payload}))"
        )
        response = websocket_eval(find_kiosk_ws_url(), expr, timeout=1.0)
        value = response.get("result", {}).get("result", {}).get("value")
        return bool(value)
    except Exception as exc:
        print(f"remote-config browser notify failed: {exc}", file=sys.stderr, flush=True)
        return False


def configure_cec_source(adapter: str, use_sudo: bool, active_source: bool = False) -> dict[str, object]:
    """Claim a logical playback address without hijacking the TV input by default.

    Countdown prepare uses CEC to wake/select the TV. Some CEC tools clear the
    adapter's logical address when they exit; Samsung then stops forwarding
    remote buttons to the Pi even though the kiosk is visible. Re-claiming a
    playback address before monitoring keeps remote-control passthrough alive.

    Sending CEC ``active-source`` also selects the Docbox HDMI input. That is
    appropriate for explicit wake/prepare/reclaim actions, but not for the
    background remote bridge while someone may be watching another TV source.
    """
    base = ["cec-ctl", "-d", adapter]
    if use_sudo and os.geteuid() != 0:
        base = ["sudo", "-n", *base]

    info_proc = subprocess.run(
        [*base, "--physical-address"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    info = info_proc.stdout
    phys = "4.0.0.0"
    match = re.search(r"Physical Address\s*:\s*([0-9a-fA-F.]*)", info)
    if match and match.group(1):
        phys = match.group(1)

    command = [*base, "--playback", "--osd-name", "docbox"]
    if active_source:
        command.extend(["--active-source", f"phys-addr={phys}"])

    proc = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    mode = "active-source" if active_source else "playback-only"
    print(f"CEC source configured: mode={mode} phys={phys} rc={proc.returncode}", flush=True)
    if proc.stdout:
        print(proc.stdout[-1000:], end="" if proc.stdout.endswith("\n") else "\n", flush=True)
    return {"ok": proc.returncode == 0, "returncode": proc.returncode, "phys": phys, "activeSource": active_source, "outputTail": (proc.stdout or "")[-1000:]}


def start_cec_reclaimer(adapter: str, use_sudo: bool, interval_seconds: int) -> threading.Event:
    """Optionally re-claim active source.

    Disabled by default because periodic active-source commands force the TV
    back to the Docbox HDMI input during normal viewing.
    """
    stop_event = threading.Event()
    if interval_seconds <= 0:
        return stop_event

    def loop() -> None:
        while not stop_event.wait(interval_seconds):
            try:
                result = configure_cec_source(adapter, use_sudo, active_source=True)
                print(f"CEC source re-claimed: {json.dumps(result, sort_keys=True)}", flush=True)
            except Exception as exc:
                print(f"CEC source re-claim failed: {exc}", file=sys.stderr, flush=True)

    threading.Thread(target=loop, name="cec-source-reclaimer", daemon=True).start()
    return stop_event


def run_bridge(adapter: str, display: str, dry_run: bool, once: bool, use_sudo: bool, reclaim_interval: int) -> int:
    if not dry_run and not shutil_which("xdotool"):
        print("xdotool is required: sudo apt-get install -y xdotool", file=sys.stderr)
        return 127

    configure_cec_source(adapter, use_sudo, active_source=False)
    reclaimer_stop = start_cec_reclaimer(adapter, use_sudo, 0 if once else reclaim_interval)

    cmd = ["cec-ctl", "-d", adapter, "--monitor", "--show-raw"]
    if use_sudo and os.geteuid() != 0:
        cmd = ["sudo", "-n", *cmd]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    def stop(_signum, _frame):
        reclaimer_stop.set()
        proc.terminate()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    assert proc.stdout is not None
    try:
        for event in parse_monitor_events(proc.stdout):
            print(f"CEC {event.action} ({event.cec_key}/{event.cec_code}) -> X11 {event.x_key or 'none'}", flush=True)
            consumed = emit_browser_remote_event(event, dry_run=dry_run)
            rc = 0 if consumed else emit_x_key(event, display=display, dry_run=dry_run)
            if rc != 0:
                print(f"xdotool failed with exit {rc}", file=sys.stderr, flush=True)
            if once:
                proc.terminate()
                return rc
    finally:
        reclaimer_stop.set()
        if proc.poll() is None:
            proc.terminate()
    return proc.wait() if proc.returncode is not None else 0


def shutil_which(name: str) -> str | None:
    for path in os.environ.get("PATH", "").split(os.pathsep):
        candidate = os.path.join(path, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Bridge HDMI-CEC remote keys to TVmed kiosk X11 key events")
    parser.add_argument("--adapter", default="/dev/cec0")
    parser.add_argument("--display", default=":0")
    parser.add_argument("--no-sudo", action="store_true", help="do not prefix cec-ctl monitor with sudo -n")
    parser.add_argument("--dry-run", action="store_true", help="parse and log events without sending X11 keys")
    parser.add_argument("--once", action="store_true", help="exit after the first bridged key")
    parser.add_argument("--reclaim-interval", type=int, default=int(os.environ.get("TVMED_CEC_RECLAIM_INTERVAL", str(DEFAULT_RECLAIM_INTERVAL_SECONDS))), help="seconds between active-source reclaims; 0 disables (default)")
    args = parser.parse_args(argv)
    return run_bridge(args.adapter, args.display, args.dry_run, args.once, not args.no_sudo, args.reclaim_interval)


if __name__ == "__main__":
    raise SystemExit(main())
