# TVmed — Go-To-Market Brief
**Version:** 0.1  
**Date:** 2026-05-14

---

## Competitive Landscape

### Who exists and what they don't do

| Product | Country | What it does | What TVmed does that they don't |
|---------|---------|-------------|----------------------------------|
| **JubileeTV** | US | Family video calls on TV via HDMI dongle, no phone needed | Clinical workflow, clinician-initiated calls, PTZ control, consent model, audit trail |
| **Independa** | US | Samsung Smart TV senior care platform, video visits + reminders | Works on ANY TV (HDMI appliance), not locked to Samsung; proper consent model; EU-ready |
| **Teladoc Solo + TV device** | US/Global | Hospital HDMI TV dongle for in-patient rooms, enterprise platform | Home-based; no IT team required; EU/Ireland deployment; affordable per-home |
| **Immedicare** | UK | 24/7 video consultation hub for care homes via tablet | TV-native; patient-direct; no carer needed to hold device |
| **Airedale NHS Digital Care Hub** | UK | NHS internal service, care homes + prisons, tablet-based | Product you can buy and deploy; TV-native; home patient |
| **Samsung Healthcare TVs** | Global | Hospital smart TVs with telehealth | Home-based; works with existing TV; no hospital procurement |

### The gap TVmed fills

**No product exists that does all of this:**
- HDMI appliance — works with any TV the patient already has
- **Clinician-initiated** call (not family/patient initiated)
- Designed for patients who **cannot use any device** (no phone, no tablet)
- Full visible consent model — chime, announcement, countdown, TV remote OK/Back
- PTZ camera controlled by clinician during consultation
- GDPR-compliant, EU-hosted, audit trail
- Priced for home/care-home deployment, not hospital enterprise

---

## Market Opportunity

### Ireland — immediate opportunity

**HSE Virtual Ward Programme (live tender)**

The HSE remote health monitoring tender is live right now at etenders.gov.ie (DPS resource ID: 4943789).

- **Scale:** 1.3 million chronic disease patients identified. HSE targeting 20-25% could benefit from remote monitoring = **260,000-325,000 potential users**
- **Contract timeline:** Q2 2026 contracts signed, rollout to end of Q4 2026
- **Specialties:** Respiratory, Cardiology, Oncology, Stroke, Maternity, Older Persons
- **Format:** Single supplier, end-to-end vendor-managed solution
- TVmed is too early to be the prime contractor — but could partner with a bigger vendor winning the contract as a TV/video consultation component

**Private home care agencies (fastest revenue)**
- Home Instead, Bluebird Care, Comfort Keepers, Carer Ireland, Myhomecare
- 50,000+ home care clients in Ireland
- Typical home care visit costs €20-30 — a TVmed check-in could reduce physical visits
- Model: white-label TVmed, per-device/month subscription
- **Target deal size:** €40-60/device/month × 50-500 devices per agency

**Private nursing homes**
- ~430 private nursing homes in Ireland (HIQA registered)
- Average 50-80 residents per home
- TV is already in every room — HDMI appliance is zero infrastructure change
- GP remote rounds: instead of GP visiting, TVmed call from practice
- **Target deal size:** €30-50/room/month × 50 rooms = €1,500-2,500/home/month

### UK — medium term

- NHS @Home / virtual ward expansion — requires DTAC certification
- 5,000+ care homes, mostly using tablets (infection control issues = opportunity)
- Primary Care Networks (PCNs) for housebound patient GP rounds

---

## Key People — HSE

### Decision makers

**Damien McCallion** — HSE Chief Technology & Transformation Officer (CTTO) & Deputy CEO
- Signed off on the remote health monitoring tender announcement (Nov 2025)
- Publicly quoted: *"Remote Health Monitoring Technologies will play a key role in expanding telehealth services... supporting the transition of services into the community"*
- LinkedIn: search Damien McCallion HSE
- **Relevance:** The person with budget and strategy authority for the tender

**Dr Colm Henry** — HSE Chief Clinical Officer (CCO)
- Clinician champion for virtual care
- Part of the National Telehealth Steering Committee
- **Relevance:** Clinical sign-off on new telehealth approaches

**National Telehealth Steering Committee**
- Brings together hospitals, community services, regional health teams, digital teams
- No public membership list found — access via eHealth Ireland events or HIHI

**ICT Programme Manager Telehealth & CAWT** (eHealth Ireland)
- Operational programme manager role — the person actually running the programme day-to-day
- Name not public-facing; contact via eHealth Ireland or conference networking

### Routes in

1. **Health Innovation Hub Ireland (HIHI)** — hihi.ie
   - Government-backed health tech accelerator, works directly with HSE
   - Ran "HIHI.AI" call Dec 2025 (15 winners), regular tender watch newsletter
   - Apply to their next call or reach out directly — they make introductions to HSE
   - Contact: info@hih.ie

2. **Enterprise Ireland Health** — enterprise-ireland.com
   - Covered the HIHI.AI winners, works with HSE CTTO
   - Irish startup support, potential co-funding for product development
   - Health sector team: contact via EI regional office

3. **Irish Health Industry Association (HIIA)** — hiia.ie
   - Industry body; events, networking with procurement leads
   - Good for meeting the right people at HSE informally

4. **eTenders.gov.ie** — the tender itself
   - DPS resource: https://www.etenders.gov.ie/epps/dps/listDPSContractDocuments.do?resourceId=4943789
   - Even if TVmed can't bid as prime contractor, monitoring DPS activity shows which vendors win contracts — those are the ones to partner with

---

## Recommended Go-To-Market Sequence

### Phase 1 — Design partner pilots (now → 6 months)
**Target:** 2-3 private home care agencies in Ireland  
**Goal:** 10-20 deployed devices, paying customers, real clinical evidence

1. Identify 2-3 home care agencies (Home Instead Dublin/Cork, Myhomecare, Carer)
2. Offer a 3-month pilot at cost/near-cost in exchange for clinical evidence and case study rights
3. Document: call completion rates, caregiver time saved, patient/carer satisfaction, clinician feedback
4. Build a GDPR-compliant data processing agreement template

### Phase 2 — Case study + HIHI (months 3-6)
1. Apply to Health Innovation Hub Ireland for validation support
2. Submit TVmed to Enterprise Ireland health sector programme
3. Attend HIHI events to get in front of HSE telehealth and regional health teams
4. Begin DTAC evidence pack (clinical safety, data protection, technical security) — this takes 3-6 months to build properly

### Phase 3 — HSE partner route (months 6-12)
1. Identify which vendors win the HSE remote health monitoring DPS contract
2. Approach them as a TV video consultation add-on component
3. Position TVmed as the solution for the subset of patients who cannot use tablets/phones (~20-30% of the remote monitoring cohort based on digital exclusion data)

### Phase 4 — Care home direct sales (months 9-18)
1. Use home care evidence to approach private nursing home groups (Mowlam, Virtue, Bartra, Curam, Orpea Ireland)
2. Pilot in 2-3 homes, target "GP remote round" use case
3. Build relationship with HIQA (regulator) to understand what documentation they need to see

---

## Pricing Model

| Segment | Model | Est. Price | Notes |
|---------|-------|-----------|-------|
| Home care agency | Per device/month SaaS | €40-60/device/month | Includes hardware amortised or upfront |
| Nursing home | Per room/month | €30-50/room/month | Volume discount for 50+ rooms |
| NHS/HSE procurement | Per patient episode or annual license | TBD — NHS framework pricing | Requires DTAC/DPS qualification |
| Private pay (family) | Hardware + subscription | €199 device + €25/month | Long-term option after B2B established |

Hardware cost per unit: ~€400-500 (Pi 5 + Brio + speakerphone + accessories)  
At €50/month, payback on hardware: 8-10 months

---

## Regulatory Checklist

Before any paid clinical pilot:
- [ ] DPIA completed (Data Protection Impact Assessment)
- [ ] Data Processing Agreement template for customers
- [ ] Lawful basis documented: Article 9(2)(h) GDPR (health care provision)
- [ ] Terms of service + acceptable use policy
- [ ] Clinical Safety Case (DCB0129 equivalent for Ireland)
- [ ] Insurance: product liability + professional indemnity
- [ ] DTAC (UK) — if targeting NHS, start building evidence pack now

---

*Research and brief by Doogle · 2026-05-14*
