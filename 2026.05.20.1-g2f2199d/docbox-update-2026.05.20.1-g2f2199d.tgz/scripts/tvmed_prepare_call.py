#!/usr/bin/env python3
"""Enqueue a TVmed scheduled-call countdown command via doogle.bot.

Intended for Hermes one-shot cron jobs, e.g. schedule this script for ten
minutes before the appointment time. It does not start patient media; it only
wakes/selects the TVmed appliance and displays a countdown. At call time the
kiosk enters the normal incoming-call/consent flow.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


PAST_CALL_GRACE_SECONDS = 30


def parse_call_time(value: str) -> int:
    raw = value.strip()
    if raw.isdigit():
        number = int(raw)
        return number if number > 10_000_000_000 else number * 1000
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    dt = datetime.fromisoformat(raw)
    if dt.tzinfo is None:
        dt = dt.astimezone()
    else:
        dt = dt.astimezone(timezone.utc)
    return int(dt.timestamp() * 1000)


def read_gate_key(path: str) -> str:
    if os.environ.get("TVMED_VIEWER_GATE_KEY"):
        return os.environ["TVMED_VIEWER_GATE_KEY"].strip()
    p = Path(path).expanduser()
    return p.read_text().strip()


def validate_future_call_time(call_time_ms: int, now_ms: int | None = None) -> None:
    """Refuse stale scheduled-call prepare commands.

    A stale wrapper with a past callTime makes the kiosk transition immediately
    from scheduled countdown to Incoming call. That is correct at the actual
    appointment time, but wrong for Telegram scheduling bugs that accidentally
    enqueue old dates. Keep a small grace window for clock skew and exact-now
    tests, but fail loudly for genuinely stale jobs.
    """
    now = int(now_ms if now_ms is not None else datetime.now(timezone.utc).timestamp() * 1000)
    if int(call_time_ms) < now - (PAST_CALL_GRACE_SECONDS * 1000):
        call_dt = datetime.fromtimestamp(int(call_time_ms) / 1000, tz=timezone.utc).astimezone()
        now_dt = datetime.fromtimestamp(now / 1000, tz=timezone.utc).astimezone()
        raise ValueError(f"call time is in the past: {call_dt.isoformat()} (now {now_dt.isoformat()})")


def post_prepare(base_url: str, gate_key: str, payload: dict) -> dict:
    url = f"{base_url.rstrip('/')}/docbox/api/prepare?k={urllib.parse.quote(gate_key)}"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={"content-type": "application/json", "user-agent": "TVmedHermesScheduler/1.0"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        body = resp.read().decode("utf-8")
        data = json.loads(body)
        if resp.status >= 400 or data.get("ok") is False:
            raise RuntimeError(body)
        return data


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Prepare a TVmed patient appliance for a scheduled call")
    parser.add_argument("--device", required=True, help="TVmed device ID, e.g. gateway-host or dylan-pi5")
    parser.add_argument("--patient-label", required=True, help="Human label shown on the TV, e.g. John Doe")
    parser.add_argument("--call-time", required=True, help="ISO datetime or unix timestamp for the actual call time")
    parser.add_argument("--caller-name", default="Clinician")
    parser.add_argument("--base-url", default="https://doogle.bot")
    parser.add_argument("--gate-key-file", default="~/.hermes/tvmed-online-viewer-key")
    args = parser.parse_args(argv)

    payload = {
        "deviceId": args.device,
        "patientLabel": args.patient_label,
        "callerName": args.caller_name,
        "callTime": parse_call_time(args.call_time),
    }
    try:
        validate_future_call_time(payload["callTime"])
    except ValueError as exc:
        print(f"TVmed prepare refused stale call time: {exc}", file=sys.stderr)
        return 1
    try:
        result = post_prepare(args.base_url, read_gate_key(args.gate_key_file), payload)
    except (OSError, urllib.error.URLError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"TVmed prepare failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({"ok": True, "deviceId": args.device, "patientLabel": args.patient_label, "commandId": result.get("commandId")}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
