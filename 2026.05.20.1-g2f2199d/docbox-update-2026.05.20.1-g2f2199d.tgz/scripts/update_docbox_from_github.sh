#!/usr/bin/env bash
set -euo pipefail

# Backwards-compatible wrapper. The durable field-update path is now manifest
# based, so field appliances do not need GitHub credentials and do not depend on
# the private GitHub repo being publicly readable.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/docbox_device_update.sh" "$@"
