#!/usr/bin/env python3
"""Build a no-secrets Docbox release bundle and public manifest.

Output layout (default: dist/docbox-releases):

  dist/docbox-releases/<version>/docbox-update-<version>.tgz
  dist/docbox-releases/<version>/manifest.json
  dist/docbox-releases/stable/manifest.json

Publish the output directory to the public release repo served by GitHub Pages:
  https://graimek311y.github.io/docbox-releases/

Then field devices can run:
  curl -fsSL https://graimek311y.github.io/docbox-releases/stable/install.sh | bash
or, once installed/current:
  /home/doogle/tvmed/scripts/docbox_device_update.sh
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

SECRET_PATTERNS = [
    b"-----BEGIN RSA PRIVATE KEY-----",
    b"-----BEGIN OPENSSH PRIVATE KEY-----",
    b"-----BEGIN EC PRIVATE KEY-----",
]

EXCLUDE_DIRS = {
    ".git",
    ".herenow",
    "backups",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    "dist",
    "releases",
}
EXCLUDE_FILES = {
    ".env",
    "tvmed-device.env",
    "tvmed-kvs-config.js",
}
EXCLUDE_SUFFIXES = {".pyc", ".tgz", ".tar", ".gz"}


def git_sha(repo: Path) -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], cwd=repo, text=True).strip()
    except Exception:
        return "nogit"


def default_version(repo: Path) -> str:
    """Return the Docbox release version: YYYY.MM.DD.N-g<sha>."""
    return f"{datetime.now(timezone.utc).strftime('%Y.%m.%d')}.1-g{git_sha(repo)}"


def copy_tree(repo: Path, stage: Path) -> None:
    for src in repo.rglob("*"):
        rel = src.relative_to(repo)
        if any(part in EXCLUDE_DIRS for part in rel.parts):
            continue
        if src.is_dir():
            continue
        if src.name in EXCLUDE_FILES or src.suffix in EXCLUDE_SUFFIXES:
            continue
        dst = stage / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def scan_for_secrets(stage: Path) -> list[str]:
    findings: list[str] = []
    for path in stage.rglob("*"):
        if not path.is_file():
            continue
        if path.relative_to(stage).as_posix() == "scripts/build_docbox_release.py":
            continue
        data = path.read_bytes()
        for pattern in SECRET_PATTERNS:
            if pattern in data:
                findings.append(f"{path.relative_to(stage)} contains {pattern.decode(errors='ignore')}")
        text = data.decode("utf-8", errors="ignore")
        # Conservative AWS access key detector.
        if "AKIA" in text:
            for match in re.finditer(r"AKIA[0-9A-Z]{16}", text):
                findings.append(f"{path.relative_to(stage)} contains AWS access-key-like value at byte {match.start()}")
        # GitHub token detectors. Avoid matching this scanner's source literals.
        for prefix in ("ghp_", "gho_"):
            for match in re.finditer(prefix + r"[0-9A-Za-z_]{30,}", text):
                findings.append(f"{path.relative_to(stage)} contains GitHub-token-like value at byte {match.start()}")
        # Telegram bot token detector.
        for match in re.finditer(r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b", text):
            findings.append(f"{path.relative_to(stage)} contains Telegram-token-like value at byte {match.start()}")
    return findings


def tar_dir(src_dir: Path, out_path: Path) -> None:
    with tarfile.open(out_path, "w:gz") as tar:
        for path in sorted(src_dir.rglob("*")):
            arcname = path.relative_to(src_dir)
            tar.add(path, arcname=str(arcname))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Build Docbox field-update release bundle")
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--out", type=Path, default=Path("dist/docbox-releases"))
    parser.add_argument("--version", default="")
    parser.add_argument("--base-url", default="https://graimek311y.github.io/docbox-releases")
    parser.add_argument("--channel", default="stable")
    args = parser.parse_args()

    repo = args.repo.resolve()
    version = args.version or default_version(repo)
    out_root = (repo / args.out).resolve() if not args.out.is_absolute() else args.out
    release_dir = out_root / version
    stable_dir = out_root / args.channel
    release_dir.mkdir(parents=True, exist_ok=True)
    stable_dir.mkdir(parents=True, exist_ok=True)
    created_at = datetime.now(timezone.utc).isoformat()

    with tempfile.TemporaryDirectory(prefix="docbox-release-") as tmp:
        stage = Path(tmp) / "package"
        stage.mkdir()
        copy_tree(repo, stage)
        version_payload = {
            "name": "docbox",
            "version": version,
            "channel": args.channel,
            "gitSha": git_sha(repo),
            "createdAt": created_at,
        }
        (stage / "web" / "docbox-version.json").write_text(json.dumps(version_payload, indent=2) + "\n")
        findings = scan_for_secrets(stage)
        if findings:
            print("Secret scan failed:", file=sys.stderr)
            for finding in findings:
                print(f"- {finding}", file=sys.stderr)
            return 2
        bundle_name = f"docbox-update-{version}.tgz"
        bundle_path = release_dir / bundle_name
        tar_dir(stage, bundle_path)

    digest = sha256(bundle_path)
    bundle_url = f"{args.base_url.rstrip('/')}/{version}/{bundle_name}"
    manifest = {
        "schema": 1,
        "minUpdaterSchema": 1,
        "product": "docbox-tvmed",
        "channel": args.channel,
        "version": version,
        "gitSha": git_sha(repo),
        "createdAt": created_at,
        "bundle": {
            "url": bundle_url,
            "sha256": digest,
            "size": bundle_path.stat().st_size,
        },
        "notes": "Generated by scripts/build_docbox_release.py. Bundle excludes secrets/env/local runtime config.",
    }
    (release_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (stable_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    install = f"""#!/usr/bin/env bash
set -euo pipefail
curl -fsSL {args.base_url.rstrip('/')}/{version}/docbox_device_update.sh -o /tmp/docbox_device_update.sh 2>/dev/null || true
if [[ -s /tmp/docbox_device_update.sh ]]; then
  bash /tmp/docbox_device_update.sh {args.base_url.rstrip('/')}/{args.channel}/manifest.json
else
  curl -fsSL {bundle_url} -o /tmp/docbox-update.tgz
  echo 'Installer helper missing; use scripts/docbox_device_update.sh from an already-installed Docbox app.' >&2
  exit 1
fi
"""
    # Also publish the updater script next to each release and in channel root.
    updater_src = repo / "scripts" / "docbox_device_update.sh"
    if updater_src.exists():
        shutil.copy2(updater_src, release_dir / "docbox_device_update.sh")
        shutil.copy2(updater_src, stable_dir / "docbox_device_update.sh")
        (release_dir / "install.sh").write_text(install)
        (stable_dir / "install.sh").write_text(install.replace(f"/{version}/", f"/{args.channel}/"))

    print(json.dumps(manifest, indent=2))
    print(f"\nBuilt release directory: {release_dir}")
    print(f"Publish {out_root} to: {args.base_url.rstrip('/')}/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
