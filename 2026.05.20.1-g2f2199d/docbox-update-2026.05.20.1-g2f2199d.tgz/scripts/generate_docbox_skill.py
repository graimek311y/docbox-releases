#!/usr/bin/env python3
"""Generate the Hermes docbox-control skill from the kiosk/API sources.

The generated skill is intentionally source-derived so kiosk/API additions are not
hand-maintained. Run this after adding kiosk controls:

    python3 scripts/generate_docbox_skill.py --install

It writes docs/docbox-control-skill.md and, with --install, installs/symlinks it
as ~/.hermes/skills/devops/docbox-control/SKILL.md.
"""
from __future__ import annotations

import argparse
import ast
import html.parser
import re
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
API = ROOT / "tvmed_device_api.py"
KIOSK_JS = ROOT / "web" / "device-kiosk.js"
KIOSK_HTML = ROOT / "web" / "device-kiosk.html"
OUTPUT = ROOT / "docs" / "docbox-control-skill.md"
DEFAULT_INSTALL = Path.home() / ".hermes" / "skills" / "devops" / "docbox-control" / "SKILL.md"


@dataclass(frozen=True)
class MenuAction:
    value: str
    label: str


class MaintenanceMenuParser(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.in_menu = False
        self.in_option = False
        self.current_value = ""
        self.current_text: list[str] = []
        self.options: list[MenuAction] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_dict = dict(attrs)
        if tag == "select" and attrs_dict.get("id") == "maintenanceMenu":
            self.in_menu = True
        elif self.in_menu and tag == "option":
            self.in_option = True
            self.current_value = attrs_dict.get("value") or ""
            self.current_text = []

    def handle_data(self, data: str) -> None:
        if self.in_menu and self.in_option:
            self.current_text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if self.in_menu and self.in_option and tag == "option":
            label = " ".join("".join(self.current_text).split())
            if self.current_value:
                self.options.append(MenuAction(self.current_value, label or self.current_value))
            self.in_option = False
        elif self.in_menu and tag == "select":
            self.in_menu = False


def parse_api_paths() -> list[str]:
    tree = ast.parse(API.read_text(encoding="utf-8"))
    paths: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Set):
            strings = {elt.value for elt in node.elts if isinstance(elt, ast.Constant) and isinstance(elt.value, str)}
            if any(s.startswith("/") for s in strings):
                paths.update(s for s in strings if s.startswith("/"))
    return sorted(paths)


def parse_kiosk_exports() -> list[str]:
    text = KIOSK_JS.read_text(encoding="utf-8")
    match = re.search(r"window\.tvmedKiosk\s*=\s*\{(?P<body>.*?)\n\};", text, re.S)
    if not match:
        raise RuntimeError("window.tvmedKiosk export block not found")
    exports: list[str] = []
    for raw in match.group("body").splitlines():
        line = raw.strip().rstrip(",")
        if not line or line.startswith("//"):
            continue
        if ":" in line:
            name = line.split(":", 1)[0].strip()
        else:
            name = line.split("(", 1)[0].strip()
        if re.fullmatch(r"[A-Za-z_$][\w$]*", name):
            exports.append(name)
    return exports


def parse_menu_actions() -> list[MenuAction]:
    parser = MaintenanceMenuParser()
    parser.feed(KIOSK_HTML.read_text(encoding="utf-8"))
    return parser.options


def describe_endpoint(path: str) -> str:
    return {
        "/incoming": "Trigger an incoming call prompt in the kiosk. Does not start camera/mic; consent is still required on screen.",
        "/prepare": "Wake/select the TV and show a scheduled-call countdown until callTime; camera/mic stay off until consent.",
        "/assistance": "Send the welfare/assistance Telegram alert after the declined-call flow.",
        "/notes": "Send patient-entered notes to Telegram.",
        "/request-call": "Send a patient request for doctor/triage callback to Telegram.",
        "/reboot": "Queue a Pi reboot. Loopback is allowed for the kiosk; external callers need the device API token.",
        "/reclaim-remote": "Reclaim HDMI-CEC active-source status so the TV remote controls Docbox again.",
        "/wifi-config": "Open the Pi WiFi/network configuration UI on the kiosk display.",
    }.get(path, "Kiosk/device API endpoint discovered from tvmed_device_api.py.")


def describe_export(name: str) -> str:
    return {
        "dispatch": "Low-level state-machine event dispatcher; use only with known events.",
        "incoming": "Enter incoming-call state for a caller name.",
        "scheduleCall": "Display scheduled-call countdown using callTime/callerName/patientLabel.",
        "clearSchedule": "Clear a scheduled countdown.",
        "startRemoteConfig": "Start TV remote configuration capture.",
        "finishRemoteConfig": "Exit TV remote configuration capture.",
        "setDebugControlVisible": "Toggle/show/hide debug log and device info panel.",
        "captureRemoteButton": "Record a raw remote button during config mode.",
        "remoteAction": "Inject remote action SELECT/UP/DOWN/LEFT/RIGHT/BACK into kiosk UI.",
        "remoteConfigStatus": "Return remote config capture status from the browser.",
        "requestCall": "Fire the kiosk's Request call action.",
        "requestTriage": "Fire the kiosk's Triage action.",
        "wifiConfig": "Call the local API to open WiFi/network configuration on the kiosk display.",
        "reclaimRemote": "Call the local API to reclaim HDMI-CEC remote control.",
        "restartPi": "Call the local API to queue Pi reboot.",
        "snapshot": "Return the kiosk state-machine snapshot.",
    }.get(name, "Kiosk browser control exported by window.tvmedKiosk.")


def endpoint_curl(path: str) -> str:
    payloads = {
        "/incoming": '{"callerName":"Dr Murphy"}',
        "/prepare": '{"callTime":1760000000000,"callerName":"Dr Murphy","patientLabel":"John Doe"}',
        "/assistance": '{"patientLabel":"John Doe","deviceId":"gateway-host","callerName":"Dr Murphy","dryRun":true}',
        "/notes": '{"patientLabel":"John Doe","deviceId":"gateway-host","callerName":"Dr Murphy","notes":"Test note","dryRun":true}',
        "/request-call": '{"patientLabel":"John Doe","deviceId":"gateway-host","callerName":"Dr Murphy","reason":"Patient requested a Doctor from the docbox.tv kiosk.","dryRun":true}',
        "/reboot": '{"dryRun":true}',
        "/reclaim-remote": '{}',
        "/wifi-config": '{}',
    }
    return f"curl -sS -X POST http://127.0.0.1:8091{path} -H 'content-type: application/json' -d '{payloads.get(path, '{}')}'"


def render_skill() -> str:
    api_paths = parse_api_paths()
    exports = parse_kiosk_exports()
    menu = parse_menu_actions()
    menu_lines = "\n".join(f"- `{item.value}` — {item.label}" for item in menu)
    endpoint_lines = "\n".join(f"- `{path}` — {describe_endpoint(path)}" for path in api_paths)
    export_lines = "\n".join(f"- `window.tvmedKiosk.{name}` — {describe_export(name)}" for name in exports)
    curl_blocks = "\n\n".join(f"### {path}\n\n```bash\n{endpoint_curl(path)}\n```" for path in api_paths)
    remote_actions = ", ".join(["SELECT", "UP", "DOWN", "LEFT", "RIGHT", "BACK"])
    return f"""---
name: docbox-control
description: "Use when controlling the deployed docbox.tv/TVmed Raspberry Pi kiosk from Hermes or Telegram. Mirrors kiosk menu actions, local API endpoints, HDMI-CEC controls, and browser state commands."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [docbox, tvmed, raspberry-pi, kiosk, telegram, cec]
    related_skills: [raspberry-pi-appliance-control, hermes-agent]
---

# Docbox Control

Generated from:

- `{API.relative_to(ROOT)}`
- `{KIOSK_JS.relative_to(ROOT)}`
- `{KIOSK_HTML.relative_to(ROOT)}`

Regenerate after kiosk/API changes:

```bash
cd ~/.openclaw/workspace/TVmed
python3 scripts/generate_docbox_skill.py --install
```

When installed on the Docbox Pi, this skill gives Hermes/Telegram the same operator controls as the on-screen kiosk menu and browser API. It is intentionally source-derived: new `window.tvmedKiosk` exports, maintenance menu items, and `tvmed_device_api.py` POST endpoints appear here after regeneration.

## Session references

- `references/scheduled-call-wake-debug.md` — use for Telegram scheduled-call failures: TV not waking, shorthand phrases missed by the deterministic plugin, stale cron wrappers, or countdown skipping straight to Incoming call.
- `references/clinician-viewer-media-controls.md` — clinician viewer installer exposure, patient bitrate/FPS behavior, and future quality-control design notes.
- `references/stage-constrained-video-layout.md` — kiosk video geometry checks for keeping clinician video 16:9 between header and footer.
- `references/vdo-ninja-media-spike.md` — parked research todo for VDO.Ninja/Raspberry Ninja as a possible future media stack.

## Target device

- Name: John Doe Pi / Docbox
- Host/IP: `doogle@192.168.0.238`
- SSH key from Hermes Mac: `~/.ssh/hermes_pi`
- Pi project dir: `/home/doogle/tvmed`
- Local project dir: `~/.openclaw/workspace/TVmed`
- Device API: `http://127.0.0.1:8091`
- Kiosk URL: `http://127.0.0.1:8088/device-kiosk.html`
- Public clinician viewer: `https://doogle.bot/docbox/` (`https://doogle.bot/TVmed/` redirects for human-facing pages)
- Public viewer config: `https://doogle.bot/docbox/tvmed-kvs-config.js`, generated by the Cloudflare Worker behind the viewer gate key/cookie; AWS viewer credentials must not exist in the static Pages bundle.
- Chromium CDP: `127.0.0.1:9222`
- Primary services: `tvmed-device-kiosk.service`, `hermes-gateway.service` user service

## Telegram/Hermes command phrases

Use these phrases in Telegram to ask Hermes on Docbox to run the matching local action:

- "Docbox status" — check kiosk service, Hermes gateway, API port, and browser state.
- "Turn on TV" / "wake Docbox" — call `/reclaim-remote` or `/prepare` as appropriate to wake/select HDMI.
- "Reclaim TV remote" — POST `/reclaim-remote`.
- "Restart Docbox/Pi" — only after explicit user intent, POST `/reboot` without dryRun.
- "Schedule/call John Doe at <time>" — POST `/prepare` with callTime milliseconds, callerName, patientLabel.
- "Call John Doe now" — POST `/incoming` with callerName; camera/mic remain off until on-screen consent.
- "Show debug control" — evaluate `window.tvmedKiosk.setDebugControlVisible(true)` through CDP.
- "Configure remote" — evaluate `window.tvmedKiosk.startRemoteConfig()` through CDP.
- "Press OK/up/down/left/right/back on Docbox" — evaluate `window.tvmedKiosk.remoteAction('<ACTION>')` where action is one of: {remote_actions}.
- "Docbox snapshot" — evaluate `window.tvmedKiosk.snapshot()` through CDP.

## Maintenance menu actions discovered from HTML

{menu_lines}

## Device API endpoints discovered from Python

{endpoint_lines}

## Browser control exports discovered from JavaScript

{export_lines}

## Local API command recipes

Run these on the Pi. From Hermes on the Mac, wrap with:

```bash
ssh -i ~/.ssh/hermes_pi -o BatchMode=yes doogle@192.168.0.238 '<command>'
```

{curl_blocks}

## CDP browser command recipes

Use CDP for controls that are browser-only and do not have an HTTP endpoint. Prefer this helper from `/home/doogle/tvmed` because it already knows how to find the kiosk page:

```bash
python3 - <<'PY'
import json
import tvmed_device_api as api
expr = "window.tvmedKiosk && window.tvmedKiosk.snapshot()"
print(json.dumps(api.websocket_eval(api.find_kiosk_ws_url(), expr), indent=2))
PY
```

Common expressions:

```javascript
window.tvmedKiosk.snapshot()
window.tvmedKiosk.setDebugControlVisible(true)
window.tvmedKiosk.startRemoteConfig()
window.tvmedKiosk.finishRemoteConfig()
window.tvmedKiosk.remoteAction('SELECT')
window.tvmedKiosk.remoteAction('BACK')
window.tvmedKiosk.requestCall()
window.tvmedKiosk.requestTriage()
window.tvmedKiosk.clearSchedule()
```

## Safety rules

- Public clinician viewer route is `https://doogle.bot/docbox/`; legacy `/TVmed/` is human-facing redirect only. Keep device/API poll compatibility for older Pi configs until all deployed env files move.
- If **Call selected patient** is disabled in the clinician viewer, first check whether `window.TVMED_KVS_CONFIG.callTriggerUrl` is empty. Common cause after route/gate changes: the page loaded `tvmed-kvs-config.js` without forwarding the gate key/cookie. Fix the static HTML loader so `tvmed-kvs-config.js` receives `window.location.search`, then verify gated config includes `/docbox/api/incoming`.
- `/incoming` and `/prepare` must never start camera/mic directly. They only change kiosk state; the patient must still consent on screen.
- Treat `/reboot` as destructive/disruptive. Dry-run first unless Graeme explicitly asked to restart.
- Loopback bypass is intentionally narrow. External API calls require `x-tvmed-token`; do not put tokens in this skill.
- After any control action, verify with either `window.tvmedKiosk.snapshot()`, service status, or the API response.
- For TV remote issues, reclaim CEC first, then test `remoteAction`/CDP before blaming the physical remote.

## Verification commands

```bash
systemctl --user is-active hermes-gateway.service
systemctl is-active tvmed-device-kiosk.service
curl -sS http://127.0.0.1:8088/device-kiosk.html | grep -q 'docbox.tv Device Kiosk'
curl -sS -X POST http://127.0.0.1:8091/reclaim-remote -H 'content-type: application/json' -d '{{}}'
python3 - <<'PY'
import json
import tvmed_device_api as api
print(json.dumps(api.websocket_eval(api.find_kiosk_ws_url(), "window.tvmedKiosk.snapshot()"), indent=2))
PY
```

## Keeping this skill current

This file is generated. Do not hand-edit the installed copy. When adding a kiosk feature:

1. Add/modify the kiosk button/menu/API/export.
2. Run `python3 scripts/generate_docbox_skill.py --install`.
3. Run `python3 scripts/generate_docbox_skill.py --check` in tests/CI.
4. Deploy `docs/docbox-control-skill.md` or install it as `~/.hermes/skills/devops/docbox-control/SKILL.md` on the Docbox Pi.
5. Restart Hermes Gateway or start a new session so the updated skill can be loaded.
"""


def write_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def install_skill(source: Path, dest: Path = DEFAULT_INSTALL) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        if dest.exists() or dest.is_symlink():
            dest.unlink()
        dest.symlink_to(source)
    except OSError:
        write_atomic(dest, source.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--install", action="store_true", help="install/symlink into ~/.hermes/skills/devops/docbox-control/SKILL.md")
    parser.add_argument("--check", action="store_true", help="fail if docs/docbox-control-skill.md is stale")
    parser.add_argument("--install-path", type=Path, default=DEFAULT_INSTALL)
    args = parser.parse_args()

    content = render_skill()
    if args.check:
        existing = OUTPUT.read_text(encoding="utf-8") if OUTPUT.exists() else ""
        if existing != content:
            print(f"{OUTPUT} is stale; run python3 scripts/generate_docbox_skill.py --install")
            return 1
        print(f"{OUTPUT} is current")
    else:
        write_atomic(OUTPUT, content)
        print(f"wrote {OUTPUT}")

    if args.install:
        install_skill(OUTPUT, args.install_path)
        print(f"installed {args.install_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
