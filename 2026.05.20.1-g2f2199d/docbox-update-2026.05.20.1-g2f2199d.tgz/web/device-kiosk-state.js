/* TVmed deterministic browser-kiosk state model. */
'use strict';

(function attach(root) {
  const STATES = Object.freeze({
    IDLE: 'idle',
    INCOMING: 'incoming',
    CONSENT: 'consent',
    CONNECTING: 'connecting',
    ACTIVE: 'active',
    END_CONFIRM: 'end_confirm',
    DECLINED_OK_CHECK: 'declined_ok_check',
    DECLINED_ASSISTANCE_CHECK: 'declined_assistance_check',
    DECLINED_ASSISTANCE_SENT: 'declined_assistance_sent',
    FAULT: 'fault',
  });

  class DeviceKioskStateMachine {
    constructor(now = () => Date.now()) {
      this.now = now;
      this.state = STATES.IDLE;
      this.mediaAllowed = false;
      this.callerName = '';
      this.message = '';
      this.callStartedAt = null;
      this.scheduledCall = null;
      this.audit = [];
      this.record('idle');
    }

    snapshot() {
      return {
        state: this.state,
        mediaAllowed: this.mediaAllowed,
        callerName: this.callerName,
        message: this.message,
        callStartedAt: this.callStartedAt,
        scheduledCall: this.scheduledCall ? { ...this.scheduledCall } : null,
        audit: this.audit.slice(),
      };
    }

    record(event, detail) {
      this.audit.push({ at: new Date(this.now()).toISOString(), event, detail: detail || null, state: this.state });
    }

    setState(state, mediaAllowed, event, detail) {
      this.state = state;
      this.mediaAllowed = Boolean(mediaAllowed);
      this.record(event, detail);
      return this.snapshot();
    }

    dispatch(event, detail = {}) {
      switch (event) {
        case 'scheduleCall': {
          if (this.state !== STATES.IDLE) return this.snapshot();
          const callTime = Number(detail.callTime || 0);
          if (!Number.isFinite(callTime) || callTime <= 0) return this.snapshot();
          this.scheduledCall = {
            callTime,
            callerName: detail.callerName || 'Clinician',
            patientLabel: detail.patientLabel || 'Patient',
          };
          this.message = 'Scheduled call countdown';
          return this.setState(STATES.IDLE, false, event, this.scheduledCall);
        }

        case 'clearSchedule':
          if (this.state !== STATES.IDLE) return this.snapshot();
          this.scheduledCall = null;
          this.message = '';
          return this.setState(STATES.IDLE, false, event);

        case 'incoming':
          if (this.state !== STATES.IDLE) return this.snapshot();
          this.scheduledCall = null;
          this.callerName = detail.callerName || 'Clinician';
          this.message = `${this.callerName} is calling`;
          return this.setState(STATES.INCOMING, false, event, { callerName: this.callerName });

        case 'acceptIncoming':
          if (this.state !== STATES.INCOMING) return this.snapshot();
          this.message = 'Consent required before camera or microphone starts';
          return this.setState(STATES.CONSENT, false, event);

        case 'decline':
          if (![STATES.INCOMING, STATES.CONSENT].includes(this.state)) return this.snapshot();
          this.message = 'Are you OK?';
          this.scheduledCall = null;
          this.callStartedAt = null;
          return this.setState(STATES.DECLINED_OK_CHECK, false, event, { callerName: this.callerName });

        case 'patientOkYes':
          if (this.state !== STATES.DECLINED_OK_CHECK) return this.snapshot();
          this.message = 'Thank you';
          this.callerName = '';
          return this.setState(STATES.IDLE, false, event);

        case 'patientOkNo':
          if (this.state !== STATES.DECLINED_OK_CHECK) return this.snapshot();
          this.message = 'Do you need assistance?';
          return this.setState(STATES.DECLINED_ASSISTANCE_CHECK, false, event, { callerName: this.callerName });

        case 'assistanceNo':
          if (this.state !== STATES.DECLINED_ASSISTANCE_CHECK) return this.snapshot();
          this.message = 'Thank you';
          this.callerName = '';
          return this.setState(STATES.IDLE, false, event);

        case 'assistanceYes':
          if (this.state !== STATES.DECLINED_ASSISTANCE_CHECK) return this.snapshot();
          this.message = 'Assistance requested';
          return this.setState(STATES.DECLINED_ASSISTANCE_SENT, false, event, { callerName: this.callerName });

        case 'assistanceSentAck':
          if (this.state !== STATES.DECLINED_ASSISTANCE_SENT) return this.snapshot();
          this.message = '';
          this.callerName = '';
          return this.setState(STATES.IDLE, false, event);

        case 'confirmConsent':
          if (this.state !== STATES.CONSENT) return this.snapshot();
          this.message = 'Connecting secure video…';
          this.callStartedAt = this.now();
          return this.setState(STATES.CONNECTING, true, event);

        case 'mediaConnected':
          if (this.state !== STATES.CONNECTING) return this.snapshot();
          this.message = 'Call active';
          return this.setState(STATES.ACTIVE, true, event);

        case 'requestEnd':
          if (![STATES.CONNECTING, STATES.ACTIVE].includes(this.state)) return this.snapshot();
          this.message = 'Confirm end call';
          return this.setState(STATES.END_CONFIRM, true, event);

        case 'cancelEnd':
          if (this.state !== STATES.END_CONFIRM) return this.snapshot();
          this.message = 'Call active';
          return this.setState(STATES.ACTIVE, true, event);

        case 'confirmEnd':
          if (this.state !== STATES.END_CONFIRM) return this.snapshot();
          this.message = 'Call ended';
          this.callerName = '';
          this.scheduledCall = null;
          this.callStartedAt = null;
          return this.setState(STATES.IDLE, false, event);

        case 'fault':
          this.message = detail.message || 'Device needs attention';
          return this.setState(STATES.FAULT, false, event, { message: this.message });

        case 'clearFault':
          if (this.state !== STATES.FAULT) return this.snapshot();
          this.message = '';
          this.callerName = '';
          this.scheduledCall = null;
          this.callStartedAt = null;
          return this.setState(STATES.IDLE, false, event);

        default:
          this.record('ignored', { event });
          return this.snapshot();
      }
    }
  }

  const api = { STATES, DeviceKioskStateMachine };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.TVMED_DEVICE_STATE = api;
})(typeof window !== 'undefined' ? window : globalThis);
