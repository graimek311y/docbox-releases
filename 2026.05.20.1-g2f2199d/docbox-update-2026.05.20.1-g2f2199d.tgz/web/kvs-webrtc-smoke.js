/* global AWS, KVSWebRTC, TVMED_KVS_CONFIG */
'use strict';

const $ = (id) => document.getElementById(id);
const logEl = $('log');
const localView = $('localView');
const remoteView = $('remoteView');
let signalingClient = null;
let peerConnection = null;
let localStream = null;
let masterRemoteClientId = null;

function log(message, data) {
  const stamp = new Date().toISOString();
  const suffix = data === undefined ? '' : ` ${JSON.stringify(data, null, 2)}`;
  logEl.textContent += `[${stamp}] ${message}${suffix}\n`;
  logEl.scrollTop = logEl.scrollHeight;
}

function randomClientId() {
  return `tvmed-${Math.random().toString(36).slice(2, 10)}`;
}

function fields() {
  return {
    role: $('role').value,
    region: $('region').value.trim(),
    channelName: $('channelName').value.trim(),
    clientId: $('clientId').value.trim() || randomClientId(),
    accessKeyId: $('accessKeyId').value.trim(),
    secretAccessKey: $('secretAccessKey').value,
    sessionToken: $('sessionToken').value.trim(),
  };
}

function applyConfig(config) {
  if (!config) return;
  for (const key of ['role', 'region', 'channelName', 'clientId', 'accessKeyId', 'secretAccessKey', 'sessionToken']) {
    if (config[key]) $(key).value = config[key];
  }
}

function saveConfig() {
  const cfg = fields();
  localStorage.setItem('tvmed-kvs-smoke', JSON.stringify(cfg));
  log('Saved settings to browser localStorage.');
}

function endpointByProtocol(endpoints, protocol) {
  const item = endpoints.find((e) => e.Protocol === protocol);
  if (!item) throw new Error(`KVS endpoint missing protocol ${protocol}`);
  return item.ResourceEndpoint;
}

async function getChannelArn(kinesisVideo, channelName) {
  const desc = await kinesisVideo.describeSignalingChannel({ ChannelName: channelName }).promise();
  const info = desc.ChannelInfo || {};
  if (info.ChannelStatus !== 'ACTIVE') throw new Error(`Channel is ${info.ChannelStatus || 'unknown'}, not ACTIVE`);
  return info.ChannelARN;
}

async function start() {
  stop();
  const cfg = fields();
  if (!cfg.accessKeyId || !cfg.secretAccessKey) throw new Error('AWS credentials are required.');
  $('clientId').value = cfg.clientId;

  AWS.config.update({
    region: cfg.region,
    credentials: new AWS.Credentials({
      accessKeyId: cfg.accessKeyId,
      secretAccessKey: cfg.secretAccessKey,
      sessionToken: cfg.sessionToken || undefined,
    }),
  });

  log(`Starting ${cfg.role} on ${cfg.channelName}/${cfg.region} as ${cfg.clientId}`);
  const kinesisVideo = new AWS.KinesisVideo({ region: cfg.region });
  const channelARN = await getChannelArn(kinesisVideo, cfg.channelName);
  log('Resolved channel ARN suffix', channelARN.split('/').slice(-2).join('/'));

  const endpointResp = await kinesisVideo.getSignalingChannelEndpoint({
    ChannelARN: channelARN,
    SingleMasterChannelEndpointConfiguration: {
      Protocols: ['WSS', 'HTTPS'],
      Role: cfg.role,
    },
  }).promise();
  const endpoints = endpointResp.ResourceEndpointList || [];
  const wssEndpoint = endpointByProtocol(endpoints, 'WSS');
  const httpsEndpoint = endpointByProtocol(endpoints, 'HTTPS');
  log('Resolved endpoints', endpoints.map((e) => e.Protocol));

  const signaling = new AWS.KinesisVideoSignalingChannels({ region: cfg.region, endpoint: httpsEndpoint });
  const iceResp = await signaling.getIceServerConfig({ ChannelARN: channelARN }).promise();
  const iceServers = [
    { urls: `stun:stun.kinesisvideo.${cfg.region}.amazonaws.com:443` },
    ...(iceResp.IceServerList || []).map((server) => ({
      urls: server.Uris,
      username: server.Username,
      credential: server.Password,
    })),
  ];
  log('ICE servers ready', { count: iceServers.length });

  peerConnection = new RTCPeerConnection({ iceServers, iceTransportPolicy: 'all' });
  peerConnection.addEventListener('icecandidate', ({ candidate }) => {
    if (!candidate || !signalingClient) return;
    if (cfg.role === 'MASTER') {
      if (!masterRemoteClientId) return;
      signalingClient.sendIceCandidate(candidate, masterRemoteClientId);
    } else {
      signalingClient.sendIceCandidate(candidate);
    }
    log('Sent ICE candidate');
  });
  peerConnection.addEventListener('track', (event) => {
    remoteView.srcObject = event.streams[0];
    log('Remote track received', { kind: event.track.kind });
  });
  peerConnection.addEventListener('connectionstatechange', () => log(`Peer state: ${peerConnection.connectionState}`));
  peerConnection.addEventListener('iceconnectionstatechange', () => log(`ICE state: ${peerConnection.iceConnectionState}`));

  if (cfg.role === 'MASTER') {
    localStream = await navigator.mediaDevices.getUserMedia({
      // First smoke focuses on visible Brio video. Audio is added after video
      // preview works; requesting audio on the headless Pi can stall Chromium
      // when ALSA device selection is unhappy.
      video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
      audio: false,
    });
    localView.srcObject = localStream;
    localView.muted = true;
    await localView.play().catch((err) => log('Local preview play warning', { message: err.message }));
    for (const track of localStream.getTracks()) peerConnection.addTrack(track, localStream);
    log('MASTER local media started', localStream.getTracks().map((t) => `${t.kind}:${t.label || '(no label)'}`));
  } else {
    peerConnection.addTransceiver('video', { direction: 'recvonly' });
    peerConnection.addTransceiver('audio', { direction: 'recvonly' });
  }

  signalingClient = new KVSWebRTC.SignalingClient({
    channelARN,
    channelEndpoint: wssEndpoint,
    role: KVSWebRTC.Role[cfg.role],
    region: cfg.region,
    credentials: AWS.config.credentials,
    clientId: cfg.role === 'VIEWER' ? cfg.clientId : undefined,
    systemClockOffset: kinesisVideo.config.systemClockOffset,
  });

  signalingClient.on('open', async () => {
    log('Signaling open');
    if (cfg.role === 'VIEWER') {
      const offer = await peerConnection.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
      await peerConnection.setLocalDescription(offer);
      signalingClient.sendSdpOffer(peerConnection.localDescription);
      log('VIEWER sent SDP offer');
    }
  });
  signalingClient.on('sdpOffer', async (offer, remoteClientId) => {
    masterRemoteClientId = remoteClientId;
    log('MASTER received SDP offer', { remoteClientId });
    await peerConnection.setRemoteDescription(offer);
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    signalingClient.sendSdpAnswer(peerConnection.localDescription, remoteClientId);
    log('MASTER sent SDP answer');
  });
  signalingClient.on('sdpAnswer', async (answer) => {
    log('VIEWER received SDP answer');
    await peerConnection.setRemoteDescription(answer);
  });
  signalingClient.on('iceCandidate', async (candidate) => {
    await peerConnection.addIceCandidate(candidate);
    log('Received ICE candidate');
  });
  signalingClient.on('close', () => log('Signaling closed'));
  signalingClient.on('error', (err) => log('Signaling error', { message: String(err && err.message ? err.message : err) }));
  signalingClient.open();
}

function stop() {
  masterRemoteClientId = null;
  if (signalingClient) { try { signalingClient.close(); } catch (_) {} signalingClient = null; }
  if (peerConnection) { try { peerConnection.close(); } catch (_) {} peerConnection = null; }
  if (localStream) { for (const track of localStream.getTracks()) track.stop(); localStream = null; }
  localView.srcObject = null;
  remoteView.srcObject = null;
}

$('save').addEventListener('click', saveConfig);
$('start').addEventListener('click', () => start().catch((err) => log('START FAILED', { message: err.message, stack: err.stack })));
$('stop').addEventListener('click', () => { stop(); log('Stopped'); });
$('copy').addEventListener('click', async () => { await navigator.clipboard.writeText(logEl.textContent); log('Copied log'); });

try { applyConfig(JSON.parse(localStorage.getItem('tvmed-kvs-smoke') || 'null')); } catch (_) {}
applyConfig(window.TVMED_KVS_CONFIG || {});
if (!$('clientId').value) $('clientId').value = randomClientId();
log('Loaded. Start MASTER on the Pi/Brio browser first, then VIEWER in a second browser with viewer-capable credentials.');
