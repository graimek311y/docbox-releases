#!/usr/bin/env python3
"""Tiny local/LAN control API for the TVmed device kiosk prototype.

The API never starts media directly. `/incoming` only asks the already-running
browser kiosk to enter its `incoming` state via Chromium DevTools Protocol. The
browser state machine still gates camera/mic behind on-screen consent.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import http.client
import json
import os
import socket
import struct
import subprocess
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen


def http_json(host: str, port: int, path: str, timeout: float = 2.0) -> Any:
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        conn.request("GET", path)
        resp = conn.getresponse()
        body = resp.read()
        if resp.status >= 400:
            raise RuntimeError(f"GET {path} failed: HTTP {resp.status} {body[:200]!r}")
        return json.loads(body.decode("utf-8"))
    finally:
        conn.close()


def find_kiosk_ws_url(host: str = "127.0.0.1", port: int = 9222) -> str:
    pages = http_json(host, port, "/json")
    for page in pages:
        url = page.get("url", "")
        if "device-kiosk.html" in url and page.get("webSocketDebuggerUrl"):
            return page["webSocketDebuggerUrl"]
    for page in pages:
        if page.get("type") == "page" and page.get("webSocketDebuggerUrl"):
            return page["webSocketDebuggerUrl"]
    raise RuntimeError("No Chromium page target found for device kiosk")


def websocket_eval(ws_url: str, expression: str, timeout: float = 3.0) -> Any:
    parsed = urlparse(ws_url)
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or 80
    path = parsed.path + (f"?{parsed.query}" if parsed.query else "")
    key = base64.b64encode(os.urandom(16)).decode("ascii")

    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        request = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        sock.sendall(request.encode("ascii"))
        header = b""
        while b"\r\n\r\n" not in header:
            chunk = sock.recv(4096)
            if not chunk:
                raise RuntimeError("WebSocket handshake closed")
            header += chunk
        if b" 101 " not in header.split(b"\r\n", 1)[0]:
            raise RuntimeError(f"WebSocket handshake failed: {header[:200]!r}")

        payload = json.dumps({
            "id": 1,
            "method": "Runtime.evaluate",
            "params": {"expression": expression, "awaitPromise": False, "returnByValue": True},
        }).encode("utf-8")
        sock.sendall(encode_ws_text(payload))

        deadline = time.time() + timeout
        while time.time() < deadline:
            message = recv_ws_message(sock)
            if not message:
                continue
            data = json.loads(message.decode("utf-8"))
            if data.get("id") == 1:
                if "exceptionDetails" in data.get("result", {}):
                    raise RuntimeError(json.dumps(data["result"]["exceptionDetails"]))
                return data
        raise RuntimeError("Timed out waiting for Runtime.evaluate response")


def encode_ws_text(payload: bytes) -> bytes:
    mask_key = os.urandom(4)
    length = len(payload)
    head = bytearray([0x81])
    if length < 126:
        head.append(0x80 | length)
    elif length < 65536:
        head.append(0x80 | 126)
        head.extend(struct.pack("!H", length))
    else:
        head.append(0x80 | 127)
        head.extend(struct.pack("!Q", length))
    masked = bytes(byte ^ mask_key[i % 4] for i, byte in enumerate(payload))
    return bytes(head) + mask_key + masked


def recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks = []
    remaining = n
    while remaining:
        chunk = sock.recv(remaining)
        if not chunk:
            raise RuntimeError("WebSocket closed")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def recv_ws_message(sock: socket.socket) -> bytes:
    first, second = recv_exact(sock, 2)
    opcode = first & 0x0F
    masked = bool(second & 0x80)
    length = second & 0x7F
    if length == 126:
        length = struct.unpack("!H", recv_exact(sock, 2))[0]
    elif length == 127:
        length = struct.unpack("!Q", recv_exact(sock, 8))[0]
    mask_key = recv_exact(sock, 4) if masked else b""
    payload = recv_exact(sock, length)
    if masked:
        payload = bytes(byte ^ mask_key[i % 4] for i, byte in enumerate(payload))
    if opcode == 0x8:
        raise RuntimeError("WebSocket closed by peer")
    if opcode == 0x9:  # ping: ignored for this one-shot client
        return b""
    return payload


def trigger_incoming(caller_name: str, cdp_host: str = "127.0.0.1", cdp_port: int = 9222) -> Any:
    caller_json = json.dumps(caller_name or "Clinician")
    expression = f"window.tvmedKiosk && window.tvmedKiosk.incoming({caller_json})"
    ws_url = find_kiosk_ws_url(cdp_host, cdp_port)
    return websocket_eval(ws_url, expression)


def schedule_call(call_time_ms: int, caller_name: str, patient_label: str, cdp_host: str = "127.0.0.1", cdp_port: int = 9222) -> Any:
    payload_json = json.dumps({
        "callTime": int(call_time_ms),
        "callerName": caller_name or "Clinician",
        "patientLabel": patient_label or "Patient",
    })
    expression = f"window.tvmedKiosk && window.tvmedKiosk.scheduleCall({payload_json})"
    ws_url = find_kiosk_ws_url(cdp_host, cdp_port)
    return websocket_eval(ws_url, expression)


def shutil_which(name: str) -> str | None:
    for path in os.environ.get("PATH", "").split(os.pathsep):
        candidate = os.path.join(path, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def wake_tv(adapter: str = "/dev/cec0", timeout: float = 5.0) -> dict[str, Any]:
    if not adapter:
        return {"ok": False, "skipped": True, "reason": "adapter not configured"}

    if shutil_which("cec-ctl"):
        try:
            info = subprocess.run(
                ["cec-ctl", "-d", adapter, "--physical-address"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            ).stdout
            phys = "4.0.0.0"
            for line in info.splitlines():
                if "Physical Address" in line and ":" in line:
                    candidate = line.split(":", 1)[1].strip()
                    if candidate:
                        phys = candidate
                        break
            view_on = subprocess.run(
                ["cec-ctl", "-d", adapter, "--playback", "--osd-name", "TVmed", "--to", "0", "--image-view-on"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
            active = subprocess.run(
                ["cec-ctl", "-d", adapter, "--playback", "--osd-name", "TVmed", "--active-source", f"phys-addr={phys}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
            output = (view_on.stdout or "") + (active.stdout or "")
            rc = view_on.returncode or active.returncode
            return {"ok": rc == 0, "returncode": rc, "method": "cec-ctl", "phys": phys, "outputTail": output[-500:]}
        except subprocess.TimeoutExpired as exc:
            return {"ok": False, "error": "cec-ctl timeout", "outputTail": (exc.stdout or "")[-500:]}

    cmd = ["cec-client", "-s", "-d", "1", adapter]
    try:
        proc = subprocess.run(
            cmd,
            input="on 0\nas\n",
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
        )
        return {"ok": proc.returncode == 0, "returncode": proc.returncode, "outputTail": proc.stdout[-500:]}
    except FileNotFoundError:
        return {"ok": False, "error": "cec-client not installed"}
    except subprocess.TimeoutExpired as exc:
        return {"ok": False, "error": "cec-client timeout", "outputTail": (exc.stdout or "")[-500:]}


def load_env_file(path: str) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        with open(os.path.expanduser(path), "r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                value = value.strip().strip('"').strip("'")
                values[key.strip()] = value
    except FileNotFoundError:
        pass
    return values


def env_value(name: str, default: str = "") -> str:
    if os.environ.get(name):
        return os.environ[name]
    return load_env_file("~/.hermes/.env").get(name, default)


def send_telegram_message(message: str, dry_run: bool = False, timeout: float = 5.0) -> dict[str, Any]:
    token = env_value("TELEGRAM_BOT_TOKEN")
    chat_id = env_value("TELEGRAM_HOME_CHANNEL") or env_value("TELEGRAM_CHAT_ID") or "8741918118"
    if dry_run:
        return {"ok": True, "dryRun": True, "chatId": chat_id, "message": message}
    if not token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN missing")
    payload = json.dumps({"chat_id": chat_id, "text": message}).encode("utf-8")
    req = Request(
        f"https://api.telegram.org/bot{token}/sendMessage",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
    parsed = json.loads(body)
    if not parsed.get("ok"):
        raise RuntimeError(f"Telegram send failed: {body[:300]}")
    return {"ok": True, "chatId": chat_id, "telegramMessageId": parsed.get("result", {}).get("message_id")}


def send_telegram_assistance_alert(data: dict[str, Any], dry_run: bool = False, timeout: float = 5.0) -> dict[str, Any]:
    patient = str(data.get("patientLabel") or "Patient")[:80]
    device = str(data.get("deviceId") or "device")[:80]
    caller = str(data.get("callerName") or "Clinician")[:80]
    at = str(data.get("at") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))[:80]
    message = (
        "🚨 TVmed assistance requested\n"
        f"Patient: {patient}\n"
        f"Device: {device}\n"
        f"After declining call from: {caller}\n"
        "Patient answered: not OK, needs assistance\n"
        f"Time: {at}"
    )
    return send_telegram_message(message, dry_run=dry_run, timeout=timeout)


def send_telegram_doctor_notes(data: dict[str, Any], dry_run: bool = False, timeout: float = 5.0) -> dict[str, Any]:
    patient = str(data.get("patientLabel") or "Patient")[:80]
    device = str(data.get("deviceId") or "device")[:80]
    caller = str(data.get("callerName") or "Dr Murphy")[:80]
    at = str(data.get("at") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))[:80]
    notes = str(data.get("notes") or "").strip()
    if not notes:
        raise RuntimeError("notes required")
    notes = notes[:1800]
    message = (
        "📝 docbox.tv notes for doctor\n"
        f"Patient: {patient}\n"
        f"Doctor: {caller}\n"
        f"Device: {device}\n"
        f"Time: {at}\n\n"
        f"{notes}"
    )
    return send_telegram_message(message, dry_run=dry_run, timeout=timeout)


def send_telegram_call_request(data: dict[str, Any], dry_run: bool = False, timeout: float = 5.0) -> dict[str, Any]:
    patient = str(data.get("patientLabel") or "Patient")[:80]
    device = str(data.get("deviceId") or "device")[:80]
    caller = str(data.get("callerName") or "Dr Murphy")[:80]
    reason = str(data.get("reason") or "Patient requested a Doctor from the docbox.tv kiosk.")[:240]
    at = str(data.get("at") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))[:80]
    message = (
        "📞 docbox.tv call requested\n"
        f"Patient: {patient}\n"
        f"Doctor: {caller}\n"
        f"Device: {device}\n"
        f"Reason: {reason}\n"
        f"Time: {at}"
    )
    return send_telegram_message(message, dry_run=dry_run, timeout=timeout)


def queue_reboot(delay_seconds: int = 2) -> dict[str, Any]:
    delay = max(1, min(int(delay_seconds or 2), 30))
    command = f"sleep {delay}; sudo -n /sbin/reboot || sudo -n /usr/sbin/reboot || /sbin/reboot || /usr/sbin/reboot"
    subprocess.Popen(
        ["/bin/sh", "-c", command],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return {"ok": True, "queued": True, "delaySeconds": delay}


def launch_wifi_config(display: str = ":0") -> dict[str, Any]:
    """Open the Pi's WiFi/network configuration UI on the kiosk display."""
    env = os.environ.copy()
    env.setdefault("DISPLAY", display or ":0")
    xauthority = os.environ.get("XAUTHORITY") or ""
    if not xauthority:
        try:
            ps = subprocess.run(
                ["pgrep", "-a", "Xorg"],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=2,
                check=False,
            )
            parts = ps.stdout.split()
            if "-auth" in parts:
                xauthority = parts[parts.index("-auth") + 1]
        except Exception:
            xauthority = ""
    env["XAUTHORITY"] = xauthority or os.path.expanduser("~/.Xauthority")
    env.setdefault("LANG", "C.UTF-8")

    candidates = [
        ["nm-connection-editor"],
        ["xterm", "-fa", "Monospace", "-fs", "18", "-geometry", "120x36", "-e", "nmtui"],
        ["lxterminal", "-e", "nmtui"],
        ["x-terminal-emulator", "-e", "nmtui"],
    ]
    tried: list[str] = []
    for cmd in candidates:
        if not shutil_which(cmd[0]):
            tried.append(f"{cmd[0]}: not installed")
            continue
        try:
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=env,
                start_new_session=True,
            )
            if cmd[0] in {"xterm", "lxterminal", "x-terminal-emulator"} and shutil_which("xdotool"):
                subprocess.Popen(
                    [
                        "/bin/sh",
                        "-c",
                        f"sleep 0.8; xdotool search --class XTerm windowraise windowfocus 2>/dev/null || "
                        f"xdotool search --name nmtui windowraise windowfocus 2>/dev/null || true; "
                        f"while xdotool search --class XTerm >/dev/null 2>&1 || xdotool search --name nmtui >/dev/null 2>&1; do sleep 0.5; done; "
                        f"sleep 0.3; "
                        f"w=$(xdotool search --name 'docbox.tv Device Kiosk' 2>/dev/null | head -1); "
                        f"if [ -n \"$w\" ]; then xdotool windowraise $w windowfocus $w mousemove 960 540 click 1; fi", 
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    env=env,
                    start_new_session=True,
                )
            return {"ok": True, "launched": cmd[0], "pid": proc.pid, "display": env.get("DISPLAY", "")}
        except Exception as exc:
            tried.append(f"{' '.join(cmd)}: {exc}")
    return {"ok": False, "error": "No supported WiFi config UI found", "tried": tried}


def run_docbox_update(manifest_url: str | None = None, timeout: int = 240) -> dict[str, Any]:
    """Run the field updater script and return bounded output."""
    workdir = os.environ.get("TVMED_WORKDIR") or os.getcwd()
    script = os.path.join(workdir, "scripts", "docbox_device_update.sh")
    if not os.path.exists(script):
        return {"ok": False, "error": f"updater script not found: {script}"}
    cmd = ["bash", script]
    if manifest_url:
        cmd.append(manifest_url)
    env = os.environ.copy()
    env.setdefault("WORKDIR", workdir)
    try:
        proc = subprocess.run(
            cmd,
            cwd=workdir,
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return {"ok": False, "error": f"update timed out after {timeout}s", "output": (exc.stdout or "")[-4000:]}
    return {
        "ok": proc.returncode == 0,
        "returncode": proc.returncode,
        "output": proc.stdout[-8000:],
    }


def launch_wifi_login(display: str = ":0") -> dict[str, Any]:
    """Open a browser window to trigger hotel/captive-portal WiFi login."""
    env = os.environ.copy()
    env.setdefault("DISPLAY", display or ":0")
    xauthority = os.environ.get("XAUTHORITY") or ""
    if not xauthority:
        try:
            ps = subprocess.run(
                ["pgrep", "-a", "Xorg"],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=2,
                check=False,
            )
            parts = ps.stdout.split()
            if "-auth" in parts:
                xauthority = parts[parts.index("-auth") + 1]
        except Exception:
            xauthority = ""
    env["XAUTHORITY"] = xauthority or os.path.expanduser("~/.Xauthority")

    browser = shutil_which("chromium") or shutil_which("chromium-browser") or shutil_which("google-chrome")
    if not browser:
        return {"ok": False, "error": "No Chromium browser found"}
    url = "http://neverssl.com/"
    cmd = [
        browser,
        "--user-data-dir=/tmp/tvmed-wifi-login",
        "--no-first-run",
        "--new-window",
        "--window-position=80,80",
        "--window-size=1760,900",
        url,
    ]
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
        start_new_session=True,
    )
    if shutil_which("xdotool"):
        subprocess.Popen(
            [
                "/bin/sh",
                "-c",
                "sleep 1.2; "
                "w=$(xdotool search --name 'NeverSSL\\|neverssl\\|Chromium' 2>/dev/null | tail -1); "
                "if [ -n \"$w\" ]; then xdotool windowraise $w windowfocus $w mousemove 960 540 click 1; fi",
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
            start_new_session=True,
        )
    return {"ok": True, "launched": os.path.basename(browser), "pid": proc.pid, "url": url, "display": env.get("DISPLAY", "")}


class Handler(BaseHTTPRequestHandler):
    server_version = "TVmedDeviceAPI/0.1"

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "content-type, x-tvmed-token")

    def _json(self, status: int, body: dict[str, Any]) -> None:
        payload = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_POST(self) -> None:  # noqa: N802
        if self.path not in {"/incoming", "/prepare", "/assistance", "/notes", "/request-call", "/reboot", "/reclaim-remote", "/wifi-config", "/wifi-login", "/update"}:
            self._json(404, {"ok": False, "error": "not found"})
            return
        token = getattr(self.server, "token", "")
        remote_host = self.client_address[0] if self.client_address else ""
        loopback_local_alert = self.path in {"/assistance", "/notes", "/request-call", "/reboot", "/reclaim-remote", "/wifi-config", "/wifi-login", "/update"} and remote_host in {"127.0.0.1", "::1"}
        if token and not loopback_local_alert and self.headers.get("x-tvmed-token") != token:
            self._json(403, {"ok": False, "error": "forbidden"})
            return
        length = int(self.headers.get("content-length", "0") or "0")
        raw = self.rfile.read(min(length, 4096)) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
            if self.path == "/assistance":
                result = send_telegram_assistance_alert(data, dry_run=bool(data.get("dryRun")))
                print(f"assistance alert result: {json.dumps({k: v for k, v in result.items() if k != 'message'})}", flush=True)
                self._json(200, {"ok": True, **result})
                return
            if self.path == "/notes":
                result = send_telegram_doctor_notes(data, dry_run=bool(data.get("dryRun")))
                print(f"doctor notes result: {json.dumps({k: v for k, v in result.items() if k != 'message'})}", flush=True)
                self._json(200, {"ok": True, **result})
                return
            if self.path == "/request-call":
                result = send_telegram_call_request(data, dry_run=bool(data.get("dryRun")))
                print(f"call request result: {json.dumps({k: v for k, v in result.items() if k != 'message'})}", flush=True)
                self._json(200, {"ok": True, **result})
                return
            if self.path == "/reboot":
                if bool(data.get("dryRun")):
                    self._json(200, {"ok": True, "dryRun": True, "queued": False})
                    return
                result = queue_reboot(int(data.get("delaySeconds") or 2))
                print(f"reboot queued: {json.dumps(result)}", flush=True)
                self._json(200, result)
                return
            if self.path == "/reclaim-remote":
                result = wake_tv(getattr(self.server, "cec_adapter", "/dev/cec0"))
                print(f"remote reclaim result: {json.dumps(result)}", flush=True)
                self._json(200 if result.get("ok") else 500, {"ok": bool(result.get("ok")), "reclaimed": bool(result.get("ok")), "cec": result})
                return
            if self.path == "/wifi-config":
                result = launch_wifi_config(getattr(self.server, "display", ":0"))
                print(f"wifi config result: {json.dumps(result)}", flush=True)
                self._json(200 if result.get("ok") else 500, result)
                return
            if self.path == "/wifi-login":
                result = launch_wifi_login(getattr(self.server, "display", ":0"))
                print(f"wifi login result: {json.dumps(result)}", flush=True)
                self._json(200 if result.get("ok") else 500, result)
                return
            if self.path == "/update":
                manifest_url = str(data.get("manifestUrl") or "")[:500] or None
                timeout = int(data.get("timeoutSeconds") or 240)
                timeout = max(30, min(timeout, 600))
                result = run_docbox_update(manifest_url, timeout=timeout)
                print(f"docbox update result: {json.dumps({k: v for k, v in result.items() if k != 'output'})}", flush=True)
                self._json(200 if result.get("ok") else 500, result)
                return
            caller = str(data.get("callerName") or "Clinician")[:80]
            if self.path == "/incoming":
                trigger_incoming(caller, self.server.cdp_host, self.server.cdp_port)
                self._json(200, {"ok": True, "state": "incoming", "callerName": caller})
                return
            call_time = int(data.get("callTime") or data.get("callTimeMs") or 0)
            if call_time <= 0:
                self._json(400, {"ok": False, "error": "callTime unix milliseconds required"})
                return
            patient_label = str(data.get("patientLabel") or "Patient")[:80]
            wake = wake_tv(getattr(self.server, "cec_adapter", "/dev/cec0")) if getattr(self.server, "wake_tv", True) else {"ok": False, "skipped": True}
            schedule_call(call_time, caller, patient_label, self.server.cdp_host, self.server.cdp_port)
            self._json(200, {"ok": True, "state": "scheduled", "callTime": call_time, "callerName": caller, "patientLabel": patient_label, "wake": wake})
        except Exception as exc:  # keep prototype API debuggable
            self._json(500, {"ok": False, "error": str(exc)})

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}", flush=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TVmed device control API")
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=int(os.environ.get("TVMED_DEVICE_API_PORT", "8091")))
    parser.add_argument("--token", default=os.environ.get("TVMED_DEVICE_API_TOKEN", ""))
    parser.add_argument("--cdp-host", default="127.0.0.1")
    parser.add_argument("--cdp-port", type=int, default=9222)
    parser.add_argument("--cec-adapter", default=os.environ.get("TVMED_CEC_ADAPTER", "/dev/cec0"))
    parser.add_argument("--display", default=os.environ.get("DISPLAY", ":0"), help="X display used for UI launch actions")
    parser.add_argument("--no-wake-tv", action="store_true", help="do not send CEC wake/active-source on /prepare")
    parser.add_argument("--trigger", metavar="CALLER", help="one-shot CLI trigger instead of serving HTTP")
    parser.add_argument("--prepare", metavar="CALL_TIME_MS", help="one-shot CLI schedule/countdown in unix milliseconds")
    args = parser.parse_args(argv)

    if args.prepare is not None:
        wake = wake_tv(args.cec_adapter) if not args.no_wake_tv else {"ok": False, "skipped": True}
        schedule_call(int(args.prepare), args.trigger or "Dr Murphy", "Patient", args.cdp_host, args.cdp_port)
        print(json.dumps({"ok": True, "callTime": int(args.prepare), "wake": wake}))
        return 0

    if args.trigger is not None:
        trigger_incoming(args.trigger, args.cdp_host, args.cdp_port)
        print(json.dumps({"ok": True, "callerName": args.trigger}))
        return 0

    httpd = ThreadingHTTPServer((args.bind, args.port), Handler)
    httpd.token = args.token
    httpd.cdp_host = args.cdp_host
    httpd.cdp_port = args.cdp_port
    httpd.cec_adapter = args.cec_adapter
    httpd.display = args.display
    httpd.wake_tv = not args.no_wake_tv
    digest = hashlib.sha256(args.token.encode()).hexdigest()[:8] if args.token else "none"
    print(f"TVmed device API listening on http://{args.bind}:{args.port} token_sha256={digest}", flush=True)
    httpd.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
