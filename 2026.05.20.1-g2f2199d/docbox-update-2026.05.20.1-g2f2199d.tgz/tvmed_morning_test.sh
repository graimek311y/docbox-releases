#!/usr/bin/env bash
# Morning operator smoke test for the TVmed Pi/Samsung prototype.
# Safe default: preflight first; TV is only woken when --wake is passed.
set -euo pipefail

cd "$(dirname "$0")"
WAKE=0
if [[ "${1:-}" == "--wake" ]]; then
  WAKE=1
fi

echo "== TVmed morning test =="
echo "Host: $(hostname)  Time: $(date -Is)"
echo

echo "1) Read-only preflight"
python3 ./tvmed_preflight.py

echo
if [[ "$WAKE" == "1" ]]; then
  echo "2) Waking TV and requesting active HDMI source"
  python3 ./tvmed_cec.py --adapter /dev/cec0 on || true
else
  echo "2) Skipping TV wake (pass --wake to turn on/request HDMI input)"
fi

echo
if command -v systemctl >/dev/null 2>&1; then
  echo "3) Installing/updating systemd units"
  # This runs as a system service because writing /dev/tty1 needs root on Debian.
  sudo cp -f systemd/tvmed-shell.service systemd/tvmed-preflight.service /etc/systemd/system/
  sudo systemctl daemon-reload || true

  echo
  echo "4) Starting prototype shell service"
  sudo systemctl restart tvmed-shell.service
  sudo systemctl --no-pager status tvmed-shell.service || true
else
  echo "3) systemctl unavailable; run manually:"
  echo "   python3 ./tvmed_cec.py --adapter /dev/cec0 listen | python3 ./tvmed_shell.py --tty /dev/tty1"
fi

echo
echo "5) On the Samsung TV, select the Pi HDMI input if needed."
echo "   Remote map: arrows move, OK selects, Back returns/declines. Home is not forwarded."
echo "   Test path: Preflight -> Back -> Incoming call mock -> OK -> OK consent -> Back -> OK end."
echo
echo "When finished, turn the TV off with: python3 ./tvmed_cec.py --adapter /dev/cec0 off"
