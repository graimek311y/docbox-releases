#!/usr/bin/env python3
"""Regression tests for the local TVmed device API."""

from __future__ import annotations

import http.client
import json
import socket
import threading
import unittest
from http.server import ThreadingHTTPServer
from unittest import mock

import tvmed_device_api


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


class DeviceApiTest(unittest.TestCase):
    def setUp(self) -> None:
        self.port = free_port()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", self.port), tvmed_device_api.Handler)
        self.httpd.token = "test-token"
        self.httpd.cdp_host = "127.0.0.1"
        self.httpd.cdp_port = 9222
        self.httpd.cec_adapter = "/dev/null"
        self.httpd.wake_tv = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self) -> None:
        self.httpd.shutdown()
        self.thread.join(timeout=2)
        self.httpd.server_close()

    def post_json(self, path: str, payload: dict, token: str | None = None) -> tuple[int, dict]:
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        headers = {"content-type": "application/json"}
        if token is not None:
            headers["x-tvmed-token"] = token
        try:
            conn.request(
                "POST",
                path,
                body=json.dumps(payload),
                headers=headers,
            )
            resp = conn.getresponse()
            body = resp.read().decode("utf-8")
            return resp.status, json.loads(body or "{}")
        finally:
            conn.close()

    def test_request_call_sends_telegram_only_and_does_not_schedule(self) -> None:
        with mock.patch.object(tvmed_device_api, "send_telegram_call_request", return_value={"dryRun": True}) as send_call_request, \
             mock.patch.object(tvmed_device_api, "schedule_call") as schedule_call, \
             mock.patch.object(tvmed_device_api, "wake_tv") as wake_tv:
            status, body = self.post_json(
                "/request-call",
                {"patientLabel": "John Doe", "reason": "Patient requested triage", "dryRun": True},
            )

        self.assertEqual(status, 200)
        self.assertTrue(body["ok"])
        send_call_request.assert_called_once()
        self.assertEqual(send_call_request.call_args.args[0]["reason"], "Patient requested triage")
        schedule_call.assert_not_called()
        wake_tv.assert_not_called()

    def test_prepare_schedules_call(self) -> None:
        with mock.patch.object(tvmed_device_api, "send_telegram_call_request") as send_call_request, \
             mock.patch.object(tvmed_device_api, "schedule_call") as schedule_call, \
             mock.patch.object(tvmed_device_api, "wake_tv", return_value={"ok": True}) as wake_tv:
            status, body = self.post_json(
                "/prepare",
                {"patientLabel": "John Doe", "callerName": "Dr Murphy", "callTime": 1900000000000},
                token="test-token",
            )

        self.assertEqual(status, 200)
        self.assertEqual(body["state"], "scheduled")
        send_call_request.assert_not_called()
        schedule_call.assert_called_once()
        wake_tv.assert_called_once()

    def test_reboot_is_loopback_allowed_and_queued(self) -> None:
        with mock.patch.object(tvmed_device_api, "queue_reboot", return_value={"ok": True, "queued": True, "delaySeconds": 2}) as queue_reboot:
            status, body = self.post_json("/reboot", {"delaySeconds": 2})

        self.assertEqual(status, 200)
        self.assertTrue(body["ok"])
        self.assertTrue(body["queued"])
        queue_reboot.assert_called_once_with(2)

    def test_reboot_dry_run_does_not_queue(self) -> None:
        with mock.patch.object(tvmed_device_api, "queue_reboot") as queue_reboot:
            status, body = self.post_json("/reboot", {"dryRun": True})

        self.assertEqual(status, 200)
        self.assertTrue(body["ok"])
        self.assertTrue(body["dryRun"])
        queue_reboot.assert_not_called()

    def test_reclaim_remote_reasserts_cec_source(self) -> None:
        with mock.patch.object(tvmed_device_api, "wake_tv", return_value={"ok": True, "method": "cec-ctl"}) as wake_tv:
            status, body = self.post_json("/reclaim-remote", {})

        self.assertEqual(status, 200)
        self.assertTrue(body["ok"])
        self.assertTrue(body["reclaimed"])
        wake_tv.assert_called_once_with("/dev/null")


if __name__ == "__main__":
    unittest.main()
