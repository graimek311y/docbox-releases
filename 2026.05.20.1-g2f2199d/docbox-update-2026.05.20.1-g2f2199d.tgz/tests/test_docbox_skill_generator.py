import importlib.util
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
GENERATOR = ROOT / "scripts" / "generate_docbox_skill.py"


def load_generator():
    spec = importlib.util.spec_from_file_location("generate_docbox_skill", GENERATOR)
    assert spec is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_generated_docbox_skill_is_current():
    generator = load_generator()
    expected = generator.render_skill()
    actual = (ROOT / "docs" / "docbox-control-skill.md").read_text(encoding="utf-8")
    assert actual == expected, "run: python3 scripts/generate_docbox_skill.py --install"


def test_generated_docbox_skill_includes_current_control_surfaces():
    generator = load_generator()
    skill = generator.render_skill()
    for endpoint in generator.parse_api_paths():
        assert f"`{endpoint}`" in skill
    for export in generator.parse_kiosk_exports():
        assert f"window.tvmedKiosk.{export}" in skill
    for action in generator.parse_menu_actions():
        assert f"`{action.value}`" in skill
