#!/usr/bin/env python3
"""Regression tests for TVmed scheduled-call prepare helper."""

from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest

MODULE_PATH = Path(__file__).resolve().parents[1] / "scripts" / "tvmed_prepare_call.py"
spec = importlib.util.spec_from_file_location("tvmed_prepare_call", MODULE_PATH)
assert spec is not None
assert spec.loader is not None
tvmed_prepare_call = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tvmed_prepare_call)


class PrepareCallTest(unittest.TestCase):
    def test_validate_future_call_time_allows_future_countdown(self) -> None:
        tvmed_prepare_call.validate_future_call_time(1_000_180_000, now_ms=1_000_000_000)

    def test_validate_future_call_time_rejects_stale_time(self) -> None:
        with self.assertRaises(ValueError):
            tvmed_prepare_call.validate_future_call_time(900_000_000, now_ms=1_000_000_000)

    def test_validate_future_call_time_allows_small_clock_skew(self) -> None:
        tvmed_prepare_call.validate_future_call_time(999_980_000, now_ms=1_000_000_000)


if __name__ == "__main__":
    unittest.main()
