'use strict';

const assert = require('assert');
const { DeviceKioskStateMachine } = require('../web/device-kiosk-state.js');

function run(name, fn) {
  try {
    fn();
    console.log(`ok - ${name}`);
  } catch (err) {
    console.error(`not ok - ${name}`);
    console.error(err && err.stack ? err.stack : err);
    process.exitCode = 1;
  }
}

run('starts idle with media stopped', () => {
  const sm = new DeviceKioskStateMachine();
  assert.strictEqual(sm.state, 'idle');
  assert.strictEqual(sm.mediaAllowed, false);
});

run('incoming call requires explicit consent before media is allowed', () => {
  const sm = new DeviceKioskStateMachine();
  sm.dispatch('incoming', { callerName: 'Dr Murphy' });
  assert.strictEqual(sm.state, 'incoming');
  assert.strictEqual(sm.mediaAllowed, false);

  sm.dispatch('acceptIncoming');
  assert.strictEqual(sm.state, 'consent');
  assert.strictEqual(sm.mediaAllowed, false);

  sm.dispatch('confirmConsent');
  assert.strictEqual(sm.state, 'connecting');
  assert.strictEqual(sm.mediaAllowed, true);
});

run('declining before consent asks safety questions before returning idle', () => {
  const sm = new DeviceKioskStateMachine();
  sm.dispatch('incoming', { callerName: 'Dr Murphy' });
  sm.dispatch('decline');
  assert.strictEqual(sm.state, 'declined_ok_check');
  assert.strictEqual(sm.mediaAllowed, false);

  sm.dispatch('patientOkYes');
  assert.strictEqual(sm.state, 'idle');
  assert.strictEqual(sm.mediaAllowed, false);
});

run('declined call can request assistance without allowing media', () => {
  const sm = new DeviceKioskStateMachine();
  sm.dispatch('incoming', { callerName: 'Dr Murphy' });
  sm.dispatch('decline');
  sm.dispatch('patientOkNo');
  assert.strictEqual(sm.state, 'declined_assistance_check');
  assert.strictEqual(sm.mediaAllowed, false);
  sm.dispatch('assistanceYes');
  assert.strictEqual(sm.state, 'declined_assistance_sent');
  assert.strictEqual(sm.mediaAllowed, false);
  sm.dispatch('assistanceSentAck');
  assert.strictEqual(sm.state, 'idle');
});

run('active call requires end confirmation before returning idle', () => {
  const sm = new DeviceKioskStateMachine();
  sm.dispatch('incoming', { callerName: 'Dr Murphy' });
  sm.dispatch('acceptIncoming');
  sm.dispatch('confirmConsent');
  sm.dispatch('mediaConnected');
  assert.strictEqual(sm.state, 'active');
  assert.strictEqual(sm.mediaAllowed, true);

  sm.dispatch('requestEnd');
  assert.strictEqual(sm.state, 'end_confirm');
  assert.strictEqual(sm.mediaAllowed, true);

  sm.dispatch('cancelEnd');
  assert.strictEqual(sm.state, 'active');
  assert.strictEqual(sm.mediaAllowed, true);

  sm.dispatch('requestEnd');
  sm.dispatch('confirmEnd');
  assert.strictEqual(sm.state, 'idle');
  assert.strictEqual(sm.mediaAllowed, false);
});

run('scheduled call countdown never enables media and incoming clears schedule', () => {
  const sm = new DeviceKioskStateMachine();
  const callTime = Date.now() + 10 * 60 * 1000;
  sm.dispatch('scheduleCall', { callTime, callerName: 'Dr Murphy', patientLabel: 'John Doe' });
  assert.strictEqual(sm.state, 'idle');
  assert.strictEqual(sm.mediaAllowed, false);
  assert.strictEqual(sm.snapshot().scheduledCall.callTime, callTime);

  sm.dispatch('incoming', { callerName: 'Dr Murphy' });
  assert.strictEqual(sm.state, 'incoming');
  assert.strictEqual(sm.mediaAllowed, false);
  assert.strictEqual(sm.snapshot().scheduledCall, null);
});

run('fault stops media', () => {
  const sm = new DeviceKioskStateMachine();
  sm.dispatch('incoming');
  sm.dispatch('acceptIncoming');
  sm.dispatch('confirmConsent');
  assert.strictEqual(sm.mediaAllowed, true);
  sm.dispatch('fault', { message: 'camera failed' });
  assert.strictEqual(sm.state, 'fault');
  assert.strictEqual(sm.mediaAllowed, false);
});
