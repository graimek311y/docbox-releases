# TVmed MVP Engineering Notes

## Prototype baseline

Current validated hardware:

- Pi 400 at `doogle@192.168.0.238`, hostname `gateway-host`
- Samsung TV via HDMI on `/dev/cec0`
- Logitech Brio camera `/dev/video0`
- Brio mic `hw:2,0`
- AWS KVS WebRTC channel `tvmed-gateway-host`, region `eu-west-1`
- Hermes ops bot: Claudette `@GPiKbot`

## Samsung remote map

Observed via HDMI-CEC when Pi input is active:

- `UP` — CEC key `up`, code `01`
- `DOWN` — CEC key `down`, code `02`
- `LEFT` — CEC key `left`, code `03`
- `RIGHT` — CEC key `right`, code `04`
- `SELECT` — CEC key `select`, code `00`
- `BACK` — CEC key `exit`, code `0d`
- Home is not forwarded to the Pi.

## Scripts

### `tvmed_cec.py`

Safe CEC helper:

```bash
./tvmed_cec.py --adapter /dev/cec0 on
./tvmed_cec.py --adapter /dev/cec0 off
./tvmed_cec.py --adapter /dev/cec0 scan
./tvmed_cec.py --adapter /dev/cec0 listen --jsonl
```

`listen` emits normalized actions suitable for the TV UI:

```text
UP
DOWN
LEFT
RIGHT
SELECT
BACK
```

or JSON lines with `--jsonl`.

### `tvmed_preflight.py`

Read-only health check for Pi appliance state:

```bash
./tvmed_preflight.py
```

Checks:

- HDMI connected
- CEC adapter/tooling present
- camera device present
- ALSA mic roughly visible
- AWS KVS env file exists with strict permissions
- Hermes gateway user service active

### `tvmed_shell.py`

The console shell now uses explicit mock-only consent and end-call confirmation states:

```text
menu -> incoming -> consent -> active -> end_call_confirm -> menu
menu -> preflight OR fault -> menu
```

Safety notes:

- The mock shell does **not** start real camera, mic, or WebRTC media.
- `Incoming call mock` needs OK once to reach consent, then OK again to start the mock active call.
- Back from an active mock call opens an `END CALL?` confirmation instead of silently ending.
- Preflight failures render a prominent fault screen.
- If the CEC listener pipeline ends, the shell logs and renders a fault screen rather than sleeping forever.

### Systemd services

Deploy on the Pi with:

```bash
sudo cp systemd/tvmed-shell.service systemd/tvmed-preflight.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl restart tvmed-shell.service
sudo systemctl status tvmed-shell.service
```

This is a system service because writing to `/dev/tty1` requires root on Debian.

`tvmed-shell.service` runs:

```bash
python3 /home/doogle/tvmed/tvmed_cec.py --adapter /dev/cec0 listen \
  | python3 /home/doogle/tvmed/tvmed_shell.py --tty /dev/tty1
```

### Morning smoke test

```bash
ssh doogle@192.168.0.238
cd ~/tvmed
./tvmed_morning_test.sh --wake
```

Remote-control test path:

1. `Preflight` -> OK -> Back.
2. `Incoming call mock` -> OK -> consent screen.
3. OK again -> `CALL ACTIVE MOCK`.
4. Back -> `END CALL?`; OK to end.
5. Turn TV off when finished: `python3 ./tvmed_cec.py --adapter /dev/cec0 off`.

### `tvmed_kvs_smoke.py`

Non-secret AWS KVS signaling/ICE check:

```bash
python3 ./tvmed_kvs_smoke.py
```

It loads `~/.hermes/tvmed-aws-kvs.env` only if permissions are strict, then verifies caller identity, channel status, WSS/HTTPS endpoints, and ICE server count. It does not start camera/mic media.

### Browser KVS media smoke

`tvmed_kvs_browser_smoke.sh` serves `web/kvs-webrtc-smoke.html`, a deliberately small AWS KVS WebRTC browser smoke page.

```bash
./tvmed_kvs_browser_smoke.sh --role MASTER --open
```

- MASTER should run in Chromium on the Pi so `getUserMedia()` captures the attached Brio camera/mic.
- VIEWER should use credentials that include `ConnectAsViewer` on the same channel.
- The helper writes `web/tvmed-kvs-config.js` from the local env file; this file may contain AWS secrets and is gitignored.
- Default bind is `127.0.0.1`; use SSH tunnelling or short controlled `--bind 0.0.0.0` tests only.

### Clinician viewer prototype

`tvmed_kvs_clinician_viewer.sh` serves `web/clinician-viewer.html`, a focused local-only VIEWER UI for proving clinician-side playback without exposing the raw smoke form.

```bash
./tvmed_kvs_clinician_viewer.sh --open
```

- Uses `~/.hermes/tvmed-aws-kvs-viewer.env` by default; permissions must be `600` or `400`.
- Generates `web/tvmed-kvs-config.js` only while the server is running, then removes it on exit.
- Requests no local camera/mic; it only receives the Pi MASTER stream.
- This is still a prototype transport viewer, not the consent/call authorization UI.

### Device browser kiosk prototype

`tvmed_device_kiosk.sh` serves `web/device-kiosk.html`, a product-shaped Pi browser UI that keeps media startup behind explicit consent.

```bash
./tvmed_device_kiosk.sh
```

Implementation notes:

- `web/device-kiosk-state.js` contains the deterministic state model and is covered by `tests/device-kiosk-state.test.js`.
- The header uses the TVmed logo asset at `web/assets/tvmed-logo-header.png`; the source upload was converted to a transparent PNG so it fits the dark kiosk UI cleanly.
- State flow: `idle -> incoming -> consent -> connecting -> active -> end_confirm -> idle`, with `fault` stopping media.
- `getUserMedia()` and KVS `MASTER` startup are only called after `confirmConsent` moves the state to `connecting` with `mediaAllowed=true`.
- Decline before consent returns to idle with camera/mic still off.
- End-call confirmation is required before media is stopped and the UI returns to idle.
- Current controls are prototype-local (`Test incoming call`, Enter/Escape). Real remote-start commands and Samsung CEC button mapping still need to be wired into this browser/device-service layer.

## Next implementation step

Replace the console shell with the browser/device kiosk as the main Pi UI and wire real control inputs around it:

1. Launch `tvmed_device_kiosk.sh` on the Pi and manually validate the consent-gated path on the Samsung TV.
2. Add a small local command channel for clinician-started incoming-call events.
3. Map Samsung CEC remote actions to the browser state buttons.
4. Re-test Pi MASTER ↔ clinician VIEWER through the consent-gated path.
5. Add audio only after video remains stable through this flow.

Keep it deterministic. Hermes can inspect status/logs but must not decide consent or camera/mic activation.
