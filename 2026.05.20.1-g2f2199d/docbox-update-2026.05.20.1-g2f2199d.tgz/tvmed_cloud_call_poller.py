#!/usr/bin/env python3
"""Poll doogle.bot for TVmed cloud call commands and forward to local Device API.

Prototype bridge: keeps the Pi private (no inbound ports) while letting the
HTTPS clinician viewer enqueue incoming-call commands through the Cloudflare
Worker. Media still remains consent-gated in the kiosk state machine.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

DEVICE_ID = os.environ.get("TVMED_DEVICE_ID", "gateway-host")
POLL_URL = os.environ.get(
    "TVMED_CLOUD_POLL_URL",
    f"https://doogle.bot/docbox/api/device/{DEVICE_ID}/poll",
)
DEVICE_API_URL = os.environ.get("TVMED_LOCAL_DEVICE_API_URL", "http://127.0.0.1:8091/incoming")
DEVICE_PREPARE_URL = os.environ.get("TVMED_LOCAL_PREPARE_URL", "http://127.0.0.1:8091/prepare")
POLL_INTERVAL = float(os.environ.get("TVMED_CLOUD_POLL_INTERVAL", "2"))
STATE_FILE = Path(os.environ.get("TVMED_CLOUD_POLLER_STATE", "/home/doogle/tvmed/.tvmed-cloud-poller-state.json"))
CLOUD_TOKEN = os.environ.get("TVMED_DEVICE_CLOUD_TOKEN", "")
LOCAL_TOKEN = os.environ.get("TVMED_DEVICE_API_TOKEN", "")

running = True


def stop(_signum, _frame):
    global running
    running = False


def request_json(url: str, *, method: str = "GET", data: dict | None = None, headers: dict | None = None, timeout: float = 10.0) -> dict:
    payload = None if data is None else json.dumps(data).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        method=method,
        headers={"content-type": "application/json", "user-agent": "Mozilla/5.0 TVmedDevice/1.0", **(headers or {})},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def load_last_id() -> str:
    try:
        return json.loads(STATE_FILE.read_text()).get("lastCommandId", "")
    except Exception:
        return ""


def save_last_id(command_id: str) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps({"lastCommandId": command_id, "updatedAt": time.time()}) + "\n")


def forward_incoming(command: dict) -> None:
    caller = str(command.get("callerName") or "Clinician")[:80]
    headers = {"x-tvmed-token": LOCAL_TOKEN} if LOCAL_TOKEN else {}
    request_json(DEVICE_API_URL, method="POST", data={"callerName": caller}, headers=headers, timeout=5)


def forward_prepare(command: dict) -> None:
    caller = str(command.get("callerName") or "Clinician")[:80]
    patient_label = str(command.get("patientLabel") or "Patient")[:80]
    call_time = int(command.get("callTime") or 0)
    headers = {"x-tvmed-token": LOCAL_TOKEN} if LOCAL_TOKEN else {}
    request_json(
        DEVICE_PREPARE_URL,
        method="POST",
        data={"callerName": caller, "patientLabel": patient_label, "callTime": call_time},
        headers=headers,
        timeout=10,
    )


def main() -> int:
    if not CLOUD_TOKEN:
        print("TVMED_DEVICE_CLOUD_TOKEN missing", file=sys.stderr, flush=True)
        return 2
    if not LOCAL_TOKEN:
        print("TVMED_DEVICE_API_TOKEN missing", file=sys.stderr, flush=True)
        return 2

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    last_id = load_last_id()
    print(f"TVmed cloud poller started: {POLL_URL}", flush=True)

    while running:
      try:
        data = request_json(POLL_URL, headers={"x-tvmed-device-token": CLOUD_TOKEN}, timeout=10)
        command = data.get("command") if data.get("ok") else None
        if command and command.get("type") in {"incoming", "prepare"}:
            command_id = str(command.get("id") or "")
            if command_id and command_id != last_id:
                if command.get("type") == "incoming":
                    forward_incoming(command)
                else:
                    forward_prepare(command)
                last_id = command_id
                save_last_id(last_id)
                print(f"forwarded {command.get('type')} command {command_id} caller={command.get('callerName','')!r}", flush=True)
      except urllib.error.HTTPError as exc:
        print(f"poll HTTP {exc.code}: {exc.read(160).decode('utf-8', 'ignore')}", file=sys.stderr, flush=True)
      except Exception as exc:
        print(f"poll error: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
      time.sleep(POLL_INTERVAL)
    print("TVmed cloud poller stopped", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
