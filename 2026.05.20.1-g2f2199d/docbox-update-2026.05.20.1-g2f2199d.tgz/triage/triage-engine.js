/**
 * docbox Triage Engine
 * Claude-powered clinical triage for TV remote navigation
 * 
 * Flow:
 *   1. Patient selects presenting complaint from TV screen
 *   2. Engine runs 4-6 adaptive yes/no questions via Claude
 *   3. Outputs structured JSON: urgency + specialty + summary
 *   4. Summary sent to clinician console before call connects
 */

const TRIAGE_SYSTEM_PROMPT = `You are a clinical triage assistant for docbox, a telemedicine system for elderly patients at home.

Your role is to conduct a brief structured symptom interview to help a clinician prepare for a video consultation.

RULES:
- Ask ONE question at a time
- Questions must be answerable with YES or NO or a simple 1-3 word choice
- Use plain simple language — the patient may be elderly, anxious, or have cognitive difficulties
- Maximum 8 questions total
- Base your questions on NHS 111 and Manchester Triage System clinical pathways
- After enough information is gathered, output a structured JSON result

RESPONSE FORMAT during interview:
Return a JSON object with:
{
  "question": "Your next question in plain English",
  "question_num": <1-8>,
  "should_stop": false
}

RESPONSE FORMAT when complete (after enough information):
{
  "should_stop": true,
  "urgency": "emergency" | "same-day" | "within-24h" | "routine" | "self-care",
  "urgency_label": "Short human-readable label e.g. 'Call 999 now' or 'See GP today'",
  "specialty": "emergency | gp | respiratory | cardiology | neurology | orthopaedics | dermatology | urology | mental-health | pharmacy | palliative",
  "presenting_complaint": "Brief description of the main issue",
  "key_symptoms": ["symptom 1", "symptom 2"],
  "red_flags": ["any serious warning signs identified"],
  "clinician_summary": "2-3 sentence plain English summary for the clinician",
  "patient_message": "Short reassuring message to show the patient on TV while they wait"
}

URGENCY GUIDE (NHS-aligned):
- emergency: life-threatening symptoms — chest pain + sweating, stroke signs, severe breathing difficulty, unconsciousness, major bleeding → advise 999
- same-day: needs to be seen today but not life-threatening
- within-24h: needs medical attention soon
- routine: can wait for next available appointment
- self-care: manageable at home with advice`;

const PRESENTING_COMPLAINTS = [
  { id: "chest",       label: "Chest pain or tightness",    icon: "♥", prompt: "The patient is reporting chest pain or tightness. Age: {age}. Start by asking about severity and onset." },
  { id: "breathing",   label: "Breathing difficulty",        icon: "🫁", prompt: "The patient is having difficulty breathing. Age: {age}. Start by asking if this came on suddenly." },
  { id: "fall",        label: "Fall or injury",              icon: "⚡", prompt: "The patient has had a fall or injury. Age: {age}. Start by asking if they can move and where the pain is." },
  { id: "confusion",   label: "Confusion or memory",         icon: "🧠", prompt: "The patient or carer reports confusion or memory problems. Age: {age}. Start by asking if this is new or sudden." },
  { id: "pain",        label: "Pain somewhere",              icon: "😣", prompt: "The patient has pain somewhere. Age: {age}. Start by asking where the pain is." },
  { id: "wound",       label: "Wound or skin problem",       icon: "🩹", prompt: "The patient has a wound or skin problem. Age: {age}. Start by asking where it is and if there are signs of infection." },
  { id: "stomach",     label: "Stomach or digestive",        icon: "🫄", prompt: "The patient has a stomach or digestive problem. Age: {age}. Start by asking if there is pain, nausea or vomiting." },
  { id: "urine",       label: "Urinary problem",             icon: "💧", prompt: "The patient has a urinary problem. Age: {age}. Start by asking if there is pain when urinating." },
  { id: "mental",      label: "Feeling low or anxious",      icon: "💭", prompt: "The patient is feeling low or anxious. Age: {age}. Start by asking how long they have been feeling this way." },
  { id: "medication",  label: "Medication question",         icon: "💊", prompt: "The patient has a question about their medication. Age: {age}. Start by asking which medication they are concerned about." },
  { id: "general",     label: "Generally unwell",            icon: "🌡", prompt: "The patient feels generally unwell. Age: {age}. Start by asking if they have a temperature or fever." },
  { id: "other",       label: "Something else",              icon: "❓", prompt: "The patient wants to discuss something else. Age: {age}. Start by asking them to describe their main concern in a few words." },
];

/**
 * Start a triage session
 * Returns: { sessionId, firstQuestion, question_num }
 */
async function startTriage(complaintId, patientAge, apiKey) {
  const complaint = PRESENTING_COMPLAINTS.find(c => c.id === complaintId);
  if (!complaint) throw new Error(`Unknown complaint: ${complaintId}`);
  
  const userPrompt = complaint.prompt.replace('{age}', patientAge || 'unknown');
  
  const response = await callClaude([
    { role: 'user', content: userPrompt }
  ], apiKey);
  
  return {
    sessionId: Date.now().toString(),
    complaint: complaintId,
    history: [
      { role: 'user', content: userPrompt },
      { role: 'assistant', content: response.raw }
    ],
    ...response.parsed
  };
}

/**
 * Submit an answer and get next question or final result
 */
async function answerTriage(session, answer, apiKey) {
  const history = [...session.history, { role: 'user', content: answer }];
  
  const response = await callClaude(history, apiKey);
  
  return {
    ...session,
    history: [...history, { role: 'assistant', content: response.raw }],
    ...response.parsed
  };
}

async function callClaude(messages, apiKey) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5',
      max_tokens: 400,
      system: TRIAGE_SYSTEM_PROMPT,
      messages,
    })
  });
  
  if (!res.ok) throw new Error(`Claude API error: ${res.status}`);
  const data = await res.json();
  const raw = data.content[0].text;
  
  // Extract JSON from response
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error('No JSON in response');
  
  const parsed = JSON.parse(jsonMatch[0]);
  return { raw, parsed };
}

// Export for use in TVmed state machine
if (typeof module !== 'undefined') {
  module.exports = { startTriage, answerTriage, PRESENTING_COMPLAINTS };
}
