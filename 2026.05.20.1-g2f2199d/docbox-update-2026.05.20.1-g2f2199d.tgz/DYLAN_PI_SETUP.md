# Dylan Pi setup

This repo contains code only. Runtime secrets are intentionally **not** in git.

## Clone

```bash
git clone https://github.com/graimek311y/TVmed.git ~/tvmed
cd ~/tvmed
```

## Pi packages

Debian/Raspberry Pi OS/Trixie baseline:

```bash
sudo apt update
sudo apt install -y \
  python3 python3-boto3 python3-websockets \
  chromium xserver-xorg xinit unclutter xdotool \
  v4l-utils alsa-utils cec-utils nodejs npm
```

## Hardware expected by current prototype

- HDMI TV connected to Pi.
- USB UVC camera/mic, currently tested with Logitech Brio.
- HDMI-CEC adapter exposed as `/dev/cec0`.
- Camera expected as `/dev/video0`.
- Mic expected as ALSA `hw:2,0` on Graeme's Pi; Dylan may need to change this.

Check Dylan's devices:

```bash
v4l2-ctl --list-devices
arecord -l
cec-ctl --list-devices || true
```

## Runtime env files Dylan needs from Graeme

Create these files locally on the Pi. Do not commit them.

### `/home/doogle/.hermes/tvmed-aws-kvs.env`

```bash
mkdir -p ~/.hermes
chmod 700 ~/.hermes
nano ~/.hermes/tvmed-aws-kvs.env
chmod 600 ~/.hermes/tvmed-aws-kvs.env
```

Required values:

```text
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=eu-west-1
KVS_SIGNALING_CHANNEL=tvmed-gateway-host
TVMED_DEVICE_ID=gateway-host
VIDEO_DEVICE=/dev/video0
AUDIO_DEVICE=hw:2,0
VIDEO_WIDTH=1280
VIDEO_HEIGHT=720
VIDEO_FPS=30
```

For Dylan's own Pi/device, create a separate KVS channel/device ID rather than sharing `gateway-host` long-term.

### `/home/doogle/tvmed/tvmed-device.env`

```bash
nano ~/tvmed/tvmed-device.env
chmod 600 ~/tvmed/tvmed-device.env
```

Required values:

```text
TVMED_DEVICE_API_TOKEN=...
TVMED_DEVICE_CLOUD_TOKEN=...
TVMED_DEVICE_ID=gateway-host
TVMED_CLOUD_POLL_URL=https://doogle.bot/docbox/api/device/gateway-host/poll
TVMED_LOCAL_INCOMING_URL=http://127.0.0.1:8091/incoming
```

## Audio routing

Install the prototype ALSA default mapping, then edit card names if Dylan's Pi differs:

```bash
cp config/pi-asoundrc ~/.asoundrc
arecord -D default -d 2 /tmp/tvmed-mic.wav
aplay /tmp/tvmed-mic.wav
```

## Smoke checks

```bash
python3 tvmed_preflight.py
python3 tvmed_kvs_smoke.py
node --test tests/device-kiosk-state.test.js
```

## Run kiosk manually first

```bash
./tvmed_device_kiosk.sh
```

Chromium must include `--disable-features=WebRtcPipeWireCamera`; the script already does this for the current Pi kiosk path.

## Install systemd services

```bash
sudo cp systemd/tvmed-device-kiosk.service /etc/systemd/system/
sudo cp systemd/tvmed-cloud-call-poller.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now tvmed-device-kiosk.service tvmed-cloud-call-poller.service
systemctl status tvmed-device-kiosk.service tvmed-cloud-call-poller.service
```

## Test with online clinician viewer

Use Chrome/Edge desktop:

1. Open `https://doogle.bot/docbox/` with Graeme's gate key.
2. Click **Call device**.
3. On TV, accept incoming call and confirm consent.
4. Click **Connect viewer** and allow clinician camera/mic.
5. Confirm two-way media:
   - patient Brio/mic → clinician browser;
   - clinician camera/mic → Samsung TV.

## Common fixes

- If Chromium hangs or camera is black: ensure kiosk launches with `--disable-features=WebRtcPipeWireCamera`.
- If audio capture fails in Chromium but `arecord -D plughw:...` works: fix `~/.asoundrc` so `arecord -D default` works.
- If online call button does not ring the TV: check `tvmed-cloud-call-poller.service` logs and `TVMED_DEVICE_CLOUD_TOKEN`.
- If WebRTC connects but echo is bad: use a USB speakerphone or lower TV volume; browser AEC may not fully cancel HDMI TV speaker → USB mic echo.
