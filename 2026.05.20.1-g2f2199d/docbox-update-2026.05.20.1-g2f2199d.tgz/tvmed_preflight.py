#!/usr/bin/env python3
"""TVmed Pi appliance preflight checks.

Safe read-only checks for the current Pi 400 prototype.
"""

from __future__ import annotations

import json
import os
import pwd
import shutil
import subprocess
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass
class Check:
    name: str
    ok: bool
    detail: str


def run(cmd: list[str], timeout: int = 10) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout, check=False)
        return p.returncode, p.stdout.strip()
    except Exception as e:
        return 999, repr(e)


def exists(path: str) -> bool:
    return Path(path).exists()


def check_hdmi() -> Check:
    statuses = []
    for p in Path("/sys/class/drm").glob("card*-HDMI-A-*/status"):
        statuses.append(f"{p.name}={p.read_text().strip()}")
    ok = any(s.endswith("=connected") for s in statuses)
    return Check("hdmi", ok, ", ".join(statuses) or "no HDMI status files")


def check_cec() -> Check:
    adapters = [str(p) for p in Path("/dev").glob("cec*")]
    ok = "/dev/cec0" in adapters and shutil.which("cec-client") is not None
    return Check("cec", ok, f"adapters={adapters}; cec-client={shutil.which('cec-client')}")


def check_camera() -> Check:
    ok = exists(os.environ.get("VIDEO_DEVICE", "/dev/video0"))
    return Check("camera", ok, os.environ.get("VIDEO_DEVICE", "/dev/video0"))


def check_mic() -> Check:
    code, out = run(["arecord", "-l"])
    expected = os.environ.get("AUDIO_DEVICE", "hw:2,0")
    ok = code == 0 and ("BRIO" in out.upper() or "Logitech" in out or expected.startswith("hw:"))
    return Check("mic", ok, f"expected={expected}; arecord_exit={code}")


def check_kvs_env() -> Check:
    home = Path(os.environ.get("TVMED_USER_HOME", str(Path.home())))
    env = home / ".hermes" / "tvmed-aws-kvs.env"
    ok = env.exists() and (env.stat().st_mode & 0o077) == 0
    return Check("aws_kvs_env", ok, str(env))


def check_hermes_gateway() -> Check:
    user = os.environ.get("TVMED_USER", "doogle")
    # Normal SSH/user context.
    code, out = run(["systemctl", "--user", "is-active", "hermes-gateway.service"])
    if code == 0 and out.strip() == "active":
        return Check("hermes_gateway", True, out)

    # System service/root context: query the user's systemd manager.
    try:
        uid = pwd.getpwnam(user).pw_uid
        env = os.environ.copy()
        env.update({"XDG_RUNTIME_DIR": f"/run/user/{uid}", "DBUS_SESSION_BUS_ADDRESS": f"unix:path=/run/user/{uid}/bus"})
        p = subprocess.run(
            ["systemctl", "--user", "is-active", "hermes-gateway.service"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=10,
            check=False,
            env=env,
        )
        if p.returncode == 0 and p.stdout.strip() == "active":
            return Check("hermes_gateway", True, p.stdout.strip())
        out = p.stdout.strip() or out
    except Exception as e:
        out = f"{out}; user-scope check failed: {e!r}"

    # Last resort: process check keeps prototype preflight useful if the user bus
    # is inaccessible from root during boot.
    code2, out2 = run(["pgrep", "-af", "hermes.*gateway"])
    ok = code2 == 0 and bool(out2.strip())
    return Check("hermes_gateway", ok, "active via process" if ok else out)


def main() -> int:
    checks = [
        check_hdmi(),
        check_cec(),
        check_camera(),
        check_mic(),
        check_kvs_env(),
        check_hermes_gateway(),
    ]
    print(json.dumps([asdict(c) for c in checks], indent=2))
    return 0 if all(c.ok for c in checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
