#!/usr/bin/env bash
set -euo pipefail

# Launch the local clinician VIEWER prototype for the TVmed KVS channel.
# Generates web/tvmed-kvs-config.js from a strict-permission viewer env file.
# The generated config contains AWS credentials; serve localhost only and remove
# it on exit.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${TVMED_KVS_VIEWER_ENV_FILE:-$HOME/.hermes/tvmed-aws-kvs-viewer.env}"
BIND="127.0.0.1"
PORT="8090"
OPEN_BROWSER=0

usage() {
  cat <<USAGE
Usage: $0 [--port 8090] [--open]

Starts http://127.0.0.1:PORT/web/clinician-viewer.html using viewer-only KVS
credentials from ~/.hermes/tvmed-aws-kvs-viewer.env.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --port) PORT="$2"; shift 2 ;;
    --open) OPEN_BROWSER=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown arg: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Viewer env file not found: $ENV_FILE" >&2
  exit 1
fi
mode="$(stat -c '%a' "$ENV_FILE" 2>/dev/null || stat -f '%Lp' "$ENV_FILE")"
if [[ "$mode" != "600" && "$mode" != "400" ]]; then
  echo "Refusing to load $ENV_FILE: permissions must be 600 or 400 (got $mode)" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

: "${AWS_REGION:=eu-west-1}"
: "${KVS_SIGNALING_CHANNEL:=tvmed-gateway-host}"
: "${TVMED_DEVICE_ID:=viewer-smoke}"
: "${AWS_ACCESS_KEY_ID:?AWS_ACCESS_KEY_ID missing}"
: "${AWS_SECRET_ACCESS_KEY:?AWS_SECRET_ACCESS_KEY missing}"

CONFIG="$ROOT/web/tvmed-kvs-config.js"
cleanup() { rm -f "$CONFIG"; }
trap cleanup EXIT

python3 - "$CONFIG" <<'PY'
import json, os, sys
path = sys.argv[1]
config = {
    "role": "VIEWER",
    "region": os.environ.get("AWS_REGION", "eu-west-1"),
    "channelName": os.environ.get("KVS_SIGNALING_CHANNEL", "tvmed-gateway-host"),
    "clientId": os.environ.get("TVMED_DEVICE_ID", "viewer-smoke"),
    "accessKeyId": os.environ["AWS_ACCESS_KEY_ID"],
    "secretAccessKey": os.environ["AWS_SECRET_ACCESS_KEY"],
    "sessionToken": os.environ.get("AWS_SESSION_TOKEN", ""),
    "callTriggerUrl": os.environ.get("TVMED_CALL_TRIGGER_URL", "http://192.168.0.238:8091/incoming"),
    "callTriggerToken": os.environ.get("TVMED_CALL_TRIGGER_TOKEN", ""),
}
open(path, "w").write("window.TVMED_KVS_CONFIG = " + json.dumps(config) + ";\n")
os.chmod(path, 0o600)
PY

URL="http://$BIND:$PORT/web/clinician-viewer.html"
echo "TVmed clinician viewer: $URL"
echo "Region: $AWS_REGION  Channel: $KVS_SIGNALING_CHANNEL  Client: $TVMED_DEVICE_ID"
echo "Start the Pi MASTER first, then click Connect viewer."

if [[ "$OPEN_BROWSER" == "1" ]]; then
  if command -v open >/dev/null 2>&1; then
    open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 &
  else
    echo "Open manually: $URL"
  fi
fi

cd "$ROOT"
python3 -m http.server "$PORT" --bind "$BIND"
