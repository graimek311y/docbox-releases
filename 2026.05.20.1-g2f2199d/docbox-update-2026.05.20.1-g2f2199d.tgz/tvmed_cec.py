#!/usr/bin/env python3
"""TVmed HDMI-CEC remote listener/control helper.

Normalizes Samsung TV remote key events from libCEC into a tiny event stream
for the TVmed appliance shell.

Observed TVmed Samsung CEC mapping:
  select/OK=00, up=01, down=02, left=03, right=04, back/return/exit=0d
"""

from __future__ import annotations

import argparse
import json
import re
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from typing import Iterable

KEY_RE = re.compile(r"key pressed: ([a-zA-Z0-9_ -]+) \(([^)]+)\)")

ACTION_BY_KEY = {
    "select": "SELECT",
    "up": "UP",
    "down": "DOWN",
    "left": "LEFT",
    "right": "RIGHT",
    "exit": "BACK",
    "back": "BACK",
}

CEC_CODE_BY_ACTION = {
    "SELECT": "00",
    "UP": "01",
    "DOWN": "02",
    "LEFT": "03",
    "RIGHT": "04",
    "BACK": "0d",
}


@dataclass
class CECEvent:
    ts: float
    key: str
    action: str
    raw_code: str
    raw_line: str


def normalize_key(raw: str) -> str:
    return raw.strip().lower().replace(" ", "_")


def parse_events(lines: Iterable[str]) -> Iterable[CECEvent]:
    for line in lines:
        # libCEC logs each press twice; the line with current(...) is the stable
        # low-level event, while the second line is a higher-level duplicate.
        if "key pressed:" not in line or " current(" not in line:
            continue
        match = KEY_RE.search(line)
        if not match:
            continue
        key = normalize_key(match.group(1))
        raw_code = match.group(2).split(",", 1)[0].strip().lower()
        action = ACTION_BY_KEY.get(key)
        if not action:
            # Keep unknown keys visible for future mapping.
            action = f"UNKNOWN:{key}"
        yield CECEvent(time.time(), key, action, raw_code, line.rstrip("\n"))


def run_listener(adapter: str, debug: int, jsonl: bool, once: bool) -> int:
    cmd = ["cec-client", "-d", str(debug), adapter]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    def stop(_signum, _frame):
        proc.terminate()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    assert proc.stdout is not None
    try:
        for event in parse_events(proc.stdout):
            if jsonl:
                print(json.dumps(asdict(event), sort_keys=True), flush=True)
            else:
                print(event.action, flush=True)
            if once:
                proc.terminate()
                return 0
    finally:
        if proc.poll() is None:
            proc.terminate()
    return proc.wait() if proc.returncode is not None else 0


def send_cec(adapter: str, commands: list[str]) -> int:
    payload = "\n".join(commands) + "\n"
    proc = subprocess.run(
        ["cec-client", "-s", "-d", "1", adapter],
        input=payload,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if proc.stdout:
        print(proc.stdout, end="")
    return proc.returncode


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TVmed HDMI-CEC helper")
    parser.add_argument("--adapter", default="/dev/cec0")
    sub = parser.add_subparsers(dest="cmd", required=True)

    listen = sub.add_parser("listen", help="listen for remote key events")
    listen.add_argument("--debug", type=int, default=31)
    listen.add_argument("--jsonl", action="store_true", help="emit JSON lines")
    listen.add_argument("--once", action="store_true", help="exit after first key")

    sub.add_parser("on", help="wake TV and request active source")
    sub.add_parser("off", help="put TV in standby")
    sub.add_parser("scan", help="scan CEC bus")

    args = parser.parse_args(argv)
    if args.cmd == "listen":
        return run_listener(args.adapter, args.debug, args.jsonl, args.once)
    if args.cmd == "on":
        return send_cec(args.adapter, ["on 0", "as"])
    if args.cmd == "off":
        return send_cec(args.adapter, ["standby 0"])
    if args.cmd == "scan":
        return send_cec(args.adapter, ["scan"])
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
