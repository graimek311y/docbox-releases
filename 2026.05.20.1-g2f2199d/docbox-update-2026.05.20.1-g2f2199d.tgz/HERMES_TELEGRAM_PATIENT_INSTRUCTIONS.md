# TVmed Telegram Patient Instructions

Short patient-facing Telegram prompts for Hermes or an operator to send when a TVmed call is about to start.

## Primary message

```text
TVmed call incoming.

1. Turn on the TV.
2. Switch the TV to the TVmed / Raspberry Pi HDMI channel.
3. When the TVmed screen shows the incoming call, choose Accept Call.
4. When asked, choose Turn On Camera.
5. Stay in front of the camera and wait for the clinician to connect.
```

## If the TV screen is blank

```text
If the TV is blank:

1. Check the TV is on.
2. Press Source/Input on the TV remote.
3. Choose the HDMI input labelled TVmed / Raspberry Pi.
4. Wait 10 seconds for the TVmed screen to appear.
```

## If the call does not appear

```text
If no incoming call appears:

1. Leave the TV on the TVmed HDMI channel.
2. Do not unplug the Raspberry Pi.
3. Message back: "TVmed ready, no call showing".
```

## If camera/mic permission appears

```text
If the screen asks for camera or microphone permission, choose Allow.
```

## End of call

```text
When the appointment is finished, press Back/Return on the TV remote and confirm End Call if asked.
```

## Operator notes

- Patient should not need a keyboard or mouse.
- Samsung TV remote OK/Select accepts call/camera consent; Back/Return starts end-call flow.
- Keep wording simple: TV on, correct HDMI, Accept Call, Turn On Camera.
- Do not include runtime secrets, tokens, AWS keys, or the gated clinician URL in patient messages.
