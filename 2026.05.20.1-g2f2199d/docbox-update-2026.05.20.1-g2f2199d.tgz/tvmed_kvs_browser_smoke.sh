#!/usr/bin/env bash
set -euo pipefail

# Start a local static server for the prototype KVS WebRTC browser smoke page.
# It writes web/tvmed-kvs-config.js from environment variables or
# ~/.hermes/tvmed-aws-kvs.env. That generated file may contain AWS secrets and
# is intentionally gitignored.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${TVMED_KVS_ENV_FILE:-$HOME/.hermes/tvmed-aws-kvs.env}"
BIND="127.0.0.1"
PORT="8088"
ROLE="${KVS_ROLE:-MASTER}"
OPEN_BROWSER=0

usage() {
  cat <<USAGE
Usage: $0 [--role MASTER|VIEWER] [--bind 127.0.0.1|0.0.0.0] [--port 8088] [--open]

Default binds to localhost to avoid serving AWS credentials on the LAN.
Use SSH tunnel or --bind 0.0.0.0 only for controlled smoke tests.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --role) ROLE="$2"; shift 2 ;;
    --bind) BIND="$2"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --open) OPEN_BROWSER=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown arg: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ -f "$ENV_FILE" ]]; then
  mode="$(stat -c '%a' "$ENV_FILE" 2>/dev/null || stat -f '%Lp' "$ENV_FILE")"
  if [[ "$mode" != "600" && "$mode" != "400" ]]; then
    echo "Refusing to load $ENV_FILE: permissions must be 600 or 400 (got $mode)" >&2
    exit 1
  fi
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

: "${AWS_REGION:=eu-west-1}"
: "${KVS_SIGNALING_CHANNEL:=tvmed-gateway-host}"
: "${TVMED_DEVICE_ID:=gateway-host}"
: "${AWS_ACCESS_KEY_ID:?AWS_ACCESS_KEY_ID missing}"
: "${AWS_SECRET_ACCESS_KEY:?AWS_SECRET_ACCESS_KEY missing}"

if [[ "$BIND" != "127.0.0.1" && "$BIND" != "localhost" ]]; then
  cat >&2 <<WARN
WARNING: binding to $BIND will serve web/tvmed-kvs-config.js containing AWS credentials.
Use only on a trusted LAN for a short smoke test, then Ctrl-C.
WARN
fi

CONFIG="$ROOT/web/tvmed-kvs-config.js"
python3 - "$CONFIG" <<'PY'
import json, os, sys
path = sys.argv[1]
config = {
    "role": os.environ.get("KVS_BROWSER_ROLE") or os.environ.get("KVS_ROLE", "MASTER"),
    "region": os.environ.get("AWS_REGION", "eu-west-1"),
    "channelName": os.environ.get("KVS_SIGNALING_CHANNEL", "tvmed-gateway-host"),
    "clientId": os.environ.get("TVMED_DEVICE_ID", "gateway-host"),
    "patientLabel": os.environ.get("TVMED_PATIENT_LABEL", "John Doe"),
    "accessKeyId": os.environ["AWS_ACCESS_KEY_ID"],
    "secretAccessKey": os.environ["AWS_SECRET_ACCESS_KEY"],
    "sessionToken": os.environ.get("AWS_SESSION_TOKEN", ""),
}
open(path, "w").write("window.TVMED_KVS_CONFIG = " + json.dumps(config) + ";\n")
os.chmod(path, 0o600)
PY
# Override role in generated config if --role was supplied.
python3 - "$CONFIG" "$ROLE" <<'PY'
import json, re, sys
path, role = sys.argv[1], sys.argv[2]
text = open(path).read()
config = json.loads(re.search(r'= (.*);', text).group(1))
config['role'] = role
open(path, 'w').write('window.TVMED_KVS_CONFIG = ' + json.dumps(config) + ';\n')
PY

echo "TVmed KVS browser smoke page: http://$BIND:$PORT/web/kvs-webrtc-smoke.html"
echo "Role: $ROLE  Region: $AWS_REGION  Channel: $KVS_SIGNALING_CHANNEL"
echo "MASTER: open on the Pi with the Brio attached; browser will request camera/mic."
echo "VIEWER: use viewer-capable credentials and open the same page in another browser."

if [[ "$OPEN_BROWSER" == "1" ]]; then
  if command -v chromium-browser >/dev/null 2>&1; then
    chromium-browser "http://127.0.0.1:$PORT/web/kvs-webrtc-smoke.html" >/dev/null 2>&1 &
  elif command -v chromium >/dev/null 2>&1; then
    chromium "http://127.0.0.1:$PORT/web/kvs-webrtc-smoke.html" >/dev/null 2>&1 &
  else
    echo "No chromium/chromium-browser command found; open the URL manually."
  fi
fi

cd "$ROOT"
python3 -m http.server "$PORT" --bind "$BIND"
