# Docbox field update system

This documents the repeatable update path for Docbox appliances that are already installed in the field and may not be reachable over LAN/SSH.

## Goals

- Update appliances without GitHub credentials on the Pi.
- Keep secrets out of public bundles.
- Preserve per-device runtime files such as `.env`, `tvmed-device.env`, and `web/tvmed-kvs-config.js`.
- Back up before every update.
- Run smoke checks before reporting success.
- Allow updates from either the kiosk maintenance menu or a local command triggered by Hermes/Telegram.

## Version numbering

Use a human-readable CalVer release for field appliances:

```text
YYYY.MM.DD.N-g<gitsha>
```

Example:

```text
2026.05.20.1-g22b5be6
```

Rules:

- `YYYY.MM.DD` is the UTC date the release is cut.
- `N` is the stable release number for that date: `.1`, `.2`, `.3`, etc.
- `g<gitsha>` is the short TVmed commit included in the bundle.
- The public channel alias stays `stable`; the version above is immutable and appears in the manifest, bundle path, `.docbox-version`, and the kiosk home screen badge as `docbox : <version>`.
- For test appliances, use a separate channel such as `beta` with the same version format.

The release builder defaults to `.1` for the current UTC day. If cutting a second same-day release, pass the version explicitly:

```bash
python3 scripts/build_docbox_release.py \
  --version 2026.05.20.2-g$(git rev-parse --short HEAD) \
  --channel stable
```

## Release model

1. Build a no-secrets release bundle on the Mac/CI:

   ```bash
   cd ~/.openclaw/workspace/TVmed
   python3 scripts/build_docbox_release.py \
     --base-url https://graimek311y.github.io/docbox-releases \
     --channel stable
   ```

2. Publish `dist/docbox-releases/` to the public release repo:

   ```text
   https://github.com/graimek311y/docbox-releases
   ```

   Files are then available under:

   ```text
   https://graimek311y.github.io/docbox-releases/
   ```

   Expected public files:

   - `stable/manifest.json`
   - `stable/docbox_device_update.sh`
   - `stable/install.sh`
   - `<version>/manifest.json`
   - `<version>/docbox-update-<version>.tgz`

3. Field devices update from the manifest:

   ```bash
   /home/doogle/tvmed/scripts/docbox_device_update.sh
   ```

   Or bootstrap/update a device that has curl but not a fresh repo checkout:

   ```bash
   curl -fsSL https://graimek311y.github.io/docbox-releases/stable/install.sh | bash
   ```

## Device-side update behavior

`scripts/docbox_device_update.sh` runs on the Pi and:

- downloads the public release manifest;
- downloads the release tarball;
- verifies SHA256;
- backs up `/home/doogle/tvmed` to `/home/doogle/tvmed/backups/docbox-update-before-<timestamp>.tgz`;
- syncs the release into `/home/doogle/tvmed`;
- preserves secrets/runtime files:
  - `.env`
  - `tvmed-device.env`
  - `web/tvmed-kvs-config.js`
  - `.git`, `backups`, venvs, `node_modules`
- writes `.docbox-version`;
- runs syntax/state-machine smoke checks;
- reloads the kiosk browser through CDP when possible.

## Kiosk/API trigger

The device local API exposes:

```bash
curl -sS -X POST http://127.0.0.1:8091/update \
  -H 'content-type: application/json' \
  -d '{}'
```

The kiosk maintenance menu **Update** action calls this endpoint. Loopback access is allowed; external callers still need the device API token.

Optional manifest override:

```bash
curl -sS -X POST http://127.0.0.1:8091/update \
  -H 'content-type: application/json' \
  -d '{"manifestUrl":"https://graimek311y.github.io/docbox-releases/beta/manifest.json"}'
```

## Telegram/Hermes phrasing

For a Docbox Hermes bot in the field, use:

```text
Update Docbox
```

If the bot does not have a deterministic command/plugin yet, tell it to run:

```bash
/home/doogle/tvmed/scripts/docbox_device_update.sh
```

or bootstrap from public release:

```bash
curl -fsSL https://doogle.bot/docbox/releases/stable/install.sh | bash
```

## Rollback

Each update creates a timestamped backup under `/home/doogle/tvmed/backups/`. Manual rollback on a Pi:

```bash
cd /home/doogle/tvmed
latest=$(ls -1t backups/docbox-update-before-*.tgz | head -1)
tar -xzf "$latest" -C /home/doogle/tvmed
python3 - <<'PY'
import tvmed_device_api as api
api.websocket_eval(api.find_kiosk_ws_url(), "window.location.reload()")
PY
```

## Safety notes

- Do not put API keys, AWS keys, Telegram tokens, patient-specific secrets, or generated `web/tvmed-kvs-config.js` in release bundles.
- The build script has a conservative secret scan, but still inspect unusual changes before publishing.
- Prefer channels: `stable` for field devices, `beta` for test appliances.
- Use per-device env/runtime config for identities and KVS credentials; releases should be generic code/assets only.
