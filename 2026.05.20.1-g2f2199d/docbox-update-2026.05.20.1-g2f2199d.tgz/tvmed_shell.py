#!/usr/bin/env python3
"""Minimal TVmed console shell prototype.

This intentionally simple shell renders large text to a Linux TTY and accepts
normalized actions from stdin (UP/DOWN/LEFT/RIGHT/SELECT/BACK). It can be driven
by:

  ./tvmed_cec.py listen | ./tvmed_shell.py --tty /dev/tty1

The goal is a deterministic, remote-control-safe state model that can later be
reused by a kiosk/browser UI.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

MENU = ["Preflight", "Incoming call mock", "Active call mock", "Turn TV off"]
ACTIONS = {"UP", "DOWN", "LEFT", "RIGHT", "SELECT", "BACK"}


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def event_log_path() -> Path:
    return Path.home() / ".hermes" / "tvmed-shell-events.log"


def log_event(message: str) -> None:
    try:
        path = event_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S%z')} {message}\n")
    except Exception:
        # Logging must never break the TV UI.
        pass


def preflight_checks() -> tuple[list[dict], list[str]]:
    proc = subprocess.run(
        [sys.executable, str(script_dir() / "tvmed_preflight.py")],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
        timeout=15,
    )
    try:
        checks = json.loads(proc.stdout)
        lines = [f"{'OK' if c['ok'] else 'FAIL'}  {c['name']}: {c['detail']}" for c in checks]
        return checks, lines
    except Exception:
        return [{"name": "preflight_parse", "ok": False, "detail": "could not parse preflight output"}], [
            "FAIL preflight_parse: could not parse output",
            proc.stdout[:1000],
        ]


class Shell:
    def __init__(self, tty: Path):
        self.tty = tty
        self.screen = "menu"
        self.idx = 0
        self.lines: list[str] = []
        self.call_started_at: float | None = None

    def write(self, text: str) -> None:
        self.tty.write_text(text)

    def render(self) -> None:
        if self.screen == "menu":
            lines = [
                "\033c",
                "TVMED PROTOTYPE\n",
                "Use Samsung remote: arrows, OK, Back\n",
                "No camera/mic starts in this prototype.\n",
                "\n",
            ]
            for i, item in enumerate(MENU):
                prefix = "> " if i == self.idx else "  "
                lines.append(f"{prefix}{item}\n")
            lines.append("\nHome is not forwarded by Samsung.\n")
            self.write("".join(lines))
        elif self.screen == "preflight":
            self.write("\033cTVMED PREFLIGHT\n\n" + "\n".join(self.lines) + "\n\nBack = menu\n")
        elif self.screen == "fault":
            self.write(
                "\033cTVMED NEEDS ATTENTION\n\n"
                + "\n".join(self.lines)
                + "\n\nBack = menu\nOK = run preflight again\n"
            )
        elif self.screen == "incoming":
            self.write(
                "\033cINCOMING CALL MOCK\n\n"
                "Dr Murphy is calling\n\n"
                "OK = continue to consent screen\n"
                "Back = decline\n\n"
                "Camera/mic are still OFF.\n"
            )
        elif self.screen == "consent":
            self.write(
                "\033cCONSENT REQUIRED\n\n"
                "Press OK to start the mock call.\n"
                "Press Back to decline.\n\n"
                "Prototype note: no real camera/mic/WebRTC is started.\n"
            )
        elif self.screen == "active":
            elapsed = 0 if self.call_started_at is None else int(time.time() - self.call_started_at)
            self.write(
                "\033cCALL ACTIVE MOCK\n\n"
                f"Elapsed: {elapsed // 60:02d}:{elapsed % 60:02d}\n"
                "Camera/mic indicator: MOCK ONLY (not active)\n\n"
                "Back = end call confirmation\n"
            )
        elif self.screen == "end_call_confirm":
            self.write("\033cEND CALL?\n\nOK = end mock call\nBack = stay in call\n")
        elif self.screen == "off":
            self.write("\033cTurning TV off...\n")

    def run_preflight(self) -> None:
        checks, lines = preflight_checks()
        self.lines = lines
        if all(bool(c.get("ok")) for c in checks):
            self.screen = "preflight"
            log_event("preflight ok")
        else:
            self.screen = "fault"
            failed = ",".join(str(c.get("name")) for c in checks if not c.get("ok"))
            log_event(f"preflight failed: {failed}")

    def turn_tv_off(self) -> bool:
        self.screen = "off"
        self.render()
        log_event("tv standby requested from shell")
        subprocess.run([sys.executable, str(script_dir() / "tvmed_cec.py"), "off"], check=False, timeout=15)
        return False

    def handle(self, action: str) -> bool:
        action = action.strip().upper()
        if not action:
            return True
        if action not in ACTIONS:
            log_event(f"ignored unknown action: {action}")
            return True

        if self.screen == "menu":
            if action == "UP":
                self.idx = (self.idx - 1) % len(MENU)
            elif action == "DOWN":
                self.idx = (self.idx + 1) % len(MENU)
            elif action == "SELECT":
                if self.idx == 0:
                    self.run_preflight()
                elif self.idx == 1:
                    self.screen = "incoming"
                    log_event("incoming mock shown")
                elif self.idx == 2:
                    self.screen = "consent"
                    log_event("direct active mock requires consent screen")
                elif self.idx == 3:
                    return self.turn_tv_off()

        elif self.screen == "preflight":
            if action == "BACK":
                self.screen = "menu"

        elif self.screen == "fault":
            if action == "BACK":
                self.screen = "menu"
            elif action == "SELECT":
                self.run_preflight()

        elif self.screen == "incoming":
            if action == "SELECT":
                self.screen = "consent"
                log_event("incoming mock consent requested")
            elif action == "BACK":
                self.screen = "menu"
                log_event("incoming mock declined")

        elif self.screen == "consent":
            if action == "SELECT":
                self.screen = "active"
                self.call_started_at = time.time()
                log_event("mock call active after explicit consent")
            elif action == "BACK":
                self.screen = "menu"
                log_event("mock call declined at consent")

        elif self.screen == "active":
            if action == "BACK":
                self.screen = "end_call_confirm"
                log_event("end mock call confirmation shown")
            elif action in {"UP", "DOWN", "LEFT", "RIGHT", "SELECT"}:
                # Placeholder for future PTZ/volume controls; keep visible in logs.
                log_event(f"active mock action: {action}")

        elif self.screen == "end_call_confirm":
            if action == "SELECT":
                self.screen = "menu"
                self.call_started_at = None
                log_event("mock call ended")
            elif action == "BACK":
                self.screen = "active"
                log_event("end mock call cancelled")

        self.render()
        return True

    def eof_fault(self) -> int:
        self.screen = "fault"
        self.lines = [
            "FAIL cec_listener: input stream ended",
            "The Samsung remote listener stopped or the pipeline closed.",
            "Restart tvmed-shell.service or run the morning test script.",
        ]
        log_event("stdin EOF / CEC listener stopped")
        self.render()
        return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tty", default="/dev/tty1")
    args = parser.parse_args()
    shell = Shell(Path(args.tty))
    shell.render()
    try:
        for line in sys.stdin:
            if not shell.handle(line):
                return 0
    except KeyboardInterrupt:
        log_event("shell interrupted")
        return 130
    return shell.eof_fault()


if __name__ == "__main__":
    raise SystemExit(main())
