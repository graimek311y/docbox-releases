#!/usr/bin/env python3
"""Non-secret AWS KVS WebRTC signaling smoke test for the TVmed Pi.

Loads ~/.hermes/tvmed-aws-kvs.env when present, verifies caller identity,
signaling channel status, endpoints, and ICE server config. It does not start
camera/mic media and does not print secrets.
"""

from __future__ import annotations

import json
import os
import stat
import sys
from pathlib import Path


def load_env(path: Path) -> None:
    if not path.exists():
        return
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode & 0o077:
        raise SystemExit(f"Refusing to load {path}: permissions must be 600 or stricter")
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def main() -> int:
    load_env(Path.home() / ".hermes" / "tvmed-aws-kvs.env")
    try:
        import boto3
        from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"boto3 unavailable: {e}"}, indent=2))
        return 2

    region = os.environ.get("AWS_REGION", "eu-west-1")
    channel = os.environ.get("KVS_SIGNALING_CHANNEL", "tvmed-gateway-host")
    role = os.environ.get("KVS_ROLE", "MASTER")

    try:
        sts = boto3.client("sts", region_name=region)
        caller = sts.get_caller_identity()
        kv = boto3.client("kinesisvideo", region_name=region)
        desc = kv.describe_signaling_channel(ChannelName=channel)["ChannelInfo"]
        arn = desc["ChannelARN"]
        endpoints = kv.get_signaling_channel_endpoint(
            ChannelARN=arn,
            SingleMasterChannelEndpointConfiguration={
                "Protocols": ["WSS", "HTTPS"],
                "Role": role,
            },
        )["ResourceEndpointList"]
        https_endpoint = next(e["ResourceEndpoint"] for e in endpoints if e["Protocol"] == "HTTPS")
        ice = boto3.client("kinesis-video-signaling", region_name=region, endpoint_url=https_endpoint)
        ice_servers = ice.get_ice_server_config(ChannelARN=arn)["IceServerList"]
        result = {
            "ok": desc.get("ChannelStatus") == "ACTIVE" and len(ice_servers) > 0,
            "account": caller.get("Account"),
            "caller_arn_suffix": caller.get("Arn", "").split("/")[-1],
            "region": region,
            "channel": channel,
            "channel_status": desc.get("ChannelStatus"),
            "endpoint_protocols": sorted(e["Protocol"] for e in endpoints),
            "ice_server_count": len(ice_servers),
            "media_started": False,
        }
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result["ok"] else 1
    except (NoCredentialsError, BotoCoreError, ClientError, Exception) as e:
        print(json.dumps({"ok": False, "region": region, "channel": channel, "error": str(e)}, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
